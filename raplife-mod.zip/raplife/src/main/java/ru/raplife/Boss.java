package ru.raplife;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.VindicatorEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.*;

/** Босс главы 4: Инспектор «Тишина» из Ведомства Культурной Безопасности. */
public final class Boss {
    public static final String TAG = "raplife_boss";
    private static class Fight { VindicatorEntity e; ServerBossBar bar; long start; boolean phase2; }
    private static final Map<UUID, Fight> F = new HashMap<>();
    private static final Random R = new Random();

    public static void start(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (a.chapter < 4 || a.bossDone == 1) { p.sendMessage(Text.literal("§7Инспектор пока не ищет тебя.")); return; }
        if (F.containsKey(p.getUuid())) { p.sendMessage(Text.literal("§7Бой уже идёт.")); return; }
        ServerWorld w = p.getServerWorld();
        double ang = R.nextDouble() * Math.PI * 2;
        int x = (int) (p.getX() + Math.cos(ang) * 16), z = (int) (p.getZ() + Math.sin(ang) * 16);
        int y = w.getRegistryKey() == World.OVERWORLD ? w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) : (int) p.getY();
        VindicatorEntity v = EntityType.VINDICATOR.create(w);
        if (v == null) return;
        v.refreshPositionAndAngles(x + 0.5, y, z + 0.5, 0f, 0f);
        v.setCustomName(Text.literal("§4Инспектор «Тишина»"));
        v.setCustomNameVisible(true);
        var hp = v.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (hp != null) hp.setBaseValue(160);
        v.setHealth(160f);
        var dmg = v.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
        if (dmg != null) dmg.setBaseValue(7);
        v.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_AXE));
        v.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
        v.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
        v.setEquipmentDropChance(EquipmentSlot.HEAD, 0f);
        v.addCommandTag(TAG);
        v.setPersistent();
        v.setTarget(p);
        w.spawnEntity(v);
        Fight f = new Fight();
        f.e = v; f.start = p.getServer().getOverworld().getTime();
        f.bar = new ServerBossBar(Text.literal("§4Инспектор «Тишина»"), BossBar.Color.RED, BossBar.Style.NOTCHED_10);
        f.bar.addPlayer(p);
        F.put(p.getUuid(), f);
        Story.title(p, "Инспектор «Тишина»", "Босс");
        RapAi.speak(p, "Инспектор «Тишина»", Story.PERSONA.get("Инспектор «Тишина»"), "Инспектор вышел на бой с рэпером.",
                Story.FB.get("Инспектор «Тишина»"), null);
    }

    public static void tick(MinecraftServer s) {
        if (F.isEmpty()) return;
        RapState st = RapState.get(s);
        long now = s.getOverworld().getTime();
        Iterator<Map.Entry<UUID, Fight>> it = F.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Fight> en = it.next();
            Fight f = en.getValue();
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(en.getKey());
            if (p == null || f.e.isRemoved() || now - f.start > 9000) {
                if (!f.e.isRemoved()) f.e.discard();
                f.bar.clearPlayers();
                if (p != null) {
                    st.of(p.getUuid()).addHype(-50); st.markDirty();
                    p.sendMessage(Text.literal("§7Инспектор растворился в тишине. Ты потерял время и 50 хайпа."));
                }
                it.remove();
                continue;
            }
            f.bar.setPercent(Math.max(0f, Math.min(1f, f.e.getHealth() / f.e.getMaxHealth())));
            if (!f.phase2 && f.e.getHealth() < f.e.getMaxHealth() / 2) {
                f.phase2 = true;
                p.sendMessage(Text.literal("§4Инспектор: §fХватит. Музыка — не твоя. Она вообще ничья."));
                Crime.spawnPatrol(p, 2);
            }
        }
    }

    public static void abort(UUID id) {
        Fight f = F.remove(id);
        if (f != null) { f.e.discard(); f.bar.clearPlayers(); }
    }

    public static void onDeath(LivingEntity e, DamageSource src) {
        if (e instanceof ServerPlayerEntity sp) {
            Fight f = F.remove(sp.getUuid());
            if (f != null) {
                f.e.discard(); f.bar.clearPlayers();
                RapState st = RapState.get(sp.getServer());
                st.of(sp.getUuid()).addHype(-30); st.markDirty();
                sp.sendMessage(Text.literal("§7Тишина победила. §c-30 хайпа§7. Вернись сильнее: /rap boss"));
            }
            return;
        }
        if (!e.getCommandTags().contains(TAG)) return;
        UUID owner = null;
        for (Map.Entry<UUID, Fight> en : F.entrySet()) if (en.getValue().e == e) { owner = en.getKey(); break; }
        if (owner == null) return;
        Fight f = F.remove(owner);
        f.bar.clearPlayers();
        MinecraftServer s = e.getServer();
        ServerPlayerEntity p = s == null ? null : s.getPlayerManager().getPlayer(owner);
        if (p == null) return;
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(owner);
        a.bossDone = 1; a.addHype(120); a.cred += 10; a.repGov -= 15; a.wanted = Math.max(0, a.wanted - 2);
        st.markDirty();
        Story.title(p, "Тишина побеждена", "+120 хайпа");
        Story.unlockTape(p, a, 5);
        p.sendMessage(Text.literal("§6Инспектор рассыпался стопкой бланков. §fВедомство отступает. §7Дорога к финалу: набери 2000 хайпа."));
    }
}
