package ru.raplife;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

public final class AiClient {
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10)).build();

    /** Возвращает текст ответа или null (нет ключа / ошибка) — тогда мод использует офлайн-генератор. */
    public static CompletableFuture<String> ask(String system, String user) {
        Config c = Config.get();
        if (!c.ready()) return CompletableFuture.completedFuture(null);
        try {
            JsonObject body = new JsonObject();
            body.addProperty("model", c.model);
            body.addProperty("max_tokens", 300);
            body.addProperty("temperature", 1.0);
            JsonArray msgs = new JsonArray();
            msgs.add(msg("system", system));
            msgs.add(msg("user", user));
            body.add("messages", msgs);

            HttpRequest.Builder rb = HttpRequest.newBuilder(URI.create(c.endpoint))
                    .timeout(Duration.ofSeconds(30))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8));
            if (c.apiKey != null && !c.apiKey.isBlank()) rb.header("Authorization", "Bearer " + c.apiKey);

            return HTTP.sendAsync(rb.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                    .thenApply(r -> {
                        if (r.statusCode() / 100 != 2) return (String) null;
                        JsonObject o = JsonParser.parseString(r.body()).getAsJsonObject();
                        return o.getAsJsonArray("choices").get(0).getAsJsonObject()
                                .getAsJsonObject("message").get("content").getAsString().trim();
                    })
                    .exceptionally(e -> null);
        } catch (Exception e) {
            return CompletableFuture.completedFuture(null);
        }
    }

    private static JsonObject msg(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }
}
