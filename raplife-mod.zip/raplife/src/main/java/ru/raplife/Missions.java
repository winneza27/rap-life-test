package ru.raplife;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Random;

/** Поручения от Старшего: 1 треки, 2 концерт B+, 3 доставки, 4 прослушивания. */
public final class Missions {
    private static final Random R = new Random();
    private static final String[] NAMES = {"", "Записать треков", "Выступить на концерте с рангом B и выше", "Выполнить доставок", "Набрать прослушиваний"};

    public static void accept(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (a.mType != 0) { status(p); return; }
        int type = 1 + R.nextInt(4);
        int ch = a.chapter;
        switch (type) {
            case 1 -> { a.mTarget = 2 + R.nextInt(2); a.mReward = 150 * a.mTarget; }
            case 2 -> { a.mTarget = 1; a.mReward = 400 + ch * 100; }
            case 3 -> { a.mTarget = 1 + R.nextInt(2); a.mReward = 300 * a.mTarget; }
            default -> { a.mTarget = 300 + ch * 400; a.mReward = 200 + ch * 100; }
        }
        a.mType = type;
        a.mProgress = 0;
        st.markDirty();
        Gui.say(p, "§6Старший: §fЕсть дело. " + NAMES[type] + ": " + a.mTarget + ". Заплачу " + a.mReward + " ₽ и уважением.");
    }

    public static void status(ServerPlayerEntity p) {
        RapState.Stats a = RapState.get(p.getServer()).of(p.getUuid());
        if (a.mType == 0) { Gui.say(p, "§7Поручений нет. Найди своего Старшего (Помощники → Старший)."); return; }
        Gui.say(p, "§6Поручение: §f" + NAMES[a.mType] + " §7— " + a.mProgress + "/" + a.mTarget + " §8| награда " + a.mReward + " ₽");
    }

    public static void onEvent(ServerPlayerEntity p, int type, int amount) {
        if (amount <= 0) return;
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (a.mType != type) return;
        a.mProgress += amount;
        if (a.mProgress < a.mTarget) { st.markDirty(); return; }
        a.addMoney(a.mReward);
        a.cred += 2;
        a.repStreet += 3;
        CrewSys.addRep(st, a, 3);
        Gui.say(p, "§6Старший: §fРаботу сделал — уважаю. §a+" + a.mReward + " ₽, §e+2 авторитета");
        a.mType = 0;
        a.mProgress = 0;
        st.markDirty();
    }
}
