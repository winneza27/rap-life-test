package ru.raplife;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.Random;

/** ПКМ — фристайл (+хайп). Запись трека: /rap track <название> с микрофоном в руке. */
public class MicItem extends Item {
    private static final Random R = new Random();
    private static final String[] LINES = {"Ты выдал фристайл на кухне — соседи аплодируют стенами.",
            "Ты записал дэмку на диктофон. Звук мутный, но душа есть.",
            "Ты читаешь куплет в зеркало. Зеркало в шоке.",
            "Ты прогнал хук три раза подряд — сосед сверху подпевает."};

    public MicItem(Settings s) { super(s); }

    @Override
    public TypedActionResult<ItemStack> use(World w, PlayerEntity p, Hand h) {
        ItemStack stack = p.getStackInHand(h);
        if (w.isClient || !(p instanceof ServerPlayerEntity sp)) return TypedActionResult.success(stack);
        if (p.getItemCooldownManager().isCoolingDown(this)) return TypedActionResult.fail(stack);
        p.getItemCooldownManager().set(this, 200);

        RapState st = RapState.get(sp.getServer());
        RapState.Stats a = st.of(sp.getUuid());
        int g = 3 + R.nextInt(6);
        a.hype += g;
        st.markDirty();

        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1f, 0.7f + R.nextFloat() * 0.6f);
        ((ServerWorld) w).spawnParticles(ParticleTypes.NOTE, p.getX(), p.getY() + 2, p.getZ(), 8, 0.5, 0.4, 0.5, 1.0);
        sp.sendMessage(Text.literal("§b" + LINES[R.nextInt(LINES.length)] + " §e+" + g + " хайпа"), true);
        return TypedActionResult.success(stack);
    }
}
