package ru.raplife;

import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

/** Лейблы: аванс и больше прослушиваний в обмен на долю с роялти и квоту новых треков. */
public final class Labels {
    public record Label(String name, int minHype, int advance, int cutPct, double mult, String desc) {}

    public static final Label[] L = {
            new Label("Подпол Коллектив", 100, 500, 15, 1.2, "Независимый, мягкие условия"),
            new Label("Бетон Рекордс", 300, 3000, 40, 1.6, "Серьёзный лейбл района"),
            new Label("Мега Мьюзик Групп", 800, 12000, 55, 2.2, "Большие деньги, большие аппетиты")};

    public static double mult(RapState.Stats a) { return a.label < 0 ? 1.0 : L[a.label].mult(); }
    public static double keep(RapState.Stats a) { return a.label < 0 ? 1.0 : (100 - L[a.label].cutPct()) / 100.0; }

    public static void open(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (!a.builds.containsKey("label")) {
            Gui.say(p, "§7Подписывать контракты можно в офисе лейбла. Построй его: Телефон → Стройка.");
            return;
        }
        Gui.Builder b = new Gui.Builder("Лейбл", 3);
        for (int i = 0; i < L.length; i++) {
            final int idx = i;
            Label l = L[i];
            boolean cur = a.label == i;
            boolean ok = a.hype >= l.minHype() && a.label < 0;
            b.set(11 + i * 2, Gui.icon(cur ? Items.ENCHANTED_GOLDEN_APPLE : Items.GOLD_INGOT, (cur ? "§a✔ " : ok ? "§6" : "§8") + l.name(),
                    "§7" + l.desc(), "§7Аванс: §a" + l.advance() + " ₽", "§7Доля лейбла: §c" + l.cutPct() + "%", "§7Прослушивания: §e×" + l.mult(),
                    "§7Квота: 2 новых трека за 10 минут", cur ? "§aТвой контракт" : ok ? "§eКлик — подписать" : "§8Нужно хайпа: " + l.minHype()),
                    ok ? q -> sign(q, idx) : null);
        }
        if (a.label >= 0) b.set(22, Gui.icon(Items.BARRIER, "§cРасторгнуть контракт", "§7Неустойка: треть аванса"), Labels::breakContract);
        b.set(18, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(p);
    }

    private static void sign(ServerPlayerEntity p, int idx) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        Label l = L[idx];
        a.label = idx;
        a.labelTracks = 0;
        a.addMoney(l.advance());
        st.markDirty();
        Story.title(p, "Контракт", l.name());
        Gui.say(p, "§6Контракт подписан: §f" + l.name() + " §aаванс +" + l.advance() + " ₽§7. Лейбл забирает " + l.cutPct() + "% роялти.");
        open(p);
    }

    private static void breakContract(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (a.label < 0) return;
        int fine = L[a.label].advance() / 3;
        if (a.money < fine) { Gui.say(p, "§cНеустойка: " + fine + " ₽."); return; }
        a.addMoney(-fine);
        a.label = -1;
        st.markDirty();
        Gui.say(p, "§7Контракт расторгнут. Неустойка " + fine + " ₽.");
        open(p);
    }

    public static void quotaCheck(MinecraftServer s) {
        RapState st = RapState.get(s);
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            RapState.Stats a = st.of(p.getUuid());
            if (a.label < 0) continue;
            if (a.labelTracks < 2) {
                a.addMoney(-500); a.addHype(-10); a.addLoyalty(-3);
                Gui.say(p, "§c" + L[a.label].name() + ": квота не выполнена (нужно 2 трека за 10 минут). §7Штраф 500 ₽, -10 хайпа.");
            } else Gui.say(p, "§a" + L[a.label].name() + ": квота выполнена. Так держать.");
            a.labelTracks = 0;
            st.markDirty();
        }
    }
}
