package ru.raplife;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.VindicatorEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/** Бифы: баттлы с вымышленными рэперами (3 раунда с ИИ-строчками), разборки с бойцами, PvP-баттлы. */
public final class Beef {
    public static final String THUG = "raplife_thug";
    public record Rival(String name, String crew, int minHype, String style) {}

    public static final Rival[] RIVALS = {
            new Rival("Yung Бетон", "Серый Квартал", 0, "грубоватый трэп с районной бравадой"),
            new Rival("Lil Мазут", "Масляные", 100, "ленивый клауд-рэп с язвительными панчами"),
            new Rival("OG Решётка", "Забор Records", 300, "старая школа, снисходительный тон"),
            new Rival("MC Сквозняк", "Тихий Ветер", 800, "быстрая читка и сложные метафоры"),
            new Rival("Принц Подземки", "Метро-клуб", 2000, "пафосный, обожает сцену и себя")};

    private static final Random R = new Random();
    private static final Set<UUID> ACTIVE = new HashSet<>();
    private static final Map<UUID, UUID> REQ = new HashMap<>();
    private static final String[][] OFF_BARS = {
            {"Твой флоу — как лифт без кнопок: вроде едет, а никуда.", "Я пишу на салфетках — и всё равно выше твоих чартов."},
            {"Ты зовёшь это панчем? Это эхо из пустого подъезда.", "Мои фанаты считают лайки, а твои — пересчитывают маму."},
            {"Бит играет за меня, а ты просто стоишь рядом.", "Пока ты ищешь рифму, я уже собрал стадион."}};

    public static void abort(UUID id) { ACTIVE.remove(id); }

    public static int bestQuality(RapState.Stats a) {
        int q = 3;
        for (RapState.Track t : a.tracks) q = Math.max(q, t.quality);
        return q;
    }

    // ---------- GUI ----------
    public static void openGui(ServerPlayerEntity p) {
        RapState.Stats a = RapState.get(p.getServer()).of(p.getUuid());
        Gui.Builder b = new Gui.Builder("Бифы", 3);
        b.set(4, Gui.icon(Items.BOOK, "§fСчёт бифов", "§aПобед: " + a.beefWins, "§cПоражений: " + a.beefLosses), null);
        for (int i = 0; i < RIVALS.length; i++) {
            final int idx = i;
            Rival r = RIVALS[i];
            boolean avail = a.hype >= r.minHype();
            Consumer<ServerPlayerEntity> act = null;
            if (avail) act = q -> { q.closeHandledScreen(); challenge(q, idx); };
            b.set(11 + i, Gui.icon(avail ? Items.IRON_SWORD : Items.BARRIER, (avail ? "§c" : "§8") + r.name(),
                    "§7Crew: " + r.crew(), "§7Стиль: " + r.style(), avail ? "§eКлик — бросить вызов" : "§8Нужно хайпа: " + r.minHype()), act);
        }
        b.set(22, Gui.icon(Items.PLAYER_HEAD, "§dВызвать игрока на баттл", "§7Команда: §f/rap beef <игрок>"), null);
        b.set(26, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(p);
    }

    // ---------- баттл с рэпером ----------
    public static void challenge(ServerPlayerEntity p, int idx) {
        MinecraftServer s = p.getServer();
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(p.getUuid());
        long now = s.getOverworld().getTime();
        if (ACTIVE.contains(p.getUuid()) || Choices.hasPending(p.getUuid()) || Concert.active(p.getUuid())) { Gui.say(p, "§7Сначала закончи текущее дело."); return; }
        if (a.hype < RIVALS[idx].minHype()) { Gui.say(p, "§7Он пока не снизойдёт до тебя."); return; }
        if (now - a.lastBeef < 3600) { Gui.say(p, "§7Дай остыть: бифы не чаще раза в 3 минуты."); return; }
        a.lastBeef = now;
        a.beefRival = idx;
        ACTIVE.add(p.getUuid());
        st.markDirty();
        Story.title(p, "Баттл", RIVALS[idx].name());
        round(p, idx, new int[2], 1);
    }

    private static void round(ServerPlayerEntity p, int idx, int[] sc, int r) {
        if (!ACTIVE.contains(p.getUuid())) return;
        if (r > 3) { end(p, idx, sc); return; }
        Rival rv = RIVALS[idx];
        RapAi.speak(p, rv.name(), "Ты — " + rv.name() + ", вымышленный рэпер (" + rv.style() + "). Читаешь дисс на соперника: остро и остроумно, без мата, "
                        + "без оскорблений по внешности, национальности, здоровью, без угроз.",
                "Раунд " + r + " баттла.", OFF_BARS[(r - 1) % OFF_BARS.length],
                () -> Choices.offer(p, "Раунд " + r + "/3 · " + sc[0] + ":" + sc[1], List.of("Чем отвечаешь?"),
                        Choices.opt("Флоу (хайп и качество треков)", q -> resolve(q, idx, sc, r, 0)),
                        Choices.opt("Панчлайн (авторитет, риск)", q -> resolve(q, idx, sc, r, 1)),
                        Choices.opt("Правда (лояльность и стиль)", q -> resolve(q, idx, sc, r, 2))));
    }

    private static void resolve(ServerPlayerEntity p, int idx, int[] sc, int r, int kind) {
        MinecraftServer s = p.getServer();
        RapState.Stats a = RapState.get(s).of(p.getUuid());
        Rival rv = RIVALS[idx];
        int mine = switch (kind) {
            case 0 -> a.hype / 30 + bestQuality(a) * 2 + R.nextInt(16);
            case 1 -> (int) (a.cred * 1.2) + R.nextInt(22);
            default -> a.loyalty / 4 + Shop.style(a) + R.nextInt(13);
        };
        int theirs = 10 + rv.minHype() / 25 + idx * 3 + R.nextInt(16);
        sc[0] += mine;
        sc[1] += theirs;
        String[] how = {"флоу", "панчлайн", "правду"};
        diss(p.getName().getString(), rv.name(), how[kind]).thenAccept(lines -> s.execute(() -> {
            Gui.say(p, "§6Ты (" + how[kind] + "):");
            for (String l : lines) Gui.say(p, "  §f" + l);
            Gui.say(p, "§7Раунд " + r + ": ты §e" + mine + " §7— " + rv.name() + " §c" + theirs + (mine >= theirs ? " §a(твой раунд)" : " §c(его раунд)"));
            round(p, idx, sc, r + 1);
        }));
    }

    private static void end(ServerPlayerEntity p, int idx, int[] sc) {
        MinecraftServer s = p.getServer();
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(p.getUuid());
        Rival rv = RIVALS[idx];
        ACTIVE.remove(p.getUuid());
        boolean win = sc[0] >= sc[1];
        Story.title(p, win ? "Победа" : "Поражение", rv.name() + " " + sc[0] + ":" + sc[1]);
        if (win) {
            a.addHype(40 + idx * 25);
            a.followers += 100 + idx * 80;
            a.cred += 2 + idx;
            a.addLoyalty(3);
            a.beefWins++;
            Streaming.addTrack(a, "Ответка: " + rv.name(), true, s.getOverworld().getTime());
            Gui.say(p, "§aТы выиграл бифф! §e+" + (40 + idx * 25) + " хайпа§7. Дисс-трек «Ответка: " + rv.name() + "» вышел на Облачке.");
            if (R.nextInt(100) < 35) {
                Gui.say(p, "§6Люди «" + rv.crew() + "» ждут тебя у выхода. Разборка!");
                spawnThugs(p, rv.crew(), 3);
            }
        } else {
            a.addHype(-20);
            a.addLoyalty(-5);
            a.beefLosses++;
            Gui.say(p, "§cТы проиграл баттл. §7-20 хайпа, фанаты расстроены.");
        }
        a.beefRival = -1;
        st.markDirty();
    }

    private static CompletableFuture<List<String>> diss(String nick, String rivalName, String how) {
        String user = "Рэпер «" + nick + "» отвечает сопернику «" + rivalName + "» в баттле, делая ставку на " + how
                + ". Напиши 2 коротких строки ответного дисса: остроумно, без мата, без оскорблений по внешности, "
                + "национальности, здоровью, без угроз. Верни только 2 строки.";
        return AiClient.ask(RapAi.SYSTEM, user).thenApply(t -> {
            List<String> l = RapAi.lines(t, 2);
            return l.isEmpty() ? Arrays.asList(OFF_BARS[R.nextInt(OFF_BARS.length)]) : l;
        });
    }

    // ---------- входящий дисс ----------
    public static void incoming(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (ACTIVE.contains(p.getUuid())) return;
        List<Integer> ok = new ArrayList<>();
        for (int i = 0; i < RIVALS.length; i++) if (a.hype >= RIVALS[i].minHype()) ok.add(i);
        int idx = ok.get(R.nextInt(ok.size()));
        Rival rv = RIVALS[idx];
        RapAi.speak(p, rv.name(), "Ты — " + rv.name() + ", вымышленный рэпер (" + rv.style() + "). Выкладываешь трек-дисс на игрока: остро, без мата и оскорблений личного характера.",
                "Соперник выпустил дисс на игрока.", OFF_BARS[R.nextInt(OFF_BARS.length)],
                () -> Choices.offer(p, "Дисс на тебя", List.of(rv.name() + " («" + rv.crew() + "») бросил вызов."),
                        Choices.opt("Ответить на баттле", q -> challenge(q, idx)),
                        Choices.opt("Проигнорировать (-5 хайпа)", q -> { a.addHype(-5); a.addLoyalty(-2); st.markDirty(); Gui.say(q, "§7Фанаты шепчутся: «молчит»."); })));
    }

    // ---------- разборка ----------
    private static void spawnThugs(ServerPlayerEntity p, String crew, int n) {
        ServerWorld w = p.getServerWorld();
        for (int i = 0; i < n; i++) {
            double ang = R.nextDouble() * Math.PI * 2, dist = 12 + R.nextInt(6);
            int x = (int) (p.getX() + Math.cos(ang) * dist), z = (int) (p.getZ() + Math.sin(ang) * dist);
            int y = w.getRegistryKey() == World.OVERWORLD ? w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) : (int) p.getY();
            VindicatorEntity v = EntityType.VINDICATOR.create(w);
            if (v == null) continue;
            v.refreshPositionAndAngles(x + 0.5, y, z + 0.5, R.nextFloat() * 360f, 0f);
            v.setCustomName(Text.literal("§6Боец «" + crew + "»"));
            v.setCustomNameVisible(true);
            v.addCommandTag(THUG);
            v.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_AXE));
            v.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
            v.setPersistent();
            v.setTarget(p);
            w.spawnEntity(v);
        }
    }

    public static void onDeath(LivingEntity e, DamageSource src) {
        if (e.getCommandTags().contains(THUG) && src.getAttacker() instanceof ServerPlayerEntity sp) {
            RapState st = RapState.get(sp.getServer());
            RapState.Stats a = st.of(sp.getUuid());
            a.cred += 1;
            a.addHype(5);
            st.markDirty();
            sp.sendMessage(Text.literal("§6Боец повержен. §e+1 авторитета, +5 хайпа"), true);
            if (R.nextInt(100) < 25) Crime.addWanted(sp, a, 1);
        }
    }

    // ---------- PvP ----------
    private static int power(RapState.Stats a) { return a.hype / 20 + a.cred + a.loyalty / 5 + Shop.style(a) + bestQuality(a) * 2; }

    public static void request(ServerPlayerEntity from, ServerPlayerEntity to) {
        if (from == to) { Gui.say(from, "§7Бифовать с самим собой — это терапия."); return; }
        REQ.put(to.getUuid(), from.getUuid());
        Gui.say(from, "§cВызов отправлен: " + to.getName().getString());
        to.sendMessage(Text.literal("§c" + from.getName().getString() + " вызывает тебя на баттл ")
                .append(Text.literal("§a[ПРИНЯТЬ]").setStyle(Style.EMPTY.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/rap beef accept")))));
    }

    public static void accept(ServerPlayerEntity to) {
        MinecraftServer s = to.getServer();
        UUID fid = REQ.remove(to.getUuid());
        ServerPlayerEntity from = fid == null ? null : s.getPlayerManager().getPlayer(fid);
        if (from == null) { Gui.say(to, "§7Вызовов нет."); return; }
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(from.getUuid()), b = st.of(to.getUuid());
        long now = s.getOverworld().getTime();
        if (now - a.lastBeef < 3600 || now - b.lastBeef < 3600) { Gui.say(to, "§7Оба должны отдохнуть: баттл не чаще раза в 3 минуты."); return; }
        a.lastBeef = now;
        b.lastBeef = now;
        int sa = power(a) + R.nextInt(30), sb = power(b) + R.nextInt(30);
        String na = from.getName().getString(), nb = to.getName().getString();
        CompletableFuture<List<String>> fa = diss(na, nb, "флоу"), fb = diss(nb, na, "флоу");
        CompletableFuture.allOf(fa, fb).thenRun(() -> s.execute(() -> {
            boolean aWin = sa >= sb;
            String[] msg = {"§6=== Баттл: " + na + " vs " + nb + " ===", "§f" + na + ": " + String.join(" / ", fa.join()),
                    "§f" + nb + ": " + String.join(" / ", fb.join()), "§eСчёт: " + sa + " : " + sb + " §a— победил " + (aWin ? na : nb)};
            for (ServerPlayerEntity x : List.of(from, to)) for (String m : msg) x.sendMessage(Text.literal(m));
            RapState.Stats w = aWin ? a : b, l = aWin ? b : a;
            w.addHype(50); w.followers += 120; w.beefWins++;
            l.addHype(-20); l.addLoyalty(-4); l.beefLosses++;
            st.markDirty();
        }));
    }
}
