package ru.raplife;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.AllayEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.*;

/** Интерактивный концерт: 5 раундов с выбором, толпа фанатов-аллэев, итоговый ранг в духе MGS. */
public final class Concert {
    private static class Session { int round, score, idx; boolean club; Set<UUID> audience = new HashSet<>(); String venue; long start; List<AllayEntity> crowd = new ArrayList<>(); }
    private static final Map<UUID, Session> S = new HashMap<>();
    private static final Random R = new Random();
    private static final String[] VENUES = {"Подвал на районе", "Клуб «Бетон»", "Арена «Кристалл»", "Дворец спорта «Квант»", "Стадион «Мегаполис»"};
    private static final int[] BASE = {60, 200, 500, 1200, 3000};
    private static final String[] TIER = {"D", "C", "B", "A", "S"};
    private static final String[] TIER_NAME = {"Крыса", "Хамелеон", "Сова", "Лис", "Большой Босс"};
    private static final double[] MULT = {0.3, 0.6, 1.0, 1.5, 2.0};
    private static final int[] HYPE = {5, 15, 30, 50, 70};

    public static boolean active(UUID id) { return S.containsKey(id); }

    public static void abort(UUID id) {
        Session s = S.remove(id);
        if (s != null) for (AllayEntity e : s.crowd) e.discard();
    }

    public static void expire(MinecraftServer srv) {
        long now = srv.getOverworld().getTime();
        List<UUID> dead = new ArrayList<>();
        for (Map.Entry<UUID, Session> e : S.entrySet()) if (now - e.getValue().start > 6000) dead.add(e.getKey());
        for (UUID id : dead) abort(id);
    }

    public static void start(ServerPlayerEntity p) {
        MinecraftServer srv = p.getServer();
        RapState st = RapState.get(srv);
        RapState.Stats a = st.of(p.getUuid());
        long now = srv.getOverworld().getTime();
        if (S.containsKey(p.getUuid())) { p.sendMessage(Text.literal("§7Ты уже на сцене!")); return; }
        if (Choices.hasPending(p.getUuid())) { p.sendMessage(Text.literal("§7Сначала ответь на текущий диалог.")); return; }
        if (a.hype < 100) { p.sendMessage(Text.literal("§7Концерты — с 100 хайпа.")); return; }
        if (now - a.lastConcert < 6000) { p.sendMessage(Text.literal("§7Тур ещё не закончился. Отдохни.")); return; }
        if (a.wanted >= 4) { p.sendMessage(Text.literal("§cПлощадку оцепил Патруль!")); Crime.spawnPatrol(p, 2); return; }
        a.lastConcert = now;
        Session s = new Session();
        s.idx = RapState.stageIndex(a.hype);
        s.venue = VENUES[s.idx];
        s.start = now;
        s.club = Structures.inside(p, "club");
        if (s.club) { s.score += 2; s.venue = s.venue + " (твой клуб)"; }
        ServerWorld w = p.getServerWorld();
        for (int i = 0; i < 4 + s.idx * 2; i++) {
            AllayEntity al = EntityType.ALLAY.create(w);
            if (al == null) continue;
            double ang = R.nextDouble() * Math.PI * 2, d = 3 + R.nextDouble() * 4;
            al.refreshPositionAndAngles(p.getX() + Math.cos(ang) * d, p.getY() + 1 + R.nextDouble() * 2, p.getZ() + Math.sin(ang) * d, 0, 0);
            al.setCustomName(Text.literal("Фанат").formatted(Formatting.LIGHT_PURPLE));
            al.setInvulnerable(true);
            al.setPersistent();
            w.spawnEntity(al);
            s.crowd.add(al);
        }
        S.put(p.getUuid(), s);
        Players.announceConcert(p, s.venue);
        Story.title(p, s.venue, "Концерт начинается");
        round(p, s);
    }

    /** Игрок приходит зрителем на концерт другого игрока: бонус к счёту и гонорару исполнителя. */
    public static void attend(ServerPlayerEntity v, ServerPlayerEntity perf) {
        Session s = S.get(perf.getUuid());
        if (s == null) { Gui.say(v, "§7Концерт уже закончился."); return; }
        if (v == perf) { Gui.say(v, "§7Ты и так на сцене."); return; }
        if (s.audience.size() >= 12 && !s.audience.contains(v.getUuid())) { Gui.say(v, "§7В зале нет мест."); return; }
        s.audience.add(v.getUuid());
        v.teleport(perf.getServerWorld(), perf.getX() + 2, perf.getY(), perf.getZ(), v.getYaw(), v.getPitch());
        Gui.say(v, "§dТы в зале на концерте " + perf.getName().getString() + "! Останься до конца — получишь хайп.");
        Gui.say(perf, "§d" + v.getName().getString() + " пришёл на твой концерт. §7Зрителей: " + s.audience.size());
    }

    private static void step(ServerPlayerEntity q, Session s, String msg) {
        RapState.get(q.getServer()).markDirty();
        q.sendMessage(Text.literal("§b" + msg));
        round(q, s);
    }

    private static void round(ServerPlayerEntity p, Session s) {
        if (S.get(p.getUuid()) != s) return;
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        s.round++;
        if (s.round > 5) { finish(p, s, st, a); return; }
        ServerWorld w = p.getServerWorld();
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.PLAYERS, 1f, 0.8f + R.nextFloat() * 0.5f);
        w.spawnParticles(ParticleTypes.NOTE, p.getX(), p.getY() + 2, p.getZ(), 10, 1.5, 0.5, 1.5, 1.0);
        List<String> head = List.of("§7Раунд " + s.round + "/5 · Счёт: §e" + s.score);
        switch (s.round) {
            case 1, 2 -> Choices.offer(p, "Сцена · " + s.venue, head,
                    Choices.opt("Старый хит", q -> { s.score += 2 + a.cred / 15; step(q, s, "Зал подпевает каждое слово."); }),
                    Choices.opt("Новый трек (риск)", q -> {
                        if (R.nextInt(100) < 40 + a.loyalty / 3) { s.score += 4; step(q, s, "Зал взорвался!"); }
                        else { a.addLoyalty(-2); step(q, s, "Тишина. Кто-то кашляет."); } }),
                    Choices.opt("Выйти в зал", q -> { s.score += 2; a.addLoyalty(2); step(q, s, "Ты тянешь руку — зал тянет в ответ."); }));
            case 3 -> Choices.offer(p, "Сцена · Ведомство в зале", List.of(head.get(0), "В третьем ряду человек в сером. Он что-то записывает."),
                    Choices.opt("Политический куплет", q -> { s.score += 4; a.addHype(10); a.repGov -= 8; if (R.nextInt(100) < 30) Crime.addWanted(q, a, 1); step(q, s, "Зал аплодирует стоя. Человек в сером ушёл звонить."); }),
                    Choices.opt("Играть по методичке", q -> { s.score += 1; a.repGov += 4; a.addMoney(100); step(q, s, "Безопасно. Скучно. +100 ₽ от спонсора."); }),
                    Choices.opt("Посвятить трек фанатам", q -> { s.score += 3; a.addLoyalty(4); step(q, s, "Передние ряды плачут. Человек в сером тоже моргнул."); }));
            case 4 -> RapAi.speak(p, "Голос из зала", "Ты — голос из толпы на концерте рэпера. Кричишь странное, трогательное или смешное.",
                    "Кто-то из зала кричит рэперу между треками.",
                    new String[]{"Сыграй то, что ты ещё не написал!", "Мама, я тут!"},
                    () -> Choices.offer(p, "Сцена · Бис близко", head,
                            Choices.opt("Стейдждайв", q -> { if (a.loyalty >= 50) { s.score += 5; step(q, s, "Тебя подхватили сотни рук."); } else { s.score -= 2; a.addLoyalty(-3); step(q, s, "Тебя не поймали. Больно, но зал уважает."); } }),
                            Choices.opt("Припев на весь зал", q -> { s.score += 3; step(q, s, "Зал поёт без тебя."); }),
                            Choices.opt("Минута тишины", q -> { s.score += 2; a.addHype(5); step(q, s, "Зал замер. Где-то в телефонах моргнул Алгоритм."); })));
            default -> Choices.offer(p, "Сцена · Бис", head,
                    Choices.opt("Главный трек", q -> { s.score += 3 + a.hype / 400; step(q, s, "Лучшая версия за ночь."); }),
                    Choices.opt("Выключить микрофон — пусть поёт зал", q -> { if (a.loyalty >= 60) { s.score += 4; step(q, s, "Зал спел всё сам. Ты просто стоял."); } else { s.score += 1; step(q, s, "Зал не знал слов."); } }),
                    Choices.opt("Раздать автографы", q -> { s.score += 2; a.addLoyalty(3); step(q, s, "Очередь тянется до выхода."); }));
        }
    }

    private static void finish(ServerPlayerEntity p, Session s, RapState st, RapState.Stats a) {
        S.remove(p.getUuid());
        for (AllayEntity e : s.crowd) e.discard();
        int aud = 0;
        for (UUID uid : s.audience) {
            ServerPlayerEntity g = p.getServer().getPlayerManager().getPlayer(uid);
            if (g == null) continue;
            aud++;
            RapState.Stats ga = st.of(uid);
            ga.addHype(4);
            ga.followers += 2;
            Gui.say(g, "§dТы был на концерте " + p.getName().getString() + ". §e+4 хайпа");
        }
        s.score += Math.min(5, aud);
        int t = s.score >= 18 ? 4 : s.score >= 14 ? 3 : s.score >= 10 ? 2 : s.score >= 6 ? 1 : 0;
        int pay = (int) (BASE[s.idx] * MULT[t]) * (100 + Shop.style(a) + CrewSys.bonusPct(st, a)) / 100;
        if (s.club) pay = pay * 125 / 100;
        pay = pay * (100 + 5 * aud) / 100;
        a.addMoney(pay);
        a.addHype(HYPE[t]);
        a.followers += HYPE[t] * 3;
        a.repStreet += 2;
        if (t >= 3) a.cred += 2;
        if (t == 4) Story.unlockTape(p, a, 6);
        CrewSys.addRep(st, a, t >= 2 ? 2 : 1);
        Missions.onEvent(p, 2, t >= 2 ? 1 : 0);
        st.markDirty();
        Story.title(p, "Ранг " + TIER[t], "«" + TIER_NAME[t] + "»");
        p.sendMessage(Text.literal("§6=== Итоги концерта · " + s.venue + " ==="));
        p.sendMessage(Text.literal("§eРанг: §f" + TIER[t] + " «" + TIER_NAME[t] + "» §7(счёт " + s.score + ")"));
        p.sendMessage(Text.literal("§aГонорар: +" + pay + " ₽  §eХайп: +" + HYPE[t]));
    }
}
