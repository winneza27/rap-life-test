package ru.raplife;

import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.enums.BedPart;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.*;

/**
 * Постройки: дома, студия, клуб, штаб crew, офис лейбла, гараж, мерч-лавка.
 * Строятся блоками прямо в мире перед игроком (вход с северной стороны), последнюю постройку можно отменить.
 */
public final class Structures {
    public record Spec(String id, String name, int price, Item icon, String desc, int w, int d, int h) {}

    public static final List<Spec> SPECS = List.of(
            new Spec("house1", "Комната в общаге", 0, Items.OAK_DOOR, "Твой первый дом (купить в магазине)", 7, 7, 6),
            new Spec("house2", "Квартира в центре", 0, Items.IRON_DOOR, "Два этажа, стеклянные окна", 11, 9, 11),
            new Spec("house3", "Лофт-студия", 0, Items.BRICKS, "Кирпич, колонки, диван, два этажа", 15, 11, 11),
            new Spec("house4", "Особняк на холме", 0, Items.GOLD_BLOCK, "Три этажа, золотые пластинки, бассейн на крыше", 21, 15, 16),
            new Spec("studio", "Студия звукозаписи", 5000, Items.NOTE_BLOCK, "Внутри: запись вдвое чаще и +2 к качеству", 11, 9, 7),
            new Spec("club", "Клуб со сценой", 15000, Items.JUKEBOX, "Концерты внутри: +25% гонорара и бонус к счёту", 19, 15, 9),
            new Spec("hq", "Штаб crew", 3000, Items.WHITE_BANNER, "Оплата из общака, +5% бонуса crew", 13, 11, 11),
            new Spec("label", "Офис лейбла", 20000, Items.GOLD_INGOT, "Нужен для подписания контрактов", 15, 13, 15),
            new Spec("garage", "Гараж", 3000, Items.IRON_HORSE_ARMOR, "Машины появляются прямо в гараже", 11, 9, 7),
            new Spec("merch", "Мерч-лавка", 6000, Items.LEATHER_CHESTPLATE, "Пассивно: +25 ₽/мин и подписчики", 9, 7, 6));

    private static final class Undo {
        ServerWorld w;
        Map<BlockPos, BlockState> blocks;
        List<UUID> labels;
        String key;
    }
    private static final Map<UUID, Undo> UNDO = new HashMap<>();

    private static String key(String id) { return id.startsWith("house") ? "house" : id; }

    public static boolean inside(ServerPlayerEntity p, String id) {
        int[] b = RapState.get(p.getServer()).of(p.getUuid()).builds.get(id);
        if (b == null) return false;
        return p.getX() >= b[0] && p.getX() < b[0] + b[3] && p.getZ() >= b[2] && p.getZ() < b[2] + b[4]
                && p.getY() >= b[1] && p.getY() < b[1] + b[5];
    }

    // ---------- GUI ----------
    public static void openGui(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        Gui.Builder b = new Gui.Builder("Стройка", 4);
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};
        for (int i = 0; i < SPECS.size(); i++) {
            Spec sp = SPECS.get(i);
            String why = requirement(st, a, sp);
            int[] built = a.builds.get(key(sp.id()));
            boolean ok = why == null;
            b.set(slots[i], Gui.icon(sp.icon(), (ok ? "§a" : "§8") + sp.name(), "§7" + sp.desc(),
                    "§7Размер: §f" + sp.w() + "×" + sp.d() + " §7высота ~" + sp.h(),
                    sp.price() > 0 ? "§eЦена: " + sp.price() + " ₽" + (sp.id().equals("hq") ? " (из общака)" : "") : "§eБесплатно (уже куплено)",
                    ok ? (built != null && sp.price() > 0 ? "§aПостроено. Можно перестроить бесплатно" : "§eКлик — построить") : "§c" + why),
                    ok ? q -> confirm(q, sp) : null);
        }
        b.set(23, Gui.icon(Items.BARRIER, "§cОтменить последнюю постройку", "§7Вернёт землю как было", "§7Деньги не возвращаются"), q -> { q.closeHandledScreen(); undo(q); });
        b.set(25, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(p);
    }

    private static String requirement(RapState st, RapState.Stats a, Spec sp) {
        switch (sp.id()) {
            case "house1", "house2", "house3", "house4" -> { return a.owned.contains(sp.id()) ? null : "Сначала купи в магазине"; }
            case "studio", "merch" -> { return a.hype >= 100 ? null : "Нужно 100 хайпа"; }
            case "club", "label" -> { return a.hype >= 300 ? null : "Нужно 300 хайпа"; }
            case "hq" -> { return st.crewOf(a) == null ? "Нужен crew" : null; }
            case "garage" -> {
                for (String id : new String[]{"car1", "car2", "car3"}) if (a.owned.contains(id)) return null;
                return "Нужна хотя бы одна машина";
            }
            default -> { return null; }
        }
    }

    private static void confirm(ServerPlayerEntity p, Spec sp) {
        Gui.Builder b = new Gui.Builder("Построить: " + sp.name(), 3);
        b.set(11, Gui.icon(Items.EMERALD, "§aПостроить здесь",
                "§7Площадка " + sp.w() + "×" + sp.d() + " начнётся на 2 блока §fюжнее §7тебя", "§7Вход будет с северной стороны (к тебе)",
                "§cВсё на площадке будет заменено!", "§7Потом можно отменить"), q -> { q.closeHandledScreen(); build(q, sp.id()); });
        b.set(13, Gui.icon(sp.icon(), "§f" + sp.name(), "§7" + sp.desc()), null);
        b.set(15, Gui.icon(Items.BARRIER, "§cОтмена"), Structures::openGui);
        b.frame().open(p);
    }

    // ---------- стройка ----------
    public static void build(ServerPlayerEntity p, String id) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        Spec sp = null;
        for (Spec s : SPECS) if (s.id().equals(id)) sp = s;
        if (sp == null) return;
        String why = requirement(st, a, sp);
        if (why != null) { Gui.say(p, "§c" + why); return; }
        String k = key(id);
        boolean first = !a.builds.containsKey(k);
        RapState.Crew crew = id.equals("hq") ? st.crewOf(a) : null;
        if (id.equals("hq")) {
            RapState.Member me = crew.members.get(p.getUuid());
            if (me == null || me.rank < 2) { Gui.say(p, "§7Штаб ставят Старшие и Лидер."); return; }
            if (crew.hq == null) {
                if (crew.treasury < sp.price()) { Gui.say(p, "§cВ общаке нужно " + sp.price() + " ₽."); return; }
                crew.treasury -= sp.price();
            }
        } else if (first && sp.price() > 0) {
            if (a.money < sp.price()) { Gui.say(p, "§cНужно " + sp.price() + " ₽."); return; }
            a.addMoney(-sp.price());
        }

        ServerWorld w = p.getServerWorld();
        int y0 = p.getBlockY() - 1;
        int x0 = p.getBlockX() - sp.w() / 2;
        int z0 = p.getBlockZ() + 2;
        Map<BlockPos, BlockState> undo = new HashMap<>();
        B b = new B(w, x0, y0, z0, undo);
        int W = sp.w(), D = sp.d();

        b.fill(-1, 1, -1, W, sp.h() + 2, D, Blocks.AIR);
        for (int x = 0; x < W; x++)
            for (int z = 0; z < D; z++)
                for (int dy = -1; dy >= -4; dy--) {
                    BlockPos bp = new BlockPos(x0 + x, y0 + dy, z0 + z);
                    BlockState cur = w.getBlockState(bp);
                    if (cur.isAir() || !cur.getFluidState().isEmpty()) b.set(x, dy, z, Blocks.STONE_BRICKS);
                }

        switch (id) {
            case "house1" -> house1(b);
            case "house2" -> house2(b);
            case "house3" -> house3(b);
            case "house4" -> house4(b);
            case "studio" -> studio(b);
            case "club" -> club(b);
            case "hq" -> hq(b);
            case "label" -> label(b);
            case "garage" -> garage(b);
            default -> merch(b);
        }
        b.tag(x0 + W / 2.0, y0 + sp.h(), z0 + D / 2.0, "§6§l" + sp.name());

        int[] bounds = {x0, y0, z0, W, D, sp.h()};
        if (id.equals("hq")) crew.hq = bounds; else a.builds.put(k, bounds);
        if (id.startsWith("house")) { a.homeSet = 1; a.homeX = x0 + W / 2; a.homeY = p.getBlockY(); a.homeZ = z0 - 1; }
        Undo u = new Undo();
        u.w = w; u.blocks = undo; u.labels = b.labels; u.key = id.equals("hq") ? "hq" : k;
        UNDO.put(p.getUuid(), u);
        st.markDirty();
        Gui.say(p, "§aПостроено: " + sp.name() + " §7(X " + x0 + ".." + (x0 + W - 1) + ", Z " + z0 + ".." + (z0 + D - 1) + "). Вход с севера."
                + (id.startsWith("house") ? " Точка дома сохранена." : ""));
    }

    public static void undo(ServerPlayerEntity p) {
        Undo u = UNDO.remove(p.getUuid());
        if (u == null) { Gui.say(p, "§7Нечего отменять."); return; }
        for (Map.Entry<BlockPos, BlockState> e : u.blocks.entrySet()) u.w.setBlockState(e.getKey(), e.getValue(), Block.NOTIFY_LISTENERS);
        for (UUID id : u.labels) { Entity e = u.w.getEntity(id); if (e != null) e.discard(); }
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (u.key.equals("hq")) { RapState.Crew c = st.crewOf(a); if (c != null) c.hq = null; }
        else a.builds.remove(u.key);
        st.markDirty();
        Gui.say(p, "§7Постройка отменена, местность восстановлена.");
    }

    // ---------- кисть ----------
    private static final class B {
        final ServerWorld w;
        final int x0, y0, z0;
        final Map<BlockPos, BlockState> undo;
        final List<UUID> labels = new ArrayList<>();

        B(ServerWorld w, int x0, int y0, int z0, Map<BlockPos, BlockState> undo) {
            this.w = w; this.x0 = x0; this.y0 = y0; this.z0 = z0; this.undo = undo;
        }

        void set(int dx, int dy, int dz, BlockState s) {
            BlockPos p = new BlockPos(x0 + dx, y0 + dy, z0 + dz);
            undo.putIfAbsent(p, w.getBlockState(p));
            w.setBlockState(p, s, Block.NOTIFY_LISTENERS);
        }

        void set(int dx, int dy, int dz, Block b) { set(dx, dy, dz, b.getDefaultState()); }

        void fill(int x1, int y1, int z1, int x2, int y2, int z2, Block blk) {
            BlockState s = blk.getDefaultState();
            for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
                for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                    for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) set(x, y, z, s);
        }

        /** Коробка: пол на y=0, стены y=1..H, потолок на y=H+1. */
        void shell(int W, int D, int H, Block wall, Block floor, Block ceil) {
            fill(0, 0, 0, W - 1, 0, D - 1, floor);
            fill(0, 1, 0, W - 1, H, 0, wall);
            fill(0, 1, D - 1, W - 1, H, D - 1, wall);
            fill(0, 1, 0, 0, H, D - 1, wall);
            fill(W - 1, 1, 0, W - 1, H, D - 1, wall);
            fill(0, H + 1, 0, W - 1, H + 1, D - 1, ceil);
        }

        void windows(int W, int D, int y1, int y2, Block g) {
            for (int x = 2; x <= W - 3; x += 3) { fill(x, y1, 0, x, y2, 0, g); fill(x, y1, D - 1, x, y2, D - 1, g); }
            for (int z = 2; z <= D - 3; z += 3) { fill(0, y1, z, 0, y2, z, g); fill(W - 1, y1, z, W - 1, y2, z, g); }
        }

        /** Этажи по 4 блока; лестница-стремянка в углу (1,*,1). */
        void floors(int W, int D, int n, Block floor) {
            BlockState lad = Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.SOUTH);
            for (int f = 1; f < n; f++) fill(1, f * 4, 1, W - 2, f * 4, D - 2, floor);
            for (int y = 1; y <= n * 4 - 1; y++) set(1, y, 1, lad);
        }

        void lights(int W, int D, int n) {
            for (int f = 1; f <= n; f++) { set(W / 4, f * 4 - 1, D / 2, Blocks.SEA_LANTERN); set(3 * W / 4, f * 4 - 1, D / 2, Blocks.SEA_LANTERN); }
        }

        void parapet(int W, int D, int y, Block blk) {
            fill(0, y, 0, W - 1, y, 0, blk); fill(0, y, D - 1, W - 1, y, D - 1, blk);
            fill(0, y, 0, 0, y, D - 1, blk); fill(W - 1, y, 0, W - 1, y, D - 1, blk);
        }

        void bed(int x, int y, int z, Direction d, Block bed) {
            set(x, y, z, bed.getDefaultState().with(BedBlock.FACING, d).with(BedBlock.PART, BedPart.FOOT));
            set(x + d.getOffsetX(), y, z + d.getOffsetZ(), bed.getDefaultState().with(BedBlock.FACING, d).with(BedBlock.PART, BedPart.HEAD));
        }

        void sofa(int x1, int x2, int y, int z, Direction face, Block stairs) {
            for (int x = x1; x <= x2; x++) set(x, y, z, stairs.getDefaultState().with(StairsBlock.FACING, face));
        }

        void tag(double x, double y, double z, String text) {
            ArmorStandEntity as = EntityType.ARMOR_STAND.create(w);
            if (as == null) return;
            as.refreshPositionAndAngles(x, y, z, 0f, 0f);
            as.setInvisible(true);
            as.setNoGravity(true);
            as.setInvulnerable(true);
            as.setCustomName(Text.literal(text));
            as.setCustomNameVisible(true);
            as.addCommandTag("raplife_label");
            w.spawnEntity(as);
            labels.add(as.getUuid());
        }
    }

    // ---------- проекты ----------
    private static void house1(B b) {
        b.shell(7, 7, 3, Blocks.STONE_BRICKS, Blocks.SPRUCE_PLANKS, Blocks.STONE_BRICKS);
        b.windows(7, 7, 2, 2, Blocks.GLASS_PANE);
        b.fill(3, 1, 0, 3, 2, 0, Blocks.AIR);
        b.set(3, 3, 3, Blocks.SEA_LANTERN);
        b.bed(1, 1, 4, Direction.SOUTH, Blocks.RED_BED);
        b.set(5, 1, 5, Blocks.JUKEBOX);
        b.set(5, 1, 1, Blocks.CRAFTING_TABLE);
        b.set(5, 2, 1, Blocks.LANTERN);
        b.fill(1, 1, 1, 1, 2, 1, Blocks.BOOKSHELF);
    }

    private static void house2(B b) {
        int W = 11, D = 9;
        b.shell(W, D, 7, Blocks.LIGHT_GRAY_CONCRETE, Blocks.OAK_PLANKS, Blocks.LIGHT_GRAY_CONCRETE);
        b.floors(W, D, 2, Blocks.OAK_PLANKS);
        b.windows(W, D, 2, 3, Blocks.GLASS_PANE);
        b.windows(W, D, 6, 7, Blocks.GLASS_PANE);
        b.fill(5, 1, 0, 5, 2, 0, Blocks.AIR);
        b.lights(W, D, 2);
        b.set(8, 1, 6, Blocks.JUKEBOX);
        b.fill(9, 1, 6, 9, 2, 6, Blocks.NOTE_BLOCK);
        b.set(8, 1, 1, Blocks.CRAFTING_TABLE);
        b.sofa(4, 6, 1, 6, Direction.NORTH, Blocks.QUARTZ_STAIRS);
        b.bed(6, 5, 6, Direction.SOUTH, Blocks.BLUE_BED);
        b.fill(9, 5, 1, 9, 6, 1, Blocks.BOOKSHELF);
        b.parapet(W, D, 9, Blocks.LIGHT_GRAY_CONCRETE);
        b.set(0, 10, 0, Blocks.LANTERN); b.set(W - 1, 10, 0, Blocks.LANTERN);
        b.set(0, 10, D - 1, Blocks.LANTERN); b.set(W - 1, 10, D - 1, Blocks.LANTERN);
    }

    private static void house3(B b) {
        int W = 15, D = 11;
        b.shell(W, D, 7, Blocks.BRICKS, Blocks.POLISHED_ANDESITE, Blocks.BRICKS);
        for (int[] c : new int[][]{{0, 0}, {W - 1, 0}, {0, D - 1}, {W - 1, D - 1}}) b.fill(c[0], 1, c[1], c[0], 7, c[1], Blocks.BLACK_CONCRETE);
        b.floors(W, D, 2, Blocks.DARK_OAK_PLANKS);
        b.windows(W, D, 2, 3, Blocks.GLASS);
        b.windows(W, D, 6, 7, Blocks.GLASS);
        b.fill(7, 1, 0, 7, 2, 0, Blocks.AIR);
        b.lights(W, D, 2);
        for (int x : new int[]{3, W - 4}) { b.set(x, 1, D - 3, Blocks.BLACK_WOOL); b.set(x, 2, D - 3, Blocks.NOTE_BLOCK); b.set(x, 3, D - 3, Blocks.BLACK_WOOL); }
        b.set(7, 1, D - 3, Blocks.JUKEBOX);
        b.sofa(5, 9, 1, 5, Direction.SOUTH, Blocks.QUARTZ_STAIRS);
        b.bed(4, 5, 8, Direction.SOUTH, Blocks.PURPLE_BED);
        b.bed(10, 5, 8, Direction.SOUTH, Blocks.PURPLE_BED);
        b.fill(3, 5, 1, 7, 5, 1, Blocks.SMOOTH_QUARTZ);
        b.set(5, 6, 1, Blocks.LANTERN);
        b.parapet(W, D, 9, Blocks.BLACK_CONCRETE);
    }

    private static void house4(B b) {
        int W = 21, D = 15;
        b.shell(W, D, 11, Blocks.WHITE_CONCRETE, Blocks.POLISHED_DIORITE, Blocks.QUARTZ_BLOCK);
        for (int[] c : new int[][]{{0, 0}, {W - 1, 0}, {0, D - 1}, {W - 1, D - 1}}) b.fill(c[0], 1, c[1], c[0], 11, c[1], Blocks.QUARTZ_PILLAR);
        b.floors(W, D, 3, Blocks.QUARTZ_BLOCK);
        b.windows(W, D, 2, 3, Blocks.GLASS);
        b.windows(W, D, 6, 7, Blocks.GLASS);
        b.windows(W, D, 10, 11, Blocks.GLASS);
        b.fill(9, 1, 0, 11, 3, 0, Blocks.AIR);
        b.lights(W, D, 3);
        b.fill(4, 1, 2, 4, 3, 2, Blocks.QUARTZ_PILLAR);
        b.fill(W - 5, 1, 2, W - 5, 3, 2, Blocks.QUARTZ_PILLAR);
        for (int x = 3; x <= W - 4; x += 3) b.set(x, 2, D - 2, Blocks.GOLD_BLOCK);
        b.set(W - 4, 1, 10, Blocks.JUKEBOX);
        b.fill(W - 4, 1, 9, W - 4, 2, 9, Blocks.NOTE_BLOCK);
        b.sofa(7, 13, 1, 6, Direction.SOUTH, Blocks.QUARTZ_STAIRS);
        for (int x : new int[]{4, 8, 12}) b.bed(x, 5, 11, Direction.SOUTH, Blocks.PINK_BED);
        for (int x : new int[]{5, 15}) b.bed(x, 9, 11, Direction.SOUTH, Blocks.WHITE_BED);
        b.fill(3, 5, 1, 7, 6, 1, Blocks.BOOKSHELF);
        b.fill(3, 9, 1, 7, 10, 1, Blocks.BOOKSHELF);
        b.parapet(W, D, 13, Blocks.QUARTZ_BLOCK);
        b.fill(4, 13, 3, W - 5, 13, D - 4, Blocks.QUARTZ_BLOCK);
        b.fill(5, 13, 4, W - 6, 13, D - 5, Blocks.WATER);
        for (int x = 7; x <= W - 8; x += 4) for (int z = 5; z <= D - 6; z += 3) b.set(x, 12, z, Blocks.SEA_LANTERN);
    }

    private static void studio(B b) {
        int W = 11, D = 9;
        b.shell(W, D, 4, Blocks.BLACK_CONCRETE, Blocks.POLISHED_BLACKSTONE, Blocks.BLACK_CONCRETE);
        b.fill(5, 1, 0, 5, 2, 0, Blocks.AIR);
        b.set(5, 3, 0, Blocks.RED_CONCRETE);
        b.fill(1, 1, 4, W - 2, 3, 4, Blocks.GLASS);
        b.fill(2, 1, 4, 2, 2, 4, Blocks.AIR);
        b.fill(3, 1, 2, 7, 1, 2, Blocks.NOTE_BLOCK);
        b.set(5, 2, 2, Blocks.LANTERN);
        b.fill(1, 1, 5, 1, 3, 7, Blocks.GRAY_WOOL);
        b.fill(W - 2, 1, 5, W - 2, 3, 7, Blocks.GRAY_WOOL);
        b.fill(5, 1, 6, 5, 2, 6, Blocks.END_ROD);
        b.set(W - 4, 1, 6, Blocks.JUKEBOX);
        for (int x : new int[]{3, 7}) for (int z : new int[]{2, 6}) b.set(x, 4, z, Blocks.SEA_LANTERN);
    }

    private static void club(B b) {
        int W = 19, D = 15;
        b.shell(W, D, 6, Blocks.BLACK_CONCRETE, Blocks.BLACK_CONCRETE, Blocks.BLACK_CONCRETE);
        Block[] cols = {Blocks.MAGENTA_CONCRETE, Blocks.CYAN_CONCRETE, Blocks.LIME_CONCRETE, Blocks.ORANGE_CONCRETE};
        for (int x = 1; x <= W - 2; x++) for (int z = 1; z <= D - 6; z++) b.set(x, 0, z, cols[(x + z) % 4]);
        b.fill(8, 1, 0, 10, 3, 0, Blocks.AIR);
        b.fill(6, 4, 0, 12, 4, 0, Blocks.MAGENTA_CONCRETE);
        b.fill(3, 1, D - 5, W - 4, 1, D - 2, Blocks.POLISHED_BLACKSTONE);
        for (int x = 3; x <= W - 4; x += 2) b.set(x, 0, D - 6, Blocks.SEA_LANTERN);
        for (int x : new int[]{4, W - 5}) { b.set(x, 2, D - 3, Blocks.BLACK_WOOL); b.set(x, 3, D - 3, Blocks.NOTE_BLOCK); b.set(x, 4, D - 3, Blocks.BLACK_WOOL); }
        b.set(W / 2, 2, D - 3, Blocks.JUKEBOX);
        for (int x = 3; x <= W - 4; x += 4) for (int z = 3; z <= D - 4; z += 4) b.set(x, 6, z, Blocks.SEA_LANTERN);
        b.fill(W - 3, 1, 2, W - 3, 1, 7, Blocks.BARREL);
        b.fill(W - 3, 2, 2, W - 3, 2, 7, Blocks.POLISHED_BLACKSTONE_SLAB);
        b.fill(W - 2, 1, 2, W - 2, 3, 7, Blocks.BOOKSHELF);
    }

    private static void hq(B b) {
        int W = 13, D = 11;
        b.shell(W, D, 7, Blocks.DEEPSLATE_BRICKS, Blocks.DARK_OAK_PLANKS, Blocks.DEEPSLATE_BRICKS);
        b.floors(W, D, 2, Blocks.DARK_OAK_PLANKS);
        b.windows(W, D, 2, 3, Blocks.GLASS_PANE);
        b.windows(W, D, 6, 7, Blocks.GLASS_PANE);
        b.fill(6, 1, 0, 6, 2, 0, Blocks.AIR);
        b.fill(2, 1, D - 1, 4, 3, D - 1, Blocks.MAGENTA_CONCRETE);
        b.fill(5, 1, D - 1, 7, 3, D - 1, Blocks.CYAN_CONCRETE);
        b.fill(8, 1, D - 1, 10, 3, D - 1, Blocks.LIME_CONCRETE);
        b.lights(W, D, 2);
        b.set(W - 2, 1, 1, Blocks.CHEST);
        b.set(W - 2, 1, 2, Blocks.CHEST);
        b.set(8, 1, 8, Blocks.JUKEBOX);
        b.set(3, 1, 8, Blocks.CRAFTING_TABLE);
        b.sofa(4, 8, 1, 4, Direction.SOUTH, Blocks.DARK_OAK_STAIRS);
        for (int x : new int[]{3, 6, 9}) b.bed(x, 5, 8, Direction.SOUTH, Blocks.BLUE_BED);
        b.parapet(W, D, 9, Blocks.DEEPSLATE_BRICKS);
    }

    private static void label(B b) {
        int W = 15, D = 13;
        b.shell(W, D, 11, Blocks.GLASS, Blocks.POLISHED_DIORITE, Blocks.QUARTZ_BLOCK);
        for (int[] c : new int[][]{{0, 0}, {W - 1, 0}, {0, D - 1}, {W - 1, D - 1}}) b.fill(c[0], 1, c[1], c[0], 11, c[1], Blocks.QUARTZ_PILLAR);
        b.floors(W, D, 3, Blocks.QUARTZ_BLOCK);
        b.fill(7, 1, 0, 7, 2, 0, Blocks.AIR);
        b.lights(W, D, 3);
        for (int f = 0; f < 3; f++) for (int x = 2; x <= W - 3; x += 2) b.set(x, 2 + f * 4, D - 2, Blocks.GOLD_BLOCK);
        b.fill(4, 1, 5, 10, 1, 5, Blocks.SPRUCE_SLAB);
        b.fill(4, 5, 5, 10, 5, 5, Blocks.SPRUCE_SLAB);
        b.fill(4, 9, 5, 10, 9, 5, Blocks.SPRUCE_SLAB);
        b.set(W - 3, 1, D - 3, Blocks.JUKEBOX);
        b.fill(W - 2, 1, 2, W - 2, 3, 4, Blocks.BOOKSHELF);
        b.parapet(W, D, 13, Blocks.GLASS);
    }

    private static void garage(B b) {
        int W = 11, D = 9;
        b.shell(W, D, 4, Blocks.GRAY_CONCRETE, Blocks.BLACK_CONCRETE, Blocks.GRAY_CONCRETE);
        b.fill(3, 1, 0, 7, 3, 0, Blocks.AIR);
        b.fill(3, 0, 1, 3, 0, D - 2, Blocks.YELLOW_CONCRETE);
        b.fill(7, 0, 1, 7, 0, D - 2, Blocks.YELLOW_CONCRETE);
        for (int x : new int[]{3, 7}) for (int z : new int[]{3, 6}) b.set(x, 4, z, Blocks.SEA_LANTERN);
        b.set(1, 1, D - 2, Blocks.SMITHING_TABLE);
        b.set(2, 1, D - 2, Blocks.ANVIL);
        b.set(W - 2, 1, D - 2, Blocks.BARREL);
    }

    private static void merch(B b) {
        int W = 9, D = 7;
        b.shell(W, D, 3, Blocks.WHITE_CONCRETE, Blocks.SMOOTH_QUARTZ, Blocks.WHITE_CONCRETE);
        b.fill(1, 1, 0, 7, 2, 0, Blocks.GLASS);
        b.fill(4, 1, 0, 4, 2, 0, Blocks.AIR);
        b.fill(0, 3, 0, 8, 3, 0, Blocks.MAGENTA_CONCRETE);
        b.fill(1, 1, 5, 7, 2, 5, Blocks.BOOKSHELF);
        b.set(2, 1, 3, Blocks.PINK_WOOL); b.set(3, 1, 3, Blocks.BLACK_WOOL);
        b.set(5, 1, 3, Blocks.LIME_WOOL); b.set(6, 1, 3, Blocks.CYAN_WOOL);
        b.fill(2, 1, 1, 6, 1, 1, Blocks.BARREL);
        b.fill(2, 2, 1, 6, 2, 1, Blocks.SMOOTH_QUARTZ_SLAB);
        b.set(4, 3, 3, Blocks.SEA_LANTERN);
    }
}
