package ru.raplife;

import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

public final class PhoneMenu {
    public static void open(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        Gui.Builder b = new Gui.Builder("Телефон", 6);
        b.set(4, Gui.icon(Items.EMERALD, "§aБаланс: " + a.money + " ₽",
                "§7Грязные: §c" + a.dirty + " ₽", "§7Хайп: §f" + a.hype + "  §7Подписчики: §f" + a.followers,
                "§7Розыск: §9" + Crime.stars(a.wanted), "§7Роялти к выплате: §e" + (int) a.royalties + " ₽"), null);
        b.set(10, Gui.icon(Items.NOTE_BLOCK, "§dТикТок", "§7Лента про тебя (ИИ)"), q -> { q.closeHandledScreen(); RapAi.showFeed(q); });
        b.set(11, Gui.icon(Items.JUKEBOX, "§bСтриминг", "§7Облачко и Спотик", "§7Слушатели и выплаты"), Streaming::open);
        b.set(12, Gui.icon(Items.EMERALD, "§aМагазин", "§7Дома, машины, цепи, шмот, серый рынок"), q -> Shop.open(q, "Дом"));
        b.set(13, Gui.icon(Items.WHITE_BANNER, "§eCrew", "§7Банда, общак, ранги"), CrewSys::open);
        b.set(14, Gui.icon(Items.IRON_SWORD, "§cБифы", "§7Баттлы с рэперами"), Beef::openGui);
        b.set(15, Gui.icon(Items.BELL, "§6Помощники", "§7Менеджер, звукарь, юрист, Старший"), Npcs::openHire);
        b.set(16, Gui.icon(Items.NOTE_BLOCK, "§fСтудия", "§7Быстрая запись трека", "§7(кулдаун 2 мин, в своей студии вдвое меньше)"), q -> {
            q.closeHandledScreen(); Streaming.record(q, Streaming.randomTitle()); });
        b.set(19, Gui.icon(Items.ENDER_EYE, "§5Кодек", "§7Позвонить контактам"), q -> { q.closeHandledScreen(); Story.codec(q); });
        b.set(20, Gui.icon(Items.WRITABLE_BOOK, "§fПоручения", "§7От Старшего"), q -> { q.closeHandledScreen(); Missions.status(q); });
        b.set(21, Gui.icon(Items.RED_BED, "§cДом", "§7Телепорт домой"), q -> { q.closeHandledScreen(); Shop.home(q); });
        b.set(22, Gui.icon(Items.IRON_HORSE_ARMOR, "§bГараж", "§7Вызвать машину"), Shop::openGarage);
        b.set(23, Gui.icon(Items.BOOK, "§fСтатистика", "§7Позывной, репутация"), q -> { q.closeHandledScreen(); RapCommands.showStats(q); });
        b.set(24, Gui.icon(Items.FIREWORK_ROCKET, "§6Концерт", "§7Выйти на сцену (зрители-игроки дают бонус)"), q -> { q.closeHandledScreen(); Concert.start(q); });
        b.set(25, Gui.icon(Items.CHEST, "§8Груз", "§7Заказ от Бархата"), q -> { q.closeHandledScreen(); Crime.startRun(q); });
        b.set(28, Gui.icon(Items.BRICKS, "§6Стройка", "§7Дома, студия, клуб, штаб, офис..."), Structures::openGui);
        b.set(29, Gui.icon(Items.GOLD_INGOT, "§eЛейбл", "§7Контракты (нужен офис)"), Labels::open);
        b.set(30, Gui.icon(Items.RED_BANNER, "§4Районы", "§7Войны crew за территорию"), Districts::open);
        b.set(31, Gui.icon(Items.GOLDEN_HELMET, "§6Достижения", "§7Получено: " + a.ach.size()), Achievements::open);
        b.set(32, Gui.icon(Items.PINK_DYE, "§dИнста", "§7Посты с подписями от ИИ"), Social::open);
        b.set(33, Gui.icon(Items.PLAYER_HEAD, "§fТоп и чарт", "§7Рэперы, crew, треки сервера"), Leaderboard::open);
        b.set(37, Gui.icon(Items.PLAYER_HEAD, "§aИгроки онлайн", "§7Подписки, фиты, баттлы, переводы,", "§7подарки, концерты, вечеринки"), Players::open);
        b.set(38, Gui.icon(Items.NOTE_BLOCK, "§dВечеринка дома", "§7Открыть/закрыть двери для гостей"), q -> { q.closeHandledScreen(); Players.party(q); });
        b.set(39, Gui.icon(Items.OAK_SIGN, "§fПомощь", "§7Как играть"), q -> { q.closeHandledScreen(); Help.show(q); });
        b.set(43, Gui.icon(Items.BARRIER, "§7Закрыть"), q -> q.closeHandledScreen());
        b.frame().open(p);
    }
}
