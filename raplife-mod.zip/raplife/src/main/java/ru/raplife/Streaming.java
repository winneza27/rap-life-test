package ru.raplife;

import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Random;

/** Стриминг: треки, слушатели, прослушивания, выплаты. Облачко платит мало, Спотик — втрое больше. */
public final class Streaming {
    private static final Random R = new Random();
    public static final double RATE_CLOUD = 0.08, RATE_SPOT = 0.25;
    private static final String[] TITLES = {"Туман", "Подъезд", "Ночной бит", "Серый район", "Холодный свет",
            "Метро в три", "Пустые панели", "Эхо двора", "Лифт без кнопок", "Дым и неон"};

    public static String randomTitle() { return TITLES[R.nextInt(TITLES.length)] + " №" + (1 + R.nextInt(99)); }

    public static RapState.Track addTrack(RapState.Stats a, String title, boolean diss, long now) {
        RapState.Track t = new RapState.Track();
        t.title = title;
        t.diss = diss;
        t.bornTick = now;
        t.quality = Math.max(1, Math.min(10, 2 + a.cred / 6 + Shop.qualityBonus(a)
                + (a.npcIds.containsKey("engineer") ? 2 : 0) + R.nextInt(3)));
        a.tracks.add(0, t);
        while (a.tracks.size() > 14) a.tracks.remove(a.tracks.size() - 1);
        return t;
    }

    /** Запись трека (команда /rap track и кнопка «Студия»). */
    public static void record(ServerPlayerEntity p, String title) {
        MinecraftServer s = p.getServer();
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(p.getUuid());
        long now = s.getOverworld().getTime();
        if (now - a.lastTrack < (Structures.inside(p, "studio") ? 1200 : 2400)) {
            Gui.say(p, "§7Студия занята. Подожди " + ((2400 - (now - a.lastTrack)) / 20) + " сек.");
            return;
        }
        a.lastTrack = now;
        Gui.say(p, "§7Записываем «" + title + "»" + (Config.get().ready() ? " (ИИ пишет куплет)..." : "..."));
        RapAi.lyrics(p.getName().getString(), a.hype, title).thenAccept(lines -> s.execute(() -> {
            int gain = (20 + R.nextInt(30) + a.cred / 10) * (100 + CrewSys.bonusPct(st, a)) / 100;
            a.addHype(gain);
            a.cred += 1 + R.nextInt(3);
            a.repStreet += 1;
            a.followers += 10 + R.nextInt(30) + a.hype / 20;
            RapState.Track t = addTrack(a, title, false, now);
            if (Structures.inside(p, "studio")) t.quality = Math.min(10, t.quality + 2);
            a.labelTracks++;
            CrewSys.addRep(st, a, 1);
            st.markDirty();
            Gui.say(p, "§6♪ «" + title + "»");
            for (String l : lines) Gui.say(p, "  " + l);
            Gui.say(p, "§aТрек вышел на Облачке! §eКачество " + t.quality + "/10, +" + gain + " хайпа.");
            Missions.onEvent(p, 1, 1);
            Players.notifyFollowers(s, p, title);
        }));
    }

    /** Раз в минуту: считаем прослушивания и роялти. */
    public static void tick(MinecraftServer s) {
        RapState st = RapState.get(s);
        long now = s.getOverworld().getTime();
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            RapState.Stats a = st.of(p.getUuid());
            boolean mansion = a.owned.contains("house4");
            if (a.tracks.isEmpty() && !mansion && !a.builds.containsKey("merch")) continue;
            double crewMult = 1.0 + CrewSys.bonusPct(st, a) / 100.0 + Math.min(0.5, Players.realFans(st, p.getUuid()) * 0.05);
            long cloud = 0, spot = 0;
            for (RapState.Track t : a.tracks) {
                double age = (now - t.bornTick) / 1200.0;
                double decay = 1.0 / (1.0 + age / 45.0);
                double base = t.quality * (3 + a.followers / 30.0 + a.hype / 15.0 + a.loyalty / 10.0 + Shop.style(a) * 0.5) * decay;
                double mult = (0.7 + R.nextDouble() * 0.7) * (t.diss ? 1.4 : 1.0) * (now < t.boostUntil ? 3.0 : 1.0) * crewMult * Labels.mult(a);
                long cs = (long) (base * (t.onSpot ? 0.6 : 1.0) * mult);
                long ss = t.onSpot ? (long) (base * 0.4 * mult) : 0;
                t.streams += cs + ss;
                cloud += cs;
                spot += ss;
                a.royalties += (cs * RATE_CLOUD + ss * RATE_SPOT) * Labels.keep(a);
            }
            a.totalStreams += cloud + spot;
            a.listenersCloud = (int) (a.listenersCloud * 0.8 + cloud * 12 * 0.2);
            a.listenersSpot = (int) (a.listenersSpot * 0.8 + spot * 12 * 0.2);
            if (mansion) a.royalties += 40;
            if (a.builds.containsKey("merch")) { a.royalties += 25; a.followers += 2; }
            if (!a.tracks.isEmpty() && R.nextInt(100) < 2) {
                RapState.Track t = a.tracks.get(R.nextInt(a.tracks.size()));
                t.boostUntil = now + 12000;
                Gui.say(p, "§d[Алгоритм] §fТрек «" + t.title + "» добавлен в рекомендации. Прослушивания ×3 на 10 минут.");
            }
            // менеджер сам выводит деньги
            if (a.npcIds.containsKey("manager") && a.royalties >= 200) {
                int pay = (int) a.royalties;
                a.royalties -= pay;
                int fee = pay * 5 / 100;
                a.addMoney(pay - fee - tax(st, a, pay));
                p.sendMessage(Text.literal("§7Менеджер вывел роялти: §a+" + (pay - fee) + " ₽"), true);
            }
            Missions.onEvent(p, 4, (int) (cloud + spot));
            st.markDirty();
        }
    }

    private static int tax(RapState st, RapState.Stats a, int pay) {
        RapState.Crew c = st.crewOf(a);
        if (c == null) return 0;
        int t = pay * 5 / 100;
        c.treasury += t;
        return t;
    }

    public static void withdraw(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        int pay = (int) a.royalties;
        if (pay < 1) { Gui.say(p, "§7Пока нечего выводить."); return; }
        a.royalties -= pay;
        int t = tax(st, a, pay);
        a.addMoney(pay - t);
        st.markDirty();
        Gui.say(p, "§aВыплата роялти: +" + (pay - t) + " ₽" + (t > 0 ? " §7(5% ушло в общак crew)" : ""));
    }

    public static void improve(ServerPlayerEntity p, RapState.Track t) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (t.quality >= 10) { Gui.say(p, "§7Тут уже идеальный звук."); return; }
        if (a.money < 300) { Gui.say(p, "§cНужно 300 ₽."); return; }
        a.addMoney(-300);
        t.quality++;
        st.markDirty();
        Gui.say(p, "§aЗвукарь пересвёл «" + t.title + "». Качество: " + t.quality + "/10");
    }

    // ---------- GUI ----------
    public static void open(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        long now = p.getServer().getOverworld().getTime();
        Gui.Builder b = new Gui.Builder("Стриминг: Облачко и Спотик", 6);
        b.set(0, Gui.icon(Items.NOTE_BLOCK, "§fЗаписать трек", "§7Быстрая запись в студии"), q -> { q.closeHandledScreen(); record(q, randomTitle()); });
        b.set(2, Gui.icon(Items.MUSIC_DISC_CAT, "§bОблачко (как SoundCloud)", "§7Слушателей за месяц: §f" + a.listenersCloud,
                "§7Платит: §a" + RATE_CLOUD + " ₽ за прослушивание", "§7Любой трек попадает сюда"), null);
        b.set(4, Gui.icon(Items.EMERALD, "§aК выплате: " + (int) a.royalties + " ₽", "§7Клик — вывести на счёт",
                "§7Всего прослушиваний: §f" + a.totalStreams), q -> { withdraw(q); open(q); });
        b.set(6, Gui.icon(Items.MUSIC_DISC_PIGSTEP, "§2Спотик (как Spotify)", "§7Слушателей за месяц: §f" + a.listenersSpot,
                "§7Платит: §a" + RATE_SPOT + " ₽ за прослушивание", "§7Выпуск трека: 300 ₽, от 300 хайпа"), null);
        b.set(8, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        int[] slots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        for (int i = 0; i < a.tracks.size() && i < slots.length; i++) {
            RapState.Track t = a.tracks.get(i);
            b.set(slots[i], Gui.icon(t.diss ? Items.MUSIC_DISC_WARD : Items.MUSIC_DISC_13, "§f" + t.title,
                    "§7Качество: §e" + t.quality + "/10", "§7Прослушиваний: §f" + t.streams,
                    "§7Платформы: §f" + (t.onSpot ? "Облачко + Спотик" : "Облачко"),
                    now < t.boostUntil ? "§dВ рекомендациях ×3!" : "§8Клик — управление"), q -> trackMenu(q, t));
        }
        if (a.tracks.isEmpty()) b.set(22, Gui.icon(Items.PAPER, "§7Треков пока нет", "§7Запиши первый: кнопка в левом верхнем углу"), null);
        b.frame().open(p);
    }

    private static void trackMenu(ServerPlayerEntity p, RapState.Track t) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        Gui.Builder b = new Gui.Builder("Трек «" + t.title + "»", 3);
        if (!t.onSpot) b.set(10, Gui.icon(Items.MUSIC_DISC_PIGSTEP, "§2Выпустить в Спотик", "§7300 ₽, нужен хайп 300", "§7Платят втрое больше"), q -> {
            if (a.hype < 300) { Gui.say(q, "§cСпотик берёт от 300 хайпа."); return; }
            if (a.money < 300) { Gui.say(q, "§cНужно 300 ₽."); return; }
            a.addMoney(-300); t.onSpot = true; st.markDirty();
            Gui.say(q, "§aТрек теперь и на Спотике!");
            open(q);
        });
        b.set(12, Gui.icon(Items.FIREWORK_STAR, "§dПитчинг в плейлист", "§7500 ₽ — ×3 прослушивания на 10 минут"), q -> {
            if (a.money < 500) { Gui.say(q, "§cНужно 500 ₽."); return; }
            a.addMoney(-500);
            t.boostUntil = q.getServer().getOverworld().getTime() + 12000;
            st.markDirty();
            Gui.say(q, "§aПлейлист-питчинг запущен.");
            open(q);
        });
        if (a.npcIds.containsKey("engineer")) b.set(14, Gui.icon(Items.NOTE_BLOCK, "§fПересвести со звукарём", "§7300 ₽, +1 качество"), q -> { improve(q, t); open(q); });
        b.set(16, Gui.icon(Items.ARROW, "§7Назад"), Streaming::open);
        b.frame().open(p);
    }
}
