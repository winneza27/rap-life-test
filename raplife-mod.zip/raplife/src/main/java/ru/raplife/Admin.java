package ru.raplife;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/** /rapadmin — для операторов (уровень 2). */
public final class Admin {
    private static void fb(ServerCommandSource s, String msg) { s.sendFeedback(() -> Text.literal(msg), true); }

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("rapadmin").requires(s -> s.hasPermissionLevel(2))
                .then(literal("give").then(argument("target", EntityArgumentType.player()).then(argument("amount", IntegerArgumentType.integer(1)).executes(c -> {
                    ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "target");
                    RapState st = RapState.get(c.getSource().getServer());
                    st.of(t.getUuid()).addMoney(IntegerArgumentType.getInteger(c, "amount"));
                    st.markDirty();
                    fb(c.getSource(), "Выдано " + IntegerArgumentType.getInteger(c, "amount") + " ₽ игроку " + t.getName().getString());
                    return 1; }))))
                .then(literal("sethype").then(argument("target", EntityArgumentType.player()).then(argument("value", IntegerArgumentType.integer(0)).executes(c -> {
                    ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "target");
                    RapState st = RapState.get(c.getSource().getServer());
                    st.of(t.getUuid()).hype = IntegerArgumentType.getInteger(c, "value");
                    st.markDirty();
                    fb(c.getSource(), "Хайп игрока " + t.getName().getString() + " = " + IntegerArgumentType.getInteger(c, "value"));
                    return 1; }))))
                .then(literal("reset").then(argument("target", EntityArgumentType.player()).executes(c -> {
                    ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "target");
                    RapState.get(c.getSource().getServer()).reset(t.getUuid());
                    fb(c.getSource(), "Прогресс игрока " + t.getName().getString() + " сброшен (он получит стартовый набор при следующем входе).");
                    return 1; })))
                .then(literal("disband").then(argument("name", StringArgumentType.greedyString()).executes(c -> {
                    RapState st = RapState.get(c.getSource().getServer());
                    RapState.Crew cr = st.crews.get(StringArgumentType.getString(c, "name"));
                    if (cr == null) { c.getSource().sendError(Text.literal("Такого crew нет.")); return 0; }
                    for (UUID id : cr.members.keySet()) st.of(id).crew = "";
                    st.districts.values().removeIf(o -> o.equals(cr.name));
                    st.crews.remove(cr.name);
                    st.markDirty();
                    fb(c.getSource(), "Crew «" + cr.name + "» распущен.");
                    return 1; })))
                .then(literal("crews").executes(c -> {
                    RapState st = RapState.get(c.getSource().getServer());
                    if (st.crews.isEmpty()) fb(c.getSource(), "Crew пока нет.");
                    for (RapState.Crew cr : st.crews.values()) fb(c.getSource(), cr.name + ": " + cr.members.size() + " чел., репутация " + cr.rep + ", общак " + cr.treasury);
                    return 1; }))
                .then(literal("reload").executes(c -> { Config.load(); fb(c.getSource(), "config/raplife.json перечитан."); return 1; })));
    }
}
