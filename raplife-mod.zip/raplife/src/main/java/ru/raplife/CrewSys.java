package ru.raplife;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/** Crew: свои банды (вымышленные), ранги Малой → Боец → Старший → Лидер, общак, бонусы. */
public final class CrewSys {
    private static final Map<UUID, String> INV = new HashMap<>();
    private static final int MAX = 14;

    public static int bonusPct(RapState st, RapState.Stats a) {
        RapState.Crew c = st.crewOf(a);
        return c == null ? 0 : Math.min(25, c.members.size() * 5) + (c.hq != null ? 5 : 0);
    }

    public static void addRep(RapState st, RapState.Stats a, int d) {
        RapState.Crew c = st.crewOf(a);
        if (c != null) c.rep += d;
    }

    public static void create(ServerPlayerEntity p, String name) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        name = name.strip();
        if (!a.crew.isEmpty()) { Gui.say(p, "§7Ты уже в crew «" + a.crew + "»."); return; }
        if (a.hype < 100) { Gui.say(p, "§7Нужно 100 хайпа, чтобы собрать crew."); return; }
        if (name.length() < 3 || name.length() > 16) { Gui.say(p, "§7Название: 3-16 символов."); return; }
        if (st.crews.containsKey(name)) { Gui.say(p, "§cТакое название уже занято."); return; }
        if (a.money < 500) { Gui.say(p, "§cНужно 500 ₽."); return; }
        a.addMoney(-500);
        RapState.Crew c = new RapState.Crew();
        c.name = name;
        c.leader = p.getUuid();
        RapState.Member m = new RapState.Member();
        m.name = p.getName().getString();
        m.rank = 3;
        c.members.put(p.getUuid(), m);
        st.crews.put(name, c);
        a.crew = name;
        st.markDirty();
        Gui.say(p, "§6Crew «" + name + "» создан! Ты — Лидер. Зови людей: §f/rap crew invite <игрок>");
    }

    public static void invite(ServerPlayerEntity from, ServerPlayerEntity to) {
        RapState st = RapState.get(from.getServer());
        RapState.Stats a = st.of(from.getUuid());
        RapState.Crew c = st.crewOf(a);
        if (c == null) { Gui.say(from, "§7У тебя нет crew."); return; }
        if (c.members.get(from.getUuid()).rank < 2) { Gui.say(from, "§7Приглашать могут Старшие и Лидер."); return; }
        if (c.members.size() >= MAX) { Gui.say(from, "§7В crew максимум " + MAX + " человек."); return; }
        if (!st.of(to.getUuid()).crew.isEmpty()) { Gui.say(from, "§7Этот игрок уже в crew."); return; }
        INV.put(to.getUuid(), c.name);
        Gui.say(from, "§dПриглашение отправлено: " + to.getName().getString());
        to.sendMessage(Text.literal("§d" + from.getName().getString() + " зовёт тебя в crew «" + c.name + "» ")
                .append(Text.literal("§a[ВСТУПИТЬ]").setStyle(Style.EMPTY.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/rap crew accept")))));
    }

    public static void accept(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        String name = INV.remove(p.getUuid());
        RapState.Crew c = name == null ? null : st.crews.get(name);
        if (c == null) { Gui.say(p, "§7Приглашений нет."); return; }
        if (!a.crew.isEmpty()) { Gui.say(p, "§7Ты уже в crew."); return; }
        if (c.members.size() >= MAX) { Gui.say(p, "§7В crew нет мест."); return; }
        RapState.Member m = new RapState.Member();
        m.name = p.getName().getString();
        c.members.put(p.getUuid(), m);
        a.crew = c.name;
        st.markDirty();
        Gui.say(p, "§6Добро пожаловать в «" + c.name + "». Ты — Малой, но все с чего-то начинали.");
        for (UUID id : c.members.keySet()) {
            ServerPlayerEntity o = p.getServer().getPlayerManager().getPlayer(id);
            if (o != null && o != p) Gui.say(o, "§d" + m.name + " вступил в crew.");
        }
    }

    public static void leave(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        RapState.Crew c = st.crewOf(a);
        if (c == null) { Gui.say(p, "§7Ты не в crew."); return; }
        c.members.remove(p.getUuid());
        a.crew = "";
        if (c.members.isEmpty()) {
            st.crews.remove(c.name);
            Gui.say(p, "§7Crew «" + c.name + "» распался.");
        } else if (p.getUuid().equals(c.leader)) {
            UUID best = null;
            int br = -1;
            for (Map.Entry<UUID, RapState.Member> e : c.members.entrySet()) if (e.getValue().rank > br) { br = e.getValue().rank; best = e.getKey(); }
            c.leader = best;
            c.members.get(best).rank = 3;
            Gui.say(p, "§7Ты вышел. Лидерство перешло к «" + c.members.get(best).name + "».");
        } else Gui.say(p, "§7Ты вышел из crew.");
        st.markDirty();
    }

    private static void disband(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Crew c = st.crewOf(st.of(p.getUuid()));
        if (c == null || !p.getUuid().equals(c.leader)) { Gui.say(p, "§7Распустить crew может только Лидер."); return; }
        for (UUID id : c.members.keySet()) st.of(id).crew = "";
        st.crews.remove(c.name);
        st.markDirty();
        p.closeHandledScreen();
        Gui.say(p, "§cCrew «" + c.name + "» распущен.");
    }

    public static void open(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(p.getUuid());
        RapState.Crew c = st.crewOf(a);
        if (c == null) {
            Gui.Builder b = new Gui.Builder("Crew", 3);
            b.set(11, Gui.icon(Items.WHITE_BANNER, "§eСоздать crew", "§7Команда: §f/rap crew create <название>", "§7Цена 500 ₽, нужно 100 хайпа"), null);
            if (INV.containsKey(p.getUuid())) b.set(13, Gui.icon(Items.LIME_DYE, "§aПринять приглашение в «" + INV.get(p.getUuid()) + "»"), q -> { accept(q); q.closeHandledScreen(); });
            b.set(15, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
            b.frame().open(p);
            return;
        }
        RapState.Member me = c.members.get(p.getUuid());
        int myRank = me == null ? 0 : me.rank;
        Gui.Builder b = new Gui.Builder("Crew «" + c.name + "»", 6);
        b.set(4, Gui.icon(Items.WHITE_BANNER, "§6" + c.name, "§7Репутация: §f" + c.rep, "§7Общак: §a" + c.treasury + " ₽",
                "§7Участников: §f" + c.members.size() + "/" + MAX, "§7Бонус к хайпу и стримам: §e+" + bonusPct(st, a) + "%",
                "§7Твой ранг: §e" + RapState.RANKS[myRank]), null);
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        int i = 0;
        for (Map.Entry<UUID, RapState.Member> e : c.members.entrySet()) {
            if (i >= slots.length) break;
            UUID id = e.getKey();
            RapState.Member m = e.getValue();
            boolean online = s.getPlayerManager().getPlayer(id) != null;
            ItemStack head = Gui.icon(Items.PLAYER_HEAD, "§f" + m.name, "§7Ранг: §e" + RapState.RANKS[m.rank],
                    online ? "§aв сети" : "§8не в сети", myRank >= 2 && !id.equals(p.getUuid()) ? "§8Клик — управление" : "");
            head.getOrCreateNbt().putString("SkullOwner", m.name);
            Consumer<ServerPlayerEntity> act = null;
            if (myRank >= 2 && !id.equals(p.getUuid())) act = q -> memberMenu(q, id);
            b.set(slots[i++], head, act);
        }
        b.set(46, Gui.icon(Items.GOLD_INGOT, "§aВнести в общак: 500 ₽"), q -> {
            if (a.money < 500) { Gui.say(q, "§cНужно 500 ₽."); return; }
            a.addMoney(-500); c.treasury += 500; c.rep += 1; st.markDirty(); open(q);
        });
        b.set(47, Gui.icon(Items.CHEST, "§eВзять из общака: 500 ₽", "§7Только Старшие и Лидер"), q -> {
            if (myRank < 2) { Gui.say(q, "§7Из общака берут Старшие и Лидер."); return; }
            if (c.treasury < 500) { Gui.say(q, "§cВ общаке не хватает."); return; }
            c.treasury -= 500; a.addMoney(500); st.markDirty(); open(q);
        });
        b.set(49, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.set(51, Gui.icon(Items.OAK_DOOR, "§cПокинуть crew"), q -> { leave(q); q.closeHandledScreen(); });
        if (myRank == 3) b.set(52, Gui.icon(Items.TNT, "§4Распустить crew"), CrewSys::disband);
        b.frame().open(p);
    }

    private static void memberMenu(ServerPlayerEntity v, UUID tid) {
        RapState st = RapState.get(v.getServer());
        RapState.Crew c = st.crewOf(st.of(v.getUuid()));
        if (c == null || !c.members.containsKey(tid)) return;
        RapState.Member t = c.members.get(tid);
        Gui.Builder b = new Gui.Builder(t.name + " · " + RapState.RANKS[t.rank], 3);
        b.set(10, Gui.icon(Items.EMERALD, "§aПовысить"), q -> act(q, tid, 0));
        b.set(12, Gui.icon(Items.REDSTONE, "§eПонизить"), q -> act(q, tid, 1));
        b.set(14, Gui.icon(Items.BARRIER, "§cВыгнать"), q -> act(q, tid, 2));
        b.set(16, Gui.icon(Items.NETHER_STAR, "§6Передать лидерство", "§7Только Лидер"), q -> act(q, tid, 3));
        b.set(22, Gui.icon(Items.ARROW, "§7Назад"), CrewSys::open);
        b.frame().open(v);
    }

    private static void act(ServerPlayerEntity v, UUID tid, int kind) {
        RapState st = RapState.get(v.getServer());
        RapState.Crew c = st.crewOf(st.of(v.getUuid()));
        if (c == null) return;
        RapState.Member me = c.members.get(v.getUuid()), t = c.members.get(tid);
        if (me == null || t == null) return;
        String note = "";
        switch (kind) {
            case 0 -> {
                if (me.rank == 3 && t.rank < 2) t.rank++;
                else if (me.rank == 2 && t.rank < 1) t.rank++;
                else { Gui.say(v, "§7Повысить нельзя."); return; }
                note = "Тебя повысили до ранга «" + RapState.RANKS[t.rank] + "».";
            }
            case 1 -> {
                if (t.rank > 0 && me.rank > t.rank) t.rank--;
                else { Gui.say(v, "§7Понизить нельзя."); return; }
                note = "Тебя понизили до ранга «" + RapState.RANKS[t.rank] + "».";
            }
            case 2 -> {
                if (me.rank >= 2 && me.rank > t.rank) { c.members.remove(tid); st.of(tid).crew = ""; note = "Тебя выгнали из crew «" + c.name + "»."; }
                else { Gui.say(v, "§7Выгнать нельзя."); return; }
            }
            default -> {
                if (me.rank == 3 && t.rank < 3) { t.rank = 3; me.rank = 2; c.leader = tid; note = "Теперь ты Лидер crew «" + c.name + "»."; }
                else { Gui.say(v, "§7Передать лидерство может только Лидер."); return; }
            }
        }
        st.markDirty();
        ServerPlayerEntity tp = v.getServer().getPlayerManager().getPlayer(tid);
        if (tp != null) Gui.say(tp, "§d" + note);
        open(v);
    }
}
