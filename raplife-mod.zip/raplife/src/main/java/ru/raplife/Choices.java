package ru.raplife;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.*;
import java.util.function.Consumer;

/** Диалоги в стиле кодека: реплики + кликабельные варианты ответа (/rap choice N). */
public final class Choices {
    public record Option(String label, Consumer<ServerPlayerEntity> action) {}

    private static final Map<UUID, List<Option>> PENDING = new HashMap<>();

    public static Option opt(String label, Consumer<ServerPlayerEntity> a) { return new Option(label, a); }
    public static boolean hasPending(UUID id) { return PENDING.containsKey(id); }
    public static void clear(UUID id) { PENDING.remove(id); }

    public static void offer(ServerPlayerEntity p, String speaker, List<String> lines, Option... opts) {
        PENDING.put(p.getUuid(), new ArrayList<>(Arrays.asList(opts)));
        p.sendMessage(Text.literal("§8§m                                  "));
        p.sendMessage(Text.literal("§6" + speaker));
        for (String l : lines) p.sendMessage(Text.literal("§f  " + l));
        for (int i = 0; i < opts.length; i++) {
            p.sendMessage(Text.literal("§a  [" + (i + 1) + "] " + opts[i].label())
                    .setStyle(Style.EMPTY.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/rap choice " + (i + 1)))));
        }
    }

    public static boolean pick(ServerPlayerEntity p, int n) {
        List<Option> l = PENDING.get(p.getUuid());
        if (l == null || n < 1 || n > l.size()) return false;
        PENDING.remove(p.getUuid());
        l.get(n - 1).action().accept(p);
        return true;
    }
}
