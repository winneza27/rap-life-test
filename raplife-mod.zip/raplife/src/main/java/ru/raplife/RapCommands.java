package ru.raplife;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.function.Consumer;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class RapCommands {

    private static int run(CommandContext<ServerCommandSource> c, Consumer<ServerPlayerEntity> f) throws CommandSyntaxException {
        f.accept(c.getSource().getPlayerOrThrow());
        return 1;
    }

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("rap")
                .executes(c -> run(c, PhoneMenu::open))
                .then(literal("menu").executes(c -> run(c, PhoneMenu::open)))
                .then(literal("stats").executes(c -> run(c, RapCommands::showStats)))
                .then(literal("rank").executes(c -> run(c, p -> Gui.say(p, "§6Позывной: §f" + Story.codename(RapState.get(p.getServer()).of(p.getUuid()))))))
                .then(literal("tiktok").executes(c -> run(c, RapAi::showFeed)))
                .then(literal("codec").executes(c -> run(c, Story::codec)))
                .then(literal("tape").executes(c -> run(c, Story::listTapes)))
                .then(literal("ending").executes(c -> run(c, Story::ending)))
                .then(literal("boss").executes(c -> run(c, Boss::start)))
                .then(literal("choice").then(argument("n", IntegerArgumentType.integer(1, 9)).executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                    if (!Choices.pick(p, IntegerArgumentType.getInteger(c, "n"))) c.getSource().sendError(Text.literal("Сейчас нет такого варианта."));
                    return 1; })))
                .then(literal("track").then(argument("name", StringArgumentType.greedyString()).executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                    if (!p.getMainHandStack().isOf(RapLifeMod.MIC)) { c.getSource().sendError(Text.literal("Возьми микрофон в основную руку.")); return 0; }
                    Streaming.record(p, StringArgumentType.getString(c, "name"));
                    return 1; })))
                .then(literal("concert").executes(c -> run(c, Concert::start)))
                .then(literal("promo").executes(c -> run(c, RapCommands::promo)))
                .then(literal("run")
                        .then(literal("start").executes(c -> run(c, Crime::startRun)))
                        .then(literal("status").executes(c -> run(c, Crime::status)))
                        .then(literal("abort").executes(c -> run(c, Crime::abort))))
                .then(literal("launder").then(argument("amount", IntegerArgumentType.integer(1))
                        .executes(c -> { Crime.launder(c.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(c, "amount")); return 1; })))
                .then(literal("players").executes(c -> run(c, Players::open)))
                .then(literal("help").executes(c -> run(c, Help::show)))
                .then(literal("kit").executes(c -> run(c, Help::kit)))
                .then(literal("party").executes(c -> run(c, Players::party)))
                .then(literal("cc").then(argument("msg", StringArgumentType.greedyString())
                        .executes(c -> { Players.crewChat(c.getSource().getPlayerOrThrow(), StringArgumentType.getString(c, "msg")); return 1; })))
                .then(literal("pay").then(argument("target", EntityArgumentType.player()).then(argument("amount", IntegerArgumentType.integer(1))
                        .executes(c -> { Players.pay(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target").getUuid(), IntegerArgumentType.getInteger(c, "amount")); return 1; }))))
                .then(literal("gift").then(argument("target", EntityArgumentType.player())
                        .executes(c -> { Players.gift(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target").getUuid()); return 1; })))
                .then(literal("follow").then(argument("target", EntityArgumentType.player())
                        .executes(c -> { Players.follow(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target").getUuid()); return 1; })))
                .then(literal("listen").then(argument("target", EntityArgumentType.player())
                        .executes(c -> { Players.listen(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target").getUuid()); return 1; })))
                .then(literal("visit").then(argument("target", EntityArgumentType.player())
                        .executes(c -> { Players.visit(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target").getUuid()); return 1; })))
                .then(literal("cover").then(argument("target", EntityArgumentType.player())
                        .executes(c -> { Players.cover(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target").getUuid()); return 1; })))
                .then(literal("profile").then(argument("target", EntityArgumentType.player())
                        .executes(c -> { Players.profile(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target").getUuid()); return 1; })))
                .then(literal("attend").then(argument("target", EntityArgumentType.player())
                        .executes(c -> { Concert.attend(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target")); return 1; })))
                .then(literal("build").executes(c -> run(c, Structures::openGui)))
                .then(literal("undo").executes(c -> run(c, Structures::undo)))
                .then(literal("label").executes(c -> run(c, Labels::open)))
                .then(literal("district").executes(c -> run(c, Districts::open)))
                .then(literal("ach").executes(c -> run(c, Achievements::open)))
                .then(literal("post").executes(c -> run(c, Social::open)))
                .then(literal("top").executes(c -> run(c, Leaderboard::open)))
                .then(literal("bribe").executes(c -> run(c, Crime::bribe)))
                .then(literal("boost").executes(c -> run(c, Crime::boost)))
                .then(literal("shop").executes(c -> run(c, p -> Shop.open(p, "Дом"))))
                .then(literal("stream").executes(c -> run(c, Streaming::open)))
                .then(literal("garage").executes(c -> run(c, Shop::openGarage)))
                .then(literal("npc").executes(c -> run(c, Npcs::openHire)))
                .then(literal("mission").executes(c -> run(c, Missions::status)))
                .then(literal("home").executes(c -> run(c, Shop::home))
                        .then(literal("set").executes(c -> run(c, Shop::homeSet))))
                .then(literal("crew").executes(c -> run(c, CrewSys::open))
                        .then(literal("create").then(argument("name", StringArgumentType.greedyString())
                                .executes(c -> { CrewSys.create(c.getSource().getPlayerOrThrow(), StringArgumentType.getString(c, "name")); return 1; })))
                        .then(literal("invite").then(argument("target", EntityArgumentType.player())
                                .executes(c -> { CrewSys.invite(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target")); return 1; })))
                        .then(literal("accept").executes(c -> run(c, CrewSys::accept)))
                        .then(literal("leave").executes(c -> run(c, CrewSys::leave))))
                .then(literal("beef").executes(c -> run(c, Beef::openGui))
                        .then(literal("accept").executes(c -> run(c, Beef::accept)))
                        .then(argument("target", EntityArgumentType.player())
                                .executes(c -> { Beef.request(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target")); return 1; })))
                .then(literal("collab")
                        .then(literal("accept").executes(c -> run(c, Fans::accept)))
                        .then(argument("target", EntityArgumentType.player())
                                .executes(c -> { Fans.request(c.getSource().getPlayerOrThrow(), EntityArgumentType.getPlayer(c, "target")); return 1; }))));
    }

    public static void showStats(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        int idx = RapState.stageIndex(a.hype);
        String next = idx + 1 < RapState.LIMITS.length ? " (до «" + RapState.STAGES[idx + 1] + "»: " + (RapState.LIMITS[idx + 1] - a.hype) + ")" : " (макс.)";
        RapState.Crew c = st.crewOf(a);
        Gui.say(p, "§6=== " + p.getName().getString() + " · Глава " + a.chapter + ": " + Story.CH_NAMES[a.chapter] + " ===");
        Gui.say(p, "§eЭтап: §f" + RapState.STAGES[idx] + "§7" + next);
        Gui.say(p, "§eХайп: §f" + a.hype + "  §eАвторитет: §f" + a.cred + "  §eПодписчики: §f" + a.followers + "  §eЛояльность: §f" + a.loyalty + "%  §eСтиль: §d" + Shop.style(a));
        Gui.say(p, "§eДеньги: §a" + a.money + " ₽  §eГрязные: §c" + a.dirty + " ₽  §eРозыск: §9" + Crime.stars(a.wanted) + "  §eРоялти: §a" + (int) a.royalties + " ₽");
        Gui.say(p, "§eСлушатели: §bОблачко " + a.listenersCloud + " §7| §2Спотик " + a.listenersSpot + "  §eБифы: §a" + a.beefWins + "§7/§c" + a.beefLosses);
        Gui.say(p, "§7Район " + a.repStreet + " | Бархат " + a.repSyndicate + " | Патруль " + a.repPolice + " | Ведомство " + a.repGov
                + (c != null ? " | Crew «" + c.name + "» (" + RapState.RANKS[c.members.get(p.getUuid()).rank] + ")" : ""));
        Gui.say(p, "§7Позывной: " + Story.codename(a));
    }

    private static void promo(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (a.money < 200) { Gui.say(p, "§cНужно 200 ₽ на рекламу у блогеров."); return; }
        a.addMoney(-200); a.addHype(40); a.followers += 80; st.markDirty();
        Gui.say(p, "§dБлогеры сделали рекламу. §e+40 хайпа, §c-200 ₽");
    }
}
