package ru.raplife;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** config/raplife.json — любой OpenAI-совместимый эндпоинт (OpenAI, OpenRouter, Ollama, LM Studio). */
public class Config {
    public boolean useAi = true;
    public String endpoint = "https://api.openai.com/v1/chat/completions";
    public String apiKey = "";
    public String model = "gpt-4o-mini";

    private static Config inst = new Config();
    public static Config get() { return inst; }

    public boolean ready() {
        boolean local = endpoint.contains("localhost") || endpoint.contains("127.0.0.1");
        return useAi && (local || (apiKey != null && !apiKey.isBlank()));
    }

    public static void load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path p = FabricLoader.getInstance().getConfigDir().resolve("raplife.json");
        try {
            if (Files.exists(p)) {
                inst = gson.fromJson(Files.readString(p), Config.class);
                if (inst == null) inst = new Config();
            } else {
                Files.writeString(p, gson.toJson(inst));
            }
        } catch (Exception e) {
            System.err.println("[raplife] config error: " + e);
        }
    }
}
