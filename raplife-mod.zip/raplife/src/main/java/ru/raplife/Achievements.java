package ru.raplife;

import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.function.Predicate;

public final class Achievements {
    private record Ach(String id, String name, String desc, int reward, Predicate<RapState.Stats> cond) {}

    private static final List<Ach> ALL = List.of(
            new Ach("first_track", "Первый трек", "Запиши трек", 100, a -> !a.tracks.isEmpty()),
            new Ach("streams_1k", "Тысяча ушей", "1 000 прослушиваний", 200, a -> a.totalStreams >= 1000),
            new Ach("streams_100k", "Сто тысяч ушей", "100 000 прослушиваний", 2000, a -> a.totalStreams >= 100000),
            new Ach("fans_1k", "Первая тысяча", "1 000 подписчиков", 300, a -> a.followers >= 1000),
            new Ach("hype_300", "Заметили", "300 хайпа", 300, a -> a.hype >= 300),
            new Ach("hype_800", "Лейбловый", "800 хайпа", 800, a -> a.hype >= 800),
            new Ach("hype_2000", "Стадионный", "2000 хайпа", 2500, a -> a.hype >= 2000),
            new Ach("beef_1", "Первая кровь", "Выиграй бифф", 300, a -> a.beefWins >= 1),
            new Ach("beef_5", "Король баттлов", "5 побед в бифах", 1500, a -> a.beefWins >= 5),
            new Ach("crew", "Свои", "Вступи в crew или создай его", 200, a -> !a.crew.isEmpty()),
            new Ach("house", "Своя крыша", "Купи дом", 150, a -> Shop.qualityBonus(a) >= 1),
            new Ach("mansion", "Особняк на холме", "Купи особняк", 2000, a -> a.owned.contains("house4")),
            new Ach("supercar", "Скорость", "Купи спорткар", 1500, a -> a.owned.contains("car3")),
            new Ach("style15", "Стиляга", "Набери 15 стиля", 500, a -> Shop.style(a) >= 15),
            new Ach("label", "Подписан", "Подпиши контракт с лейблом", 500, a -> a.label >= 0),
            new Ach("builder", "Застройщик", "Построй 3 здания", 600, a -> a.builds.size() >= 3),
            new Ach("rich", "Наличка", "10 000 ₽ на руках", 1000, a -> a.money >= 10000),
            new Ach("wanted5", "Враг государства", "Розыск на 5 звёзд", 400, a -> a.wanted >= 5),
            new Ach("boss", "Тишина побеждена", "Победи Инспектора", 1500, a -> a.bossDone == 1),
            new Ach("tapes", "Коллекционер", "Найди все 8 кассет", 1000, a -> Integer.bitCount(a.tapes) >= 8));

    public static void check(ServerPlayerEntity p, RapState st, RapState.Stats a) {
        for (Ach x : ALL) {
            if (a.ach.contains(x.id()) || !x.cond().test(a)) continue;
            a.ach.add(x.id());
            a.addMoney(x.reward());
            st.markDirty();
            Story.title(p, "Достижение", x.name());
            Gui.say(p, "§6★ Достижение: §f" + x.name() + " §a+" + x.reward() + " ₽");
        }
    }

    public static void open(ServerPlayerEntity p) {
        RapState.Stats a = RapState.get(p.getServer()).of(p.getUuid());
        Gui.Builder b = new Gui.Builder("Достижения " + a.ach.size() + "/" + ALL.size(), 6);
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
        for (int i = 0; i < ALL.size() && i < slots.length; i++) {
            Ach x = ALL.get(i);
            boolean got = a.ach.contains(x.id());
            b.set(slots[i], Gui.icon(got ? Items.GOLD_INGOT : Items.COAL, (got ? "§6" : "§8") + x.name(), "§7" + x.desc(),
                    got ? "§aПолучено" : "§eНаграда: " + x.reward() + " ₽"), null);
        }
        b.set(49, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(p);
    }
}
