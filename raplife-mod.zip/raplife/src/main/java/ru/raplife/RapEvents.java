package ru.raplife;

import net.minecraft.entity.mob.VindicatorEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.TypeFilter;

import java.util.List;
import java.util.Random;

public final class RapEvents {
    private static final Random R = new Random();

    public static void tick(MinecraftServer s) {
        int t = s.getTicks();
        if (t % 10 == 0) Boss.tick(s);
        if (t % 20 == 0) Crime.tickRuns(s);
        if (t % 40 == 0) {
            RapState st = RapState.get(s);
            for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
                RapState.Stats a = st.of(p.getUuid());
                a.name = p.getName().getString();
                Story.check(p, st, a);
            }
        }
        if (t % 200 == 0) {
            RapState st = RapState.get(s);
            for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) Achievements.check(p, st, st.of(p.getUuid()));
        }
        if (t % 600 == 0) Crime.tickPatrols(s);
        if (t % 1200 == 0) { cleanup(s); Fans.spawnFans(s); Concert.expire(s); Streaming.tick(s); Districts.tick(s); Players.tick(s); }
        if (t % 6000 == 0) lifeEvents(s);
        if (t % 12000 == 3000) transmissions(s);
        if (t % 12000 == 9000) Labels.quotaCheck(s);
    }

    private static void cleanup(MinecraftServer s) {
        for (ServerWorld w : s.getWorlds()) {
            w.getEntitiesByType(TypeFilter.instanceOf(VillagerEntity.class), v -> v.getCommandTags().contains(Fans.TAG) && v.age > 12000)
                    .forEach(v -> v.discard());
            w.getEntitiesByType(TypeFilter.instanceOf(VindicatorEntity.class),
                    v -> (v.getCommandTags().contains(Crime.COP) || v.getCommandTags().contains(Beef.THUG)) && v.age > 6000)
                    .forEach(v -> v.discard());
        }
    }

    private static void transmissions(MinecraftServer s) {
        RapState st = RapState.get(s);
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            RapState.Stats a = st.of(p.getUuid());
            if (a.chapter < 2 || Choices.hasPending(p.getUuid()) || Concert.active(p.getUuid())) continue;
            RapAi.speak(p, "Алгоритм", Story.PERSONA.get("Алгоритм"), "Алгоритм сам вышел на связь без повода.", Story.FB.get("Алгоритм"), null);
        }
    }

    private static void lifeEvents(MinecraftServer s) {
        RapState st = RapState.get(s);
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            RapState.Stats a = st.of(p.getUuid());
            if (a.hype < 20 || Choices.hasPending(p.getUuid()) || Concert.active(p.getUuid())) continue;
            switch (R.nextInt(12)) {
                case 0 -> { a.addHype(-10); a.addLoyalty(-2); msg(p, "§cХейтеры в комментах разнесли твой последний релиз. §7-10 хайпа"); }
                case 1 -> { int m = 50 + a.hype / 4; a.addMoney(m); msg(p, "§aМерч разошёлся: футболки с твоим логотипом. §e+" + m + " ₽"); }
                case 2 -> { a.cred += 3; msg(p, "§bYung Подъезд зачитал твой куплет на районе. §e+3 авторитета"); }
                case 3 -> { int c = Math.min(a.money, 100); a.addMoney(-c); msg(p, "§cСемпл пришлось легализовать — юристы взяли свою долю. §7-" + c + " ₽"); }
                case 4 -> { a.addHype(15); a.followers += 40; msg(p, "§6Твой трек подхватили в стримах. §e+15 хайпа"); }
                case 5 -> { if (a.chapter >= 3) censorship(p, st, a); else { a.cred += 1; msg(p, "§7Тебя узнали в магазине. §e+1 авторитета"); } }
                case 6 -> { if (a.auditRisk > 0 && R.nextInt(100) < Math.min(80, a.auditRisk)) audit(p, st, a); else { a.followers += 25; msg(p, "§7Новые подписчики пришли из ниоткуда."); } }
                case 7 -> { if (a.hype >= 100) Beef.incoming(p); else msg(p, "§7Кто-то написал про тебя пост. Пока без хейта."); }
                case 8 -> { if (a.followers >= 300) sponsor(p, st, a); else msg(p, "§7Бренды пока не знают твоего имени."); }
                case 9 -> {
                    if (!a.tracks.isEmpty()) { a.royalties *= 0.8; a.addHype(20); msg(p, "§eТрек слили в сеть до релиза: часть роялти потеряна, зато слышали все. §7+20 хайпа"); }
                    else msg(p, "§7Тихая неделя.");
                }
                case 10 -> festival(p, st, a);
                default -> {
                    if (a.loyalty < 25) { a.followers = Math.max(0, a.followers - 50); msg(p, "§cФанаты отписываются: ты давно не был с ними честен. §7-50 подписчиков"); }
                    else { a.addHype(5); msg(p, "§7Тихий день. Бит сам пишется. §e+5 хайпа"); }
                }
            }
            st.markDirty();
        }
    }

    private static void msg(ServerPlayerEntity p, String t) { p.sendMessage(Text.literal("§8[Жизнь] " + t)); }

    private static void sponsor(ServerPlayerEntity p, RapState st, RapState.Stats a) {
        int pay = 200 + a.followers / 10;
        Choices.offer(p, "Бренд «Энергия Двора»", List.of("Предлагают рекламный контракт: " + pay + " ₽.", "Фанаты могут решить, что ты продался."),
                Choices.opt("Взять рекламу (+" + pay + " ₽)", q -> { a.addMoney(pay); a.addLoyalty(-3); st.markDirty(); msg(q, "§aКонтракт подписан. §e+" + pay + " ₽, §7-3 лояльности"); }),
                Choices.opt("Отказаться", q -> { a.addLoyalty(2); st.markDirty(); msg(q, "§7Фанаты уважают принципы. §e+2 лояльности"); }));
    }

    private static void festival(ServerPlayerEntity p, RapState st, RapState.Stats a) {
        if (a.hype < 100) { msg(p, "§7Фестиваль прошёл без тебя."); return; }
        Choices.offer(p, "Фестиваль «Открытый Двор»", List.of("Организаторы зовут выступить на одной из сцен."),
                Choices.opt("Выступить", q -> {
                    if (R.nextInt(100) < 70) { int m = 150 + a.hype / 5; a.addMoney(m); a.addHype(30); a.followers += 150; msg(q, "§aТы порвал фестиваль! §e+30 хайпа, +" + m + " ₽"); }
                    else { a.addHype(-10); msg(q, "§cМикрофон отключили на втором треке. §7-10 хайпа"); }
                    st.markDirty();
                }),
                Choices.opt("Отказаться", q -> msg(q, "§7Ты отсиделся дома.")));
    }

    private static void censorship(ServerPlayerEntity p, RapState st, RapState.Stats a) {
        Choices.offer(p, "Ведомство Культурной Безопасности",
                List.of("Твой последний трек признан «неудобным».", "Вам предлагают «правки» — и компенсацию."),
                Choices.opt("Согласиться на правки (+300 ₽)", q -> { a.addMoney(300); a.addLoyalty(-8); a.repGov += 8; st.markDirty(); msg(q, "§7Трек стал глаже. Фанаты заметили. §e+300 ₽"); }),
                Choices.opt("Отказаться", q -> {
                    a.addLoyalty(6); a.addHype(10); a.repGov -= 10;
                    if (a.repGov < -30) Crime.addWanted(q, a, 1);
                    st.markDirty(); msg(q, "§aТы отказал. Фанаты в восторге. §e+10 хайпа");
                }),
                Choices.opt("Нанять юриста (-200 ₽)", q -> {
                    if (a.money >= 200) { a.addMoney(-200); a.repGov += 2; st.markDirty(); msg(q, "§7Юрист нашёл лазейку."); }
                    else { a.addLoyalty(-3); st.markDirty(); msg(q, "§cНет денег на юриста. Трек сняли с площадок."); }
                }));
    }

    private static void audit(ServerPlayerEntity p, RapState st, RapState.Stats a) {
        a.auditRisk /= 2;
        Choices.offer(p, "Ведомство · финансовый отдел", List.of("Вам пришла повестка: «пояснить происхождение доходов»."),
                Choices.opt("Оплатить штраф (20% денег)", q -> { int f = a.money / 5; a.addMoney(-f); a.repGov += 3; st.markDirty(); msg(q, "§cШтраф оплачен: -" + f + " ₽"); }),
                Choices.opt("Дать взятку инспектору (300 ₽)", q -> {
                    if (a.money >= 300) { a.addMoney(-300); a.repGov += 2; st.markDirty(); msg(q, "§7Дело потерялось в папках."); }
                    else { Crime.addWanted(q, a, 1); st.markDirty(); msg(q, "§cНечем платить — возбуждено дело."); }
                }),
                Choices.opt("Игнорировать", q -> { Crime.addWanted(q, a, 1); a.repGov -= 8; Crime.spawnPatrol(q, 2); st.markDirty(); }));
    }
}
