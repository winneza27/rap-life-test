package ru.raplife;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.*;

public class RapState extends PersistentState {

    public static class Track {
        public String title = "";
        public int quality;
        public boolean onSpot, diss;
        public long streams, bornTick, boostUntil;
    }

    public static class Member { public String name = ""; public int rank; }

    public static class Crew {
        public String name = "";
        public UUID leader;
        public int treasury, rep;
        public int[] hq;
        public final Map<UUID, Member> members = new LinkedHashMap<>();
    }

    public static class Stats {
        public int hype, money, dirty, cred, wanted, chapter = 1, tapes, loyalty = 50, followers;
        public int repStreet, repSyndicate, repPolice, repGov, bossDone, ending, auditRisk;
        public int stash, homeSet, homeX, homeY, homeZ, beefRival = -1, beefHeat, beefWins, beefLosses;
        public int mType, mTarget, mProgress, mReward, listenersCloud, listenersSpot;
        public int label = -1, labelTracks;
        public String name = "";
        public final Set<String> ach = new HashSet<>();
        public final Set<UUID> subs = new HashSet<>();
        public final Map<String, int[]> builds = new HashMap<>();
        public double royalties;
        public long totalStreams;
        public String crew = "";
        public final List<Track> tracks = new ArrayList<>();
        public final Set<String> owned = new HashSet<>();
        public final Map<String, UUID> npcIds = new HashMap<>();
        // не сохраняются
        public long lastTrack = -99999, lastConcert = -99999, lastCodec = -99999, lastBoost = -99999,
                lastCollab = -99999, lastWantedTick, lastBeef = -99999;

        public void addHype(int d) { hype = Math.max(0, hype + d); }
        public void addLoyalty(int d) { loyalty = Math.max(0, Math.min(100, loyalty + d)); }
        public void addMoney(int d) { money = Math.max(0, money + d); }

        int[] pack() {
            return new int[]{hype, money, dirty, cred, wanted, chapter, tapes, loyalty, followers,
                    repStreet, repSyndicate, repPolice, repGov, bossDone, ending, auditRisk,
                    stash, homeSet, homeX, homeY, homeZ, beefRival, beefHeat, beefWins, beefLosses,
                    mType, mTarget, mProgress, mReward, listenersCloud, listenersSpot, label, labelTracks};
        }

        void unpack(int[] v) {
            int i = 0;
            hype = v[i++]; money = v[i++]; dirty = v[i++]; cred = v[i++]; wanted = v[i++]; chapter = v[i++];
            tapes = v[i++]; loyalty = v[i++]; followers = v[i++]; repStreet = v[i++]; repSyndicate = v[i++];
            repPolice = v[i++]; repGov = v[i++]; bossDone = v[i++]; ending = v[i++]; auditRisk = v[i++];
            stash = v[i++]; homeSet = v[i++]; homeX = v[i++]; homeY = v[i++]; homeZ = v[i++];
            beefRival = v[i++]; beefHeat = v[i++]; beefWins = v[i++]; beefLosses = v[i++];
            mType = v[i++]; mTarget = v[i++]; mProgress = v[i++]; mReward = v[i++];
            listenersCloud = v[i++]; listenersSpot = v[i++]; label = v[i++]; labelTracks = v[i++];
        }
    }

    private static final String[] KEYS = {"hype", "money", "dirty", "cred", "wanted", "chapter", "tapes", "loyalty",
            "followers", "repStreet", "repSyndicate", "repPolice", "repGov", "bossDone", "ending", "auditRisk",
            "stash", "homeSet", "homeX", "homeY", "homeZ", "beefRival", "beefHeat", "beefWins", "beefLosses",
            "mType", "mTarget", "mProgress", "mReward", "listenersCloud", "listenersSpot", "label", "labelTracks"};

    public static final int[] LIMITS = {0, 100, 300, 800, 2000};
    public static final String[] STAGES = {"Подвал", "SoundCloud", "Фит с известным", "Контракт с лейблом", "Стадион"};
    public static final String[] RANKS = {"Малой", "Боец", "Старший", "Лидер"};

    private final Map<UUID, Stats> map = new HashMap<>();
    public final Map<String, Crew> crews = new LinkedHashMap<>();
    public final Map<String, String> districts = new LinkedHashMap<>();

    public static RapState get(MinecraftServer s) {
        return s.getOverworld().getPersistentStateManager().getOrCreate(RapState::fromNbt, RapState::new, "raplife");
    }

    public Stats of(UUID id) { return map.computeIfAbsent(id, k -> new Stats()); }

    public void reset(UUID id) {
        Stats a = map.get(id);
        if (a != null) {
            Crew c = crewOf(a);
            if (c != null) {
                c.members.remove(id);
                if (c.members.isEmpty()) {
                    crews.remove(c.name);
                    districts.values().removeIf(o -> o.equals(c.name));
                } else if (id.equals(c.leader)) {
                    UUID best = null;
                    int br = -1;
                    for (Map.Entry<UUID, Member> e : c.members.entrySet()) if (e.getValue().rank > br) { br = e.getValue().rank; best = e.getKey(); }
                    c.leader = best;
                    c.members.get(best).rank = 3;
                }
            }
            map.remove(id);
        }
        markDirty();
    }

    public Set<Map.Entry<UUID, Stats>> entries() { return map.entrySet(); }

    public Crew crewOf(Stats a) { return a.crew.isEmpty() ? null : crews.get(a.crew); }

    public static int stageIndex(int hype) {
        int idx = 0;
        for (int i = 0; i < LIMITS.length; i++) if (hype >= LIMITS[i]) idx = i;
        return idx;
    }

    public static String stageName(int hype) { return STAGES[stageIndex(hype)]; }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtCompound all = new NbtCompound();
        for (Map.Entry<UUID, Stats> e : map.entrySet()) {
            Stats s = e.getValue();
            NbtCompound c = new NbtCompound();
            int[] v = s.pack();
            for (int i = 0; i < KEYS.length; i++) c.putInt(KEYS[i], v[i]);
            c.putDouble("royalties", s.royalties);
            c.putLong("totalStreams", s.totalStreams);
            c.putString("crew", s.crew);
            NbtList tl = new NbtList();
            for (Track t : s.tracks) {
                NbtCompound tc = new NbtCompound();
                tc.putString("title", t.title);
                tc.putInt("quality", t.quality);
                tc.putBoolean("onSpot", t.onSpot);
                tc.putBoolean("diss", t.diss);
                tc.putLong("streams", t.streams);
                tc.putLong("born", t.bornTick);
                tc.putLong("boost", t.boostUntil);
                tl.add(tc);
            }
            c.put("tracks", tl);
            NbtList ol = new NbtList();
            for (String o : s.owned) ol.add(NbtString.of(o));
            c.put("owned", ol);
            NbtCompound nc = new NbtCompound();
            for (Map.Entry<String, UUID> n : s.npcIds.entrySet()) nc.putString(n.getKey(), n.getValue().toString());
            c.put("npcs", nc);
            c.putString("name", s.name);
            NbtList al = new NbtList();
            for (String x : s.ach) al.add(NbtString.of(x));
            c.put("ach", al);
            NbtList sl = new NbtList();
            for (UUID u : s.subs) sl.add(NbtString.of(u.toString()));
            c.put("subs", sl);
            NbtCompound bc = new NbtCompound();
            for (Map.Entry<String, int[]> bb : s.builds.entrySet()) bc.putIntArray(bb.getKey(), bb.getValue());
            c.put("builds", bc);
            all.put(e.getKey().toString(), c);
        }
        nbt.put("players", all);

        NbtList cl = new NbtList();
        for (Crew cr : crews.values()) {
            NbtCompound cc = new NbtCompound();
            cc.putString("name", cr.name);
            cc.putString("leader", cr.leader == null ? "" : cr.leader.toString());
            cc.putInt("treasury", cr.treasury);
            cc.putInt("rep", cr.rep);
            cc.putIntArray("hq", cr.hq == null ? new int[0] : cr.hq);
            NbtList ml = new NbtList();
            for (Map.Entry<UUID, Member> m : cr.members.entrySet()) {
                NbtCompound mc = new NbtCompound();
                mc.putString("id", m.getKey().toString());
                mc.putString("name", m.getValue().name);
                mc.putInt("rank", m.getValue().rank);
                ml.add(mc);
            }
            cc.put("members", ml);
            cl.add(cc);
        }
        nbt.put("crews", cl);
        NbtCompound dc = new NbtCompound();
        for (Map.Entry<String, String> d : districts.entrySet()) dc.putString(d.getKey(), d.getValue());
        nbt.put("districts", dc);
        return nbt;
    }

    public static RapState fromNbt(NbtCompound nbt) {
        RapState st = new RapState();
        NbtCompound all = nbt.getCompound("players");
        for (String k : all.getKeys()) {
            NbtCompound c = all.getCompound(k);
            Stats s = new Stats();
            int[] v = s.pack();
            for (int i = 0; i < KEYS.length; i++) if (c.contains(KEYS[i])) v[i] = c.getInt(KEYS[i]);
            s.unpack(v);
            s.royalties = c.getDouble("royalties");
            s.totalStreams = c.getLong("totalStreams");
            s.crew = c.getString("crew");
            NbtList tl = c.getList("tracks", NbtElement.COMPOUND_TYPE);
            for (int i = 0; i < tl.size(); i++) {
                NbtCompound tc = tl.getCompound(i);
                Track t = new Track();
                t.title = tc.getString("title");
                t.quality = tc.getInt("quality");
                t.onSpot = tc.getBoolean("onSpot");
                t.diss = tc.getBoolean("diss");
                t.streams = tc.getLong("streams");
                t.bornTick = tc.getLong("born");
                t.boostUntil = tc.getLong("boost");
                s.tracks.add(t);
            }
            NbtList ol = c.getList("owned", NbtElement.STRING_TYPE);
            for (int i = 0; i < ol.size(); i++) s.owned.add(ol.getString(i));
            NbtCompound nc = c.getCompound("npcs");
            for (String role : nc.getKeys()) {
                try { s.npcIds.put(role, UUID.fromString(nc.getString(role))); } catch (IllegalArgumentException ignored) {}
            }
            s.name = c.getString("name");
            NbtList al = c.getList("ach", NbtElement.STRING_TYPE);
            for (int i = 0; i < al.size(); i++) s.ach.add(al.getString(i));
            NbtList sl = c.getList("subs", NbtElement.STRING_TYPE);
            for (int i = 0; i < sl.size(); i++) {
                try { s.subs.add(UUID.fromString(sl.getString(i))); } catch (IllegalArgumentException ignored) {}
            }
            NbtCompound bc = c.getCompound("builds");
            for (String bk : bc.getKeys()) s.builds.put(bk, bc.getIntArray(bk));
            st.map.put(UUID.fromString(k), s);
        }
        NbtList cl = nbt.getList("crews", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < cl.size(); i++) {
            NbtCompound cc = cl.getCompound(i);
            Crew cr = new Crew();
            cr.name = cc.getString("name");
            String ld = cc.getString("leader");
            cr.leader = ld.isEmpty() ? null : UUID.fromString(ld);
            cr.treasury = cc.getInt("treasury");
            cr.rep = cc.getInt("rep");
            int[] hqa = cc.getIntArray("hq");
            cr.hq = hqa.length == 6 ? hqa : null;
            NbtList ml = cc.getList("members", NbtElement.COMPOUND_TYPE);
            for (int j = 0; j < ml.size(); j++) {
                NbtCompound mc = ml.getCompound(j);
                Member m = new Member();
                m.name = mc.getString("name");
                m.rank = mc.getInt("rank");
                cr.members.put(UUID.fromString(mc.getString("id")), m);
            }
            st.crews.put(cr.name, cr);
        }
        NbtCompound dcr = nbt.getCompound("districts");
        for (String dk : dcr.getKeys()) st.districts.put(dk, dcr.getString(dk));
        return st;
    }
}
