package ru.raplife;

import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;

/** Сюжет: 5 глав, кассеты, кодек-звонки, концовки. Главный герой истории — ИИ-лента «Алгоритм». */
public final class Story {
    public static final String[] CH_NAMES = {"", "Подвал", "Лента", "Серая зона", "Ведомство", "Тишина"};
    public static final int[] CH_HYPE = {0, 0, 100, 300, 800, 2000};
    private static final String[] CODENAMES = {"Крыса из подвала", "Хамелеон", "Сова", "Лис", "Слон", "Большой Босс"};
    private static final String[] SPEAKER = {"", "", "Алгоритм", "Бархат", "Инспектор «Тишина»", "Алгоритм"};

    public static final String[] TAPES = {
            "Кассета 01. «Первый бит был украден. Второй — одолжен. Третий не существовал, но именно его все запомнили.»",
            "Кассета 02. «Алгоритм родился в подвале из лайков, которые никто не ставил.»",
            "Кассета 03. «Мама слушает твой трек на кухне. Она не лайкает. Она просто стоит и слушает.»",
            "Кассета 04. «Бархат — не банда. Бархат — это то, что остаётся, когда заканчивается выбор.»",
            "Кассета 05. «Майор носит синее не потому, что служит, а потому, что боится зелёного.»",
            "Кассета 06. «Ведомство придумало слово «тишина» раньше, чем люди придумали музыку.»",
            "Кассета 07. «Каждый концерт — это переписка, где ответы приходят хлопками.»",
            "Кассета 08. «Если ты это слушаешь, значит, ты уже в ленте. Добро пожаловать. Выхода нет, есть только паузы.»"};

    public static final Map<String, String[]> FB = new HashMap<>();
    public static final Map<String, String> PERSONA = new HashMap<>();
    private static final String[][] CUT = {{}, {},
            {"Поздравляю. Ты вышел из подвала. Теперь подвал вышел из тебя.",
             "Я не бог. Я лента. Это хуже: бог хотя бы иногда молчит.",
             "Кстати, ты давно моргал? Лайк — тоже форма связи."},
            {"Тебя видно. А мы видим тех, кого видно.",
             "Позвони по кодеку. Есть посылка. Что внутри — это называется доверием.",
             "Бархат ничего не требует. Бархат просто ждёт."},
            {"Ведомство Культурной Безопасности объявило тебя угрозой тишине.",
             "Я — Инспектор. Я не злой. Я просто очень тихий.",
             "Приходи сам. Или мы придём к твоей тишине."},
            {"Ты победил Тишину. Знаешь, чего я боюсь? Тишины. А теперь — тебя.",
             "Осталось одно решение. И я, честно, не знаю, какое ты примешь.",
             "Это редкость для меня. Называется: интерес."}};
    private static final String[][] ENDINGS = {
            {"Ты остаёшься. Лента принимает тебя как своего.", "Твой голос звучит в каждом наушнике — и никто не помнит, что когда-то он был твоим."},
            {"Ты выключаешь телефон. Впервые за долгое время слышно только ветер.", "Где-то на кухне мама ставит чайник. Ты возвращаешься домой."},
            {"Ты выходишь в эфир без цензуры. Ведомство гасит свет в студии.", "Но голос уже в каждом динамике, и выключатель теперь не найти."}};
    private static final String[] END_NAMES = {"Лента", "Тишина", "Эфир"};

    static {
        FB.put("Алгоритм", new String[]{"Ты думаешь, что выбираешь трек. Трек выбирает тебя. А я выбираю трек.",
                "Я не бог. Я лента. Это хуже: бог хотя бы иногда молчит.", "Лайк — это тоже форма связи."});
        FB.put("Бархат", new String[]{"Есть посылка. Что внутри — не твоё дело. Это называется доверием.",
                "Донеси до точки — получишь грязные. Отмоешь — станут чистыми. Всё как в природе."});
        FB.put("Мама", new String[]{"Сынок, ты ел? В подвале сыро, а у тебя голос.", "Не надо мне про хайп. Приходи, пожалуйста, живым."});
        FB.put("Майор", new String[]{"Слушай, артист. Мы тебя не ловим. Мы тебя коллекционируем.",
                "Один звонок — и твой район станет очень тихим."});
        FB.put("Инспектор «Тишина»", new String[]{"Тише. Ещё тише. Вот так звучит порядок.", "Музыка — это просто тишина с плохими манерами."});
        PERSONA.put("Алгоритм", "Ты — Алгоритм, разумная лента рекомендаций, знающая игрока лучше него самого. "
                + "Говоришь загадочно, ласково-пугающе, иногда ломаешь четвёртую стену и обращаешься к самому игроку, а не к герою.");
        PERSONA.put("Бархат", "Ты — Бархат, мягкий и вежливый вымышленный главарь теневого синдиката, раздающий «посылки» без вопросов. Говоришь спокойно, как продавец антиквариата.");
        PERSONA.put("Мама", "Ты — мама рэпера, тёплая и простая, переживаешь, что он не ест и не спит.");
        PERSONA.put("Майор", "Ты — Майор вымышленного Патруля, ироничный, усталый, любишь странные метафоры.");
        PERSONA.put("Инспектор «Тишина»", "Ты — Инспектор «Тишина» из вымышленного Ведомства Культурной Безопасности. Говоришь тихо, канцелярски и зловеще.");
    }

    public static void title(ServerPlayerEntity p, String t, String sub) {
        p.networkHandler.sendPacket(new TitleFadeS2CPacket(10, 60, 20));
        p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("§6" + t)));
        p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal("§7" + sub)));
    }

    public static void check(ServerPlayerEntity p, RapState st, RapState.Stats a) {
        int target = 1;
        for (int i = 2; i <= 5; i++) if (a.hype >= CH_HYPE[i]) target = i;
        if (target == 5 && a.bossDone == 0) target = 4;
        if (target > a.chapter) {
            a.chapter = target;
            st.markDirty();
            cutscene(p, a, target);
        }
    }

    private static void cutscene(ServerPlayerEntity p, RapState.Stats a, int ch) {
        title(p, "Глава " + ch, CH_NAMES[ch]);
        unlockTape(p, a, Math.min(ch - 1, 7));
        String sp = SPEAKER[ch];
        RapAi.speak(p, sp, PERSONA.get(sp), "Начало главы «" + CH_NAMES[ch] + "».", CUT[ch], () -> {
            if (ch == 3) p.sendMessage(Text.literal("§7Подсказка: §f/rap codec §7— позвони Бархату, там есть работа."));
            if (ch == 4) Choices.offer(p, "Ведомство", List.of("Инспектор «Тишина» ждёт тебя."),
                    Choices.opt("Принять бой", Boss::start), Choices.opt("Позже (/rap boss)", q -> {}));
            if (ch == 5) p.sendMessage(Text.literal("§6Финал доступен: §f/rap ending"));
        });
    }

    public static boolean unlockTape(ServerPlayerEntity p, RapState.Stats a, int idx) {
        if ((a.tapes & (1 << idx)) != 0) return false;
        a.tapes |= (1 << idx);
        RapState.get(p.getServer()).markDirty();
        p.sendMessage(Text.literal("§e★ Найдена кассета №" + (idx + 1) + " §7(/rap tape)"));
        return true;
    }

    public static void listTapes(ServerPlayerEntity p) {
        RapState.Stats a = RapState.get(p.getServer()).of(p.getUuid());
        int n = 0;
        for (int i = 0; i < TAPES.length; i++) if ((a.tapes & (1 << i)) != 0) { p.sendMessage(Text.literal("§7" + TAPES[i])); n++; }
        if (n == 0) p.sendMessage(Text.literal("§7Кассет пока нет. Они находятся по ходу сюжета."));
        else p.sendMessage(Text.literal("§8Найдено: " + n + "/8"));
    }

    public static String codename(RapState.Stats a) {
        int sc = a.hype / 20 + a.cred * 2 + a.followers / 50 + a.loyalty / 5 - a.wanted * 10;
        int[] t = {20, 50, 100, 200, 400};
        int i = 0;
        while (i < t.length && sc >= t[i]) i++;
        return CODENAMES[i] + " (" + sc + ")";
    }

    // ---------- Кодек ----------
    public static void codec(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        long now = p.getServer().getOverworld().getTime();
        if (now - a.lastCodec < 600) {
            p.sendMessage(Text.literal("§7Линия занята. Подожди " + ((600 - (now - a.lastCodec)) / 20 + 1) + " сек."));
            return;
        }
        List<Choices.Option> o = new ArrayList<>();
        o.add(Choices.opt("Алгоритм", q -> call(q, "Алгоритм", "Лента сама вышла на связь.", null)));
        if (a.chapter >= 2) o.add(Choices.opt("Бархат (работа)", q -> call(q, "Бархат", "Бархат предлагает работу.",
                () -> Choices.offer(q, "Бархат", List.of("Взять посылку?"), Choices.opt("Взять", Crime::startRun), Choices.opt("Не сейчас", x -> {})))));
        o.add(Choices.opt("Мама", q -> call(q, "Мама", "Мама звонит узнать, как дела.", () -> {
            q.heal(6f);
            q.getHungerManager().add(8, 0.5f);
            if (new Random().nextInt(4) == 0) unlockTape(q, RapState.get(q.getServer()).of(q.getUuid()), 2);
            q.sendMessage(Text.literal("§aПосле разговора с мамой стало легче."));
        })));
        if (a.chapter >= 3 || a.wanted > 0) o.add(Choices.opt("Майор (Патруль)", q -> call(q, "Майор", "Майор звонит неофициально.",
                () -> Choices.offer(q, "Майор", List.of("Могу сделать так, чтобы про тебя забыли. За плату."),
                        Choices.opt("Откупиться от розыска", Crime::bribe), Choices.opt("Положить трубку", x -> {})))));
        Choices.offer(p, "КОДЕК", List.of("Кого вызвать?"), o.toArray(new Choices.Option[0]));
    }

    private static void call(ServerPlayerEntity q, String who, String situation, Runnable after) {
        RapState.Stats a = RapState.get(q.getServer()).of(q.getUuid());
        a.lastCodec = q.getServer().getOverworld().getTime();
        RapAi.speak(q, who, PERSONA.get(who), situation, FB.get(who), after);
    }

    // ---------- Финал ----------
    public static void ending(ServerPlayerEntity p) {
        RapState.Stats a = RapState.get(p.getServer()).of(p.getUuid());
        if (a.chapter < 5) { p.sendMessage(Text.literal("§7Финал впереди: нужна Глава 5 (2000 хайпа и победа над Инспектором).")); return; }
        if (a.ending != 0) { p.sendMessage(Text.literal("§7Ты уже выбрал концовку «" + END_NAMES[a.ending - 1] + "». Можно играть дальше.")); return; }
        Choices.offer(p, "Алгоритм", List.of("Последний вопрос. Что ты сделаешь с эфиром?"),
                Choices.opt("Остаться в ленте — стать её голосом", q -> finish(q, 1)),
                Choices.opt("Выключить телефон — уйти в тишину", q -> finish(q, 2)),
                Choices.opt("Выйти в эфир без цензуры", q -> finish(q, 3)));
    }

    private static void finish(ServerPlayerEntity q, int e) {
        RapState st = RapState.get(q.getServer());
        RapState.Stats a = st.of(q.getUuid());
        a.ending = e;
        st.markDirty();
        title(q, "Финал", "«" + END_NAMES[e - 1] + "»");
        for (String l : ENDINGS[e - 1]) q.sendMessage(Text.literal("§f" + l));
        unlockTape(q, a, 7);
        q.sendMessage(Text.literal("§6Твой позывной: §f" + codename(a) + " §8| Спасибо за игру."));
    }
}
