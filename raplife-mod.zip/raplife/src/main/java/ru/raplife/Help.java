package ru.raplife;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public final class Help {
    public static void onJoin(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(p.getUuid());
        boolean first = a.name.isEmpty();
        a.name = p.getName().getString();
        st.markDirty();
        if (first) {
            a.addMoney(300);
            kit(p);
            Gui.say(p, "§6=== Rap Life: Подвал → Стадион ===");
            Gui.say(p, "§fТы начинающий рэпер. Тебе выдали §eТелефон§f и §eМикрофон§f, на счету 300 ₽.");
            show(p);
        } else {
            Gui.say(p, "§7С возвращением, §f" + a.name + "§7. §8/rap — меню, /rap help — подсказки.");
        }
    }

    private static boolean has(ServerPlayerEntity p, Item it) {
        for (int i = 0; i < p.getInventory().size(); i++) if (p.getInventory().getStack(i).isOf(it)) return true;
        return false;
    }

    public static void kit(ServerPlayerEntity p) {
        boolean gave = false;
        if (!has(p, RapLifeMod.PHONE)) { p.giveItemStack(new ItemStack(RapLifeMod.PHONE)); gave = true; }
        if (!has(p, RapLifeMod.MIC)) { p.giveItemStack(new ItemStack(RapLifeMod.MIC)); gave = true; }
        Gui.say(p, gave ? "§aСтартовый набор выдан." : "§7У тебя уже есть и Телефон, и Микрофон.");
    }

    public static void show(ServerPlayerEntity p) {
        Gui.say(p, "§eКак играть:");
        Gui.say(p, "§f1. §7ПКМ телефоном (или §f/rap§7) — меню всех приложений. Shift+ПКМ — лента ТикТока.");
        Gui.say(p, "§f2. §7ПКМ микрофоном — фристайл (+хайп). Запись трека: приложение «Студия» или §f/rap track <название>§7.");
        Gui.say(p, "§f3. §7Треки сами зарабатывают на Облачке; роялти выводи в «Стриминге». От 100 хайпа — концерты и фанаты.");
        Gui.say(p, "§f4. §7Деньги тратятся в «Магазине» и «Стройке»: дом, студия, клуб, гараж, мерч.");
        Gui.say(p, "§f5. §7«Кодек» открывает сюжет: Алгоритм, Бархат (серые схемы), Мама, Майор.");
        Gui.say(p, "§eС друзьями:");
        Gui.say(p, "§f• §7«Игроки» в телефоне: подписки, фиты, баттлы, переводы, подарки, концерты, вечеринки.");
        Gui.say(p, "§f• §7Crew: §f/rap crew create <название>§7, приглашения, общак, районы, чат §f/rap cc <текст>§7.");
        Gui.say(p, "§8Если потерял предметы: /rap kit. Все команды: §f/rap§8 + Tab.");
    }
}
