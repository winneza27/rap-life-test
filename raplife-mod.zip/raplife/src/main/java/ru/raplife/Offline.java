package ru.raplife;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Запасной генератор, если ИИ не настроен или недоступен. */
public final class Offline {
    private static final Random R = new Random();

    private static final String[] L1 = {"Туман в голове, как дым над гаражами", "Жду свой звук в наушниках, пока район спит",
            "Бит качает стены в этом подвале", "Телефон горит, а в директе тишина", "Пятый этаж, но я смотрю на звёзды"};
    private static final String[] L2 = {"Мы с пацанами строим планы без бумаги", "В сторис — мой город, в сердце — пустота",
            "Кеды стёрты, зато флоу выше крыши", "Снова ночь, снова демка на повторе", "Лайки считаю вместо овец"};

    public static List<String> lyrics(String title) {
        List<String> l = new ArrayList<>();
        l.add("§f" + L1[R.nextInt(L1.length)]);
        l.add("§f" + L2[R.nextInt(L2.length)]);
        l.add("§f" + L1[R.nextInt(L1.length)]);
        l.add("§f" + L2[R.nextInt(L2.length)]);
        return l;
    }

    private static final String[] VIDEOS = {"Парень танцует под твой трек в лифте", "Фанат переозвучил хук на ютубе-котиков",
            "Блогер ругает твой кроссфейд, но всё равно слушает на повторе", "Подборка «звуки района» с твоим битом",
            "Школьник читает твой куплет на уроке литературы"};
    private static final String[] COMMENTS = {"это же огонь", "бит просто космос", "кто пришёл с рекомендаций?",
            "автотюн решает", "прыгаю на кровати 3 часа", "лучше, чем у тех, кто в чартах"};

    public static List<String> feed() {
        List<String> l = new ArrayList<>();
        for (int i = 0; i < 3; i++)
            l.add(VIDEOS[R.nextInt(VIDEOS.length)] + " | " + COMMENTS[R.nextInt(COMMENTS.length)]);
        return l;
    }
}
