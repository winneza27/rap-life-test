package ru.raplife;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.HorseEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.List;

/** Магазин: дома, машины, украшения, одежда и «серый рынок» (абстрактный товар для доставок). */
public final class Shop {
    private record Prod(String id, String cat, String name, int price, Item icon, int style, String desc) {}

    private static final String[] CATS = {"Дом", "Машина", "Украшения", "Одежда", "Серый рынок"};
    private static final Item[] CAT_ICONS = {Items.OAK_DOOR, Items.MINECART, Items.DIAMOND, Items.LEATHER_CHESTPLATE, Items.BARREL};
    private static final int[] SLOTS = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};

    private static final List<Prod> P = List.of(
            new Prod("house1", "Дом", "Комната в общаге", 1500, Items.OAK_DOOR, 0, "+1 к качеству треков"),
            new Prod("house2", "Дом", "Квартира в центре", 8000, Items.IRON_DOOR, 0, "+2 к качеству треков"),
            new Prod("house3", "Дом", "Лофт-студия", 25000, Items.BRICKS, 0, "+3 к качеству треков"),
            new Prod("house4", "Дом", "Особняк на холме", 90000, Items.GOLD_BLOCK, 0, "+4 к качеству, +40 ₽/мин пассивно"),
            new Prod("car1", "Машина", "Старая «девятка»", 1200, Items.MINECART, 0, "Скорость ×1 (конь-тачка)"),
            new Prod("car2", "Машина", "Купе", 12000, Items.CHEST_MINECART, 0, "Скорость ×1.5"),
            new Prod("car3", "Машина", "Спорткар", 60000, Items.FURNACE_MINECART, 0, "Скорость ×2, прыгает"),
            new Prod("chain", "Украшения", "Золотая цепь", 3000, Items.CHAIN, 2, "Стиль +2"),
            new Prod("grillz", "Украшения", "Золотые грилзы", 5000, Items.GOLD_NUGGET, 3, "Стиль +3"),
            new Prod("watch", "Украшения", "Швейцарские часы", 9000, Items.CLOCK, 4, "Стиль +4"),
            new Prod("ring", "Украшения", "Бриллиантовый перстень", 20000, Items.DIAMOND, 6, "Стиль +6"),
            new Prod("cap", "Одежда", "Кепка", 500, Items.LEATHER_HELMET, 1, "Стиль +1"),
            new Prod("hoodie", "Одежда", "Оверсайз-худи", 800, Items.LEATHER_CHESTPLATE, 1, "Стиль +1"),
            new Prod("pants", "Одежда", "Широкие штаны", 1000, Items.LEATHER_LEGGINGS, 2, "Стиль +2"),
            new Prod("sneakers", "Одежда", "Кроссовки лимитка", 1500, Items.LEATHER_BOOTS, 2, "Стиль +2"),
            new Prod("jacket", "Одежда", "Дизайнерская куртка", 6000, Items.LEATHER_CHESTPLATE, 4, "Стиль +4"),
            new Prod("stash", "Серый рынок", "Партия товара", 400, Items.BARREL, 0,
                    "Абстрактный груз для доставок: ×2 к оплате за заказ, но больше проверок. До 3 партий. Можно платить грязными."));

    // ---------- бонусы от покупок ----------
    public static int style(RapState.Stats a) {
        int s = 0;
        for (Prod p : P) if (a.owned.contains(p.id())) s += p.style();
        return s;
    }

    public static int qualityBonus(RapState.Stats a) {
        for (int i = 4; i >= 1; i--) if (a.owned.contains("house" + i)) return i;
        return 0;
    }

    // ---------- GUI ----------
    public static void open(ServerPlayerEntity p, String cat) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        Gui.Builder b = new Gui.Builder("Магазин · " + cat, 6);
        b.set(0, Gui.icon(Items.EMERALD, "§aДеньги: " + a.money + " ₽", "§7Грязные: §c" + a.dirty + " ₽", "§7Стиль: §d" + style(a)), null);
        for (int i = 0; i < CATS.length; i++) {
            String c = CATS[i];
            b.set(2 + i, Gui.icon(CAT_ICONS[i], (c.equals(cat) ? "§e▶ " : "§f") + c), q -> open(q, c));
        }
        b.set(8, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        int n = 0;
        for (Prod pr : P) {
            if (!pr.cat().equals(cat) || n >= SLOTS.length) continue;
            boolean has = !pr.cat().equals("Серый рынок") && a.owned.contains(pr.id());
            b.set(SLOTS[n++], Gui.icon(pr.icon(), (has ? "§a✔ " : "§f") + pr.name(),
                    "§7" + pr.desc(), has ? "§aКуплено" : "§eЦена: " + pr.price() + " ₽"), q -> buy(q, pr));
        }
        if (cat.equals("Серый рынок")) b.set(40, Gui.icon(Items.PAPER, "§7В запасе партий: §f" + a.stash + "/3"), null);
        b.frame().open(p);
    }

    private static boolean pay(RapState.Stats a, int cost, boolean dirtyFirst) {
        if (a.money + (dirtyFirst ? a.dirty : 0) < cost) return false;
        int d = dirtyFirst ? Math.min(a.dirty, cost) : 0;
        a.dirty -= d;
        a.addMoney(-(cost - d));
        return true;
    }

    private static void buy(ServerPlayerEntity p, Prod pr) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        boolean gray = pr.cat().equals("Серый рынок");
        if (!gray && a.owned.contains(pr.id())) { Gui.say(p, "§7Это у тебя уже есть."); return; }
        if (gray && a.stash >= 3) { Gui.say(p, "§7Склад полон (3 партии)."); return; }
        if (!pay(a, pr.price(), gray)) { Gui.say(p, "§cНе хватает денег."); return; }
        if (gray) {
            a.stash++;
            Gui.say(p, "§8Партия получена. Следующий заказ от Бархата заплатит больше. Рискованнее.");
        } else {
            a.owned.add(pr.id());
            if (pr.cat().equals("Украшения") || pr.cat().equals("Одежда")) p.giveItemStack(wear(pr));
            Gui.say(p, "§aКуплено: " + pr.name());
        }
        st.markDirty();
        open(p, pr.cat());
    }

    private static void dye(ItemStack s, int rgb) { s.getOrCreateSubNbt("display").putInt("color", rgb); }

    private static ItemStack wear(Prod pr) {
        ItemStack s;
        switch (pr.id()) {
            case "chain" -> s = new ItemStack(Items.CHAIN);
            case "watch" -> s = new ItemStack(Items.CLOCK);
            case "grillz" -> s = new ItemStack(Items.GOLD_NUGGET);
            case "ring" -> s = new ItemStack(Items.DIAMOND);
            case "cap" -> { s = new ItemStack(Items.LEATHER_HELMET); dye(s, 0x1d1d1d); }
            case "hoodie" -> { s = new ItemStack(Items.LEATHER_CHESTPLATE); dye(s, 0x3a3a3a); }
            case "pants" -> { s = new ItemStack(Items.LEATHER_LEGGINGS); dye(s, 0x1f3a5f); }
            case "sneakers" -> { s = new ItemStack(Items.LEATHER_BOOTS); dye(s, 0xf2f2f2); }
            default -> { s = new ItemStack(Items.LEATHER_CHESTPLATE); dye(s, 0x7b2cbf); }
        }
        s.setCustomName(Text.literal("§d" + pr.name()).styled(x -> x.withItalic(false)));
        return s;
    }

    // ---------- дом ----------
    public static void home(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (qualityBonus(a) == 0) { Gui.say(p, "§7У тебя нет дома. Загляни в магазин."); return; }
        if (a.homeSet == 0) { Gui.say(p, "§7Точка дома не задана. Встань у своего дома и введи §f/rap home set"); return; }
        if (a.wanted > 0) { Gui.say(p, "§cПока ты в розыске, домой нельзя — приведёшь хвост."); return; }
        p.teleport(p.getServer().getOverworld(), a.homeX + 0.5, a.homeY, a.homeZ + 0.5, p.getYaw(), p.getPitch());
        Gui.say(p, "§7Ты дома.");
    }

    public static void homeSet(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (qualityBonus(a) == 0) { Gui.say(p, "§7Сначала купи дом."); return; }
        BlockPos bp = p.getBlockPos();
        a.homeSet = 1; a.homeX = bp.getX(); a.homeY = bp.getY(); a.homeZ = bp.getZ();
        st.markDirty();
        Gui.say(p, "§aТочка дома сохранена.");
    }

    // ---------- гараж ----------
    public static void openGarage(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        Gui.Builder b = new Gui.Builder("Гараж", 3);
        int slot = 10;
        for (Prod pr : P) {
            if (!pr.cat().equals("Машина")) continue;
            boolean has = a.owned.contains(pr.id());
            b.set(slot, Gui.icon(pr.icon(), (has ? "§a" : "§8") + pr.name(), has ? "§7Клик — вызвать к себе" : "§cНе куплено"),
                    has ? q -> summon(q, pr.id(), pr.name()) : null);
            slot += 2;
        }
        b.set(16, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(p);
    }

    private static void summon(ServerPlayerEntity p, String id, String name) {
        ServerWorld w = p.getServerWorld();
        w.getEntitiesByType(net.minecraft.util.TypeFilter.instanceOf(HorseEntity.class),
                h -> h.getCommandTags().contains("raplife_car") && h.getCommandTags().contains("owner:" + p.getUuidAsString()))
                .forEach(Entity::discard);
        HorseEntity h = EntityType.HORSE.create(w);
        if (h == null) return;
        int[] g = RapState.get(p.getServer()).of(p.getUuid()).builds.get("garage");
        if (g != null) h.refreshPositionAndAngles(g[0] + g[3] / 2.0, g[1] + 1, g[2] + g[4] / 2.0, 0f, 0f);
        else h.refreshPositionAndAngles(p.getX() + 2, p.getY(), p.getZ(), p.getYaw(), 0f);
        h.setCustomName(Text.literal("§b" + name));
        h.setCustomNameVisible(true);
        h.setTame(true);
        h.setOwnerUuid(p.getUuid());
        h.saddle(null);
        double speed = id.equals("car1") ? 0.26 : id.equals("car2") ? 0.34 : 0.45;
        var sp = h.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (sp != null) sp.setBaseValue(speed);
        var jp = h.getAttributeInstance(EntityAttributes.HORSE_JUMP_STRENGTH);
        if (jp != null) jp.setBaseValue(id.equals("car3") ? 0.9 : 0.6);
        var hp = h.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (hp != null) hp.setBaseValue(40);
        h.setHealth(40f);
        h.addCommandTag("raplife_car");
        h.addCommandTag("owner:" + p.getUuidAsString());
        h.setPersistent();
        w.spawnEntity(h);
        p.closeHandledScreen();
        Gui.say(p, "§bТачка подана: " + name + ". ПКМ — садись.");
    }
}
