package ru.raplife;

import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** «Инста»: посты с подписями от ИИ, лайки, прирост подписчиков, шанс скандала. */
public final class Social {
    private static final Random R = new Random();
    private static final Map<UUID, Long> LAST = new HashMap<>();
    private static final String[] OFF = {"новый вайб, старый район", "тишина в студии громче битов", "спасибо что вы есть", "ночь, окно, бит"};

    public static void open(ServerPlayerEntity p) {
        Gui.Builder b = new Gui.Builder("Инста", 3);
        b.set(11, Gui.icon(Items.LEATHER_CHESTPLATE, "§dФото в новом шмоте", "§7Лучше работает со стилем"), q -> { q.closeHandledScreen(); post(q, 0); });
        b.set(13, Gui.icon(Items.NOTE_BLOCK, "§fЗакулисье студии", "§7Живые кадры"), q -> { q.closeHandledScreen(); post(q, 1); });
        b.set(15, Gui.icon(Items.MUSIC_DISC_13, "§bАнонс трека", "§7×1.3 к охвату, нужен трек"), q -> { q.closeHandledScreen(); post(q, 2); });
        b.set(22, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(p);
    }

    public static void post(ServerPlayerEntity p, int kind) {
        MinecraftServer s = p.getServer();
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(p.getUuid());
        long now = s.getOverworld().getTime();
        Long last = LAST.get(p.getUuid());
        if (last != null && now - last < 2400) { Gui.say(p, "§7Подожди: пост раз в 2 минуты."); return; }
        if (kind == 2 && a.tracks.isEmpty()) { Gui.say(p, "§7Сначала запиши трек."); return; }
        LAST.put(p.getUuid(), now);
        String[] kinds = {"фото в новом шмоте", "закулисье студии", "анонс нового трека"};
        String user = "Придумай короткую подпись (до 90 символов) к посту рэпера «" + p.getName().getString() + "»: "
                + kinds[kind] + ". Без мата и без хэштегов. Верни только подпись.";
        Gui.say(p, "§7Публикуем пост" + (Config.get().ready() ? " (ИИ пишет подпись)..." : "..."));
        AiClient.ask(RapAi.SYSTEM, user).thenAccept(t -> s.execute(() -> {
            List<String> l = RapAi.lines(t, 1);
            String cap = l.isEmpty() ? OFF[R.nextInt(OFF.length)] : l.get(0);
            double f = 0.05 + R.nextDouble() * 0.15;
            if (kind == 0) f *= 1 + Shop.style(a) / 15.0;
            if (kind == 2) f *= 1.3;
            int likes = (int) (a.followers * f) + 5;
            a.followers += likes / 10;
            a.addHype(likes / 200);
            Gui.say(p, "§d[Инста] §f«" + cap + "»");
            Gui.say(p, "§7Лайков: §e" + likes + " §7| подписчиков: §a+" + likes / 10);
            if (R.nextInt(100) < 10) {
                a.addLoyalty(-4);
                a.repGov -= 1;
                Gui.say(p, "§cСкандал в комментариях: пост поняли не так. §7-4 лояльности");
            }
            st.markDirty();
        }));
    }
}
