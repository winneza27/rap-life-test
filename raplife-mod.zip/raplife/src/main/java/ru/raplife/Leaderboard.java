package ru.raplife;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.*;

public final class Leaderboard {
    private record Row(String artist, RapState.Track t) {}

    public static void open(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        List<Map.Entry<UUID, RapState.Stats>> pl = new ArrayList<>(st.entries());
        pl.sort((x, y) -> Integer.compare(y.getValue().hype, x.getValue().hype));
        List<RapState.Crew> cr = new ArrayList<>(st.crews.values());
        cr.sort((x, y) -> Integer.compare(y.rep, x.rep));
        List<Row> tracks = new ArrayList<>();
        for (Map.Entry<UUID, RapState.Stats> e : pl) {
            String nm = e.getValue().name.isEmpty() ? "Игрок" : e.getValue().name;
            for (RapState.Track t : e.getValue().tracks) tracks.add(new Row(nm, t));
        }
        tracks.sort((x, y) -> Long.compare(y.t().streams, x.t().streams));

        Gui.Builder b = new Gui.Builder("Топ: рэперы, crew и чарт", 6);
        b.set(0, Gui.icon(Items.GOLD_INGOT, "§6Топ рэперов по хайпу"), null);
        for (int i = 0; i < pl.size() && i < 7; i++) {
            RapState.Stats a = pl.get(i).getValue();
            String nm = a.name.isEmpty() ? "Игрок" : a.name;
            ItemStack h = Gui.icon(Items.PLAYER_HEAD, "§f#" + (i + 1) + " " + nm, "§7Хайп: §e" + a.hype, "§7Подписчики: §f" + a.followers,
                    "§7Слушатели: §f" + (a.listenersCloud + a.listenersSpot), "§7Бифы: §a" + a.beefWins + "§7/§c" + a.beefLosses);
            if (!a.name.isEmpty()) h.getOrCreateNbt().putString("SkullOwner", a.name);
            b.set(10 + i, h, null);
        }
        b.set(18, Gui.icon(Items.WHITE_BANNER, "§eТоп crew по репутации"), null);
        for (int i = 0; i < cr.size() && i < 7; i++) {
            RapState.Crew c = cr.get(i);
            int d = 0;
            for (String o : st.districts.values()) if (o.equals(c.name)) d++;
            b.set(19 + i, Gui.icon(Items.WHITE_BANNER, "§f#" + (i + 1) + " " + c.name, "§7Репутация: §e" + c.rep, "§7Участников: §f" + c.members.size(),
                    "§7Районов: §a" + d, "§7Общак: §a" + c.treasury + " ₽"), null);
        }
        b.set(27, Gui.icon(Items.JUKEBOX, "§bЧарт треков сервера"), null);
        for (int i = 0; i < tracks.size() && i < 7; i++) {
            Row r = tracks.get(i);
            b.set(28 + i, Gui.icon(r.t().diss ? Items.MUSIC_DISC_WARD : Items.MUSIC_DISC_13, "§f#" + (i + 1) + " «" + r.t().title + "»",
                    "§7Артист: §e" + r.artist(), "§7Прослушиваний: §f" + r.t().streams, "§7Качество: §e" + r.t().quality + "/10"), null);
        }
        b.set(49, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(p);
    }
}
