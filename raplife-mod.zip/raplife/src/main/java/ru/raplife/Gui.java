package ru.raplife;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/** Свои GUI: серверные меню на базе сундуков. Работают на ванильном клиенте. */
public final class Gui {

    public static ItemStack icon(Item item, String name, String... lore) {
        ItemStack s = new ItemStack(item);
        s.setCustomName(Text.literal(name).styled(x -> x.withItalic(false)));
        if (lore.length > 0) {
            NbtList l = new NbtList();
            for (String t : lore) l.add(NbtString.of(Text.Serializer.toJson(Text.literal(t).styled(x -> x.withItalic(false)))));
            s.getOrCreateSubNbt("display").put("Lore", l);
        }
        return s;
    }

    public static void say(ServerPlayerEntity p, String msg) { p.sendMessage(Text.literal(msg)); }

    public static final class Builder {
        private final int rows;
        private final String title;
        private final SimpleInventory inv;
        private final Map<Integer, Consumer<ServerPlayerEntity>> acts = new HashMap<>();

        public Builder(String title, int rows) {
            this.title = title;
            this.rows = rows;
            this.inv = new SimpleInventory(rows * 9);
        }

        public Builder set(int slot, ItemStack s, Consumer<ServerPlayerEntity> act) {
            if (slot >= 0 && slot < rows * 9) {
                inv.setStack(slot, s);
                if (act != null) acts.put(slot, act);
            }
            return this;
        }

        public Builder frame() {
            ItemStack pane = icon(Items.GRAY_STAINED_GLASS_PANE, " ");
            for (int i = 0; i < rows * 9; i++) if (inv.getStack(i).isEmpty()) inv.setStack(i, pane.copy());
            return this;
        }

        public void open(ServerPlayerEntity p) {
            p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                    (id, pi, pl) -> new Menu(id, pi, inv, rows, acts), Text.literal(title)));
        }
    }

    private static ScreenHandlerType<GenericContainerScreenHandler> typeFor(int rows) {
        return switch (rows) {
            case 1 -> ScreenHandlerType.GENERIC_9X1;
            case 2 -> ScreenHandlerType.GENERIC_9X2;
            case 3 -> ScreenHandlerType.GENERIC_9X3;
            case 4 -> ScreenHandlerType.GENERIC_9X4;
            case 5 -> ScreenHandlerType.GENERIC_9X5;
            default -> ScreenHandlerType.GENERIC_9X6;
        };
    }

    private static final class Menu extends GenericContainerScreenHandler {
        private final int rows;
        private final Map<Integer, Consumer<ServerPlayerEntity>> acts;

        Menu(int syncId, PlayerInventory pi, SimpleInventory inv, int rows, Map<Integer, Consumer<ServerPlayerEntity>> acts) {
            super(typeFor(rows), syncId, pi, inv, rows);
            this.rows = rows;
            this.acts = acts;
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (slot >= 0 && slot < rows * 9 && player instanceof ServerPlayerEntity sp
                    && (type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE)) {
                Consumer<ServerPlayerEntity> c = acts.get(slot);
                if (c != null) c.accept(sp);
            }
            // всё остальное игнорируем: предметы из меню забрать нельзя
        }

        @Override
        public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
