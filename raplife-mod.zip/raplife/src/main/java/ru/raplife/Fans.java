package ru.raplife;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypeFilter;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.*;

/** Фанаты: появляются рядом, общаются через ИИ, селфи/автограф/пение. Плюс фиты между игроками. */
public final class Fans {
    public static final String TAG = "raplife_fan";
    private static final Random R = new Random();
    private static final String[] NAMES = {"Дима", "Аня", "Костя", "Лиза", "Тёма", "Вика", "Илья", "Саша", "Оля", "Макс"};
    private static final String[] FB = {"Это вы?! Я ваш трек на репите гоняю!", "Можно селфи? Мне никто не поверит.",
            "Вы на сцене огонь, а вживую ещё лучше!", "Когда новый трек? Мы уже ждём!"};

    public static void spawnFans(MinecraftServer s) {
        RapState st = RapState.get(s);
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            RapState.Stats a = st.of(p.getUuid());
            if (a.hype < 50) continue;
            ServerWorld w = p.getServerWorld();
            int idx = RapState.stageIndex(a.hype);
            int near = w.getEntitiesByType(TypeFilter.instanceOf(VillagerEntity.class),
                    v -> v.getCommandTags().contains(TAG) && v.squaredDistanceTo(p) < 40 * 40).size();
            if (near >= 3 + idx) continue;
            int n = 1 + R.nextInt(1 + idx);
            for (int i = 0; i < n; i++) {
                double ang = R.nextDouble() * Math.PI * 2, d = 8 + R.nextInt(8);
                int x = (int) (p.getX() + Math.cos(ang) * d), z = (int) (p.getZ() + Math.sin(ang) * d);
                int y = w.getRegistryKey() == World.OVERWORLD ? w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) : (int) p.getY();
                VillagerEntity v = EntityType.VILLAGER.create(w);
                if (v == null) continue;
                v.refreshPositionAndAngles(x + 0.5, y, z + 0.5, R.nextFloat() * 360f, 0f);
                v.setCustomName(Text.literal("Фанат ").formatted(Formatting.LIGHT_PURPLE)
                        .append(Text.literal(NAMES[R.nextInt(NAMES.length)]).formatted(Formatting.WHITE)));
                v.setCustomNameVisible(true);
                v.addCommandTag(TAG);
                v.setPersistent();
                w.spawnEntity(v);
            }
            p.sendMessage(Text.literal("§d▶ Рядом заметили фанатов. §7ПКМ с телефоном — селфи, с микрофоном — спеть, с пустой рукой — поговорить."), true);
        }
    }

    public static ActionResult onUse(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hit) {
        if (!(entity instanceof VillagerEntity) || !entity.getCommandTags().contains(TAG)) return ActionResult.PASS;
        if (world.isClient || hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity sp)) return ActionResult.SUCCESS;
        MinecraftServer s = sp.getServer();
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(sp.getUuid());
        ServerWorld w = sp.getServerWorld();
        String name = entity.getCustomName() == null ? "Фанат" : entity.getCustomName().getString();

        if (sp.getMainHandStack().isOf(RapLifeMod.PHONE)) {
            a.addHype(8); a.addLoyalty(3); a.followers += 5 + R.nextInt(15);
            st.markDirty();
            sp.sendMessage(Text.literal("§dСелфи с фанатом! §e+8 хайпа, +лояльность"));
            leave(w, entity);
        } else if (sp.getMainHandStack().isOf(RapLifeMod.MIC)) {
            a.addHype(4); a.addLoyalty(5);
            st.markDirty();
            sp.sendMessage(Text.literal("§dТы спел для одного человека. Он запомнит это навсегда. §e+4 хайпа, +лояльность"));
            leave(w, entity);
        } else if (!Choices.hasPending(sp.getUuid())) {
            RapAi.speak(sp, name, "Ты — фанат рэпера, встретил его на улице. Говоришь искренне, коротко, можешь попросить автограф или пожаловаться на жизнь.",
                    "Фанат подошёл к рэперу.", FB, () -> Choices.offer(sp, "Что ответить?", List.of(),
                            Choices.opt("Дать автограф", q -> { a.addHype(3); a.addLoyalty(4); st.markDirty(); q.sendMessage(Text.literal("§dАвтограф на ладони. Фанат счастлив.")); leave(w, entity); }),
                            Choices.opt("Попросить поддержать донатом", q -> {
                                int m = 20 + R.nextInt(40); a.addMoney(m); a.addLoyalty(-3); st.markDirty();
                                q.sendMessage(Text.literal("§eФанат скинул " + m + " ₽, но слегка приуныл.")); leave(w, entity); }),
                            Choices.opt("Отшить", q -> { a.addLoyalty(-4); st.markDirty(); q.sendMessage(Text.literal("§7Фанат ушёл, пнув камушек.")); leave(w, entity); })));
        }
        return ActionResult.SUCCESS;
    }

    private static void leave(ServerWorld w, Entity e) {
        w.spawnParticles(ParticleTypes.HEART, e.getX(), e.getY() + 1.5, e.getZ(), 8, 0.4, 0.4, 0.4, 0.1);
        e.discard();
    }

    // ---------- Фиты между игроками ----------
    private static final Map<UUID, UUID> REQ = new HashMap<>();

    public static void request(ServerPlayerEntity from, ServerPlayerEntity to) {
        if (from == to) { from.sendMessage(Text.literal("§7Фит с самим собой — это просто сольник.")); return; }
        REQ.put(to.getUuid(), from.getUuid());
        from.sendMessage(Text.literal("§dЗапрос на фит отправлен: " + to.getName().getString()));
        to.sendMessage(Text.literal("§d" + from.getName().getString() + " зовёт тебя на совместный трек ")
                .append(Text.literal("§a[ПРИНЯТЬ]").setStyle(Style.EMPTY.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/rap collab accept")))));
    }

    public static void accept(ServerPlayerEntity to) {
        MinecraftServer s = to.getServer();
        UUID fid = REQ.remove(to.getUuid());
        if (fid == null) { to.sendMessage(Text.literal("§7Нет входящих запросов.")); return; }
        ServerPlayerEntity from = s.getPlayerManager().getPlayer(fid);
        if (from == null) { to.sendMessage(Text.literal("§7Партнёр вышел из сети.")); return; }
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(to.getUuid()), b = st.of(from.getUuid());
        long now = s.getOverworld().getTime();
        if (now - a.lastCollab < 6000 || now - b.lastCollab < 6000) { to.sendMessage(Text.literal("§7Студия занята: фиты не чаще раза в 5 минут.")); return; }
        a.lastCollab = now; b.lastCollab = now;
        for (RapState.Stats x : List.of(a, b)) { x.addHype(30); x.cred += 3; x.addLoyalty(2); x.followers += 60; }
        st.markDirty();
        String msg = "§6♪ Совместный трек «" + from.getName().getString() + " x " + to.getName().getString() + "» вышел! §e+30 хайпа, +3 авторитета";
        from.sendMessage(Text.literal(msg));
        to.sendMessage(Text.literal(msg));
    }
}
