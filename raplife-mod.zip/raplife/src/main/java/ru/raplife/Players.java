package ru.raplife;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;

import java.util.*;

/** Взаимодействие игроков: список онлайн, профили, подписки, прослушивание, переводы, подарки, вечеринки, чат crew. */
public final class Players {
    private static final Map<UUID, Long> PARTY = new HashMap<>();
    private static final Map<String, Long> LAST = new HashMap<>();

    private static boolean onCooldown(String key, long now, long ticks) {
        Long l = LAST.get(key);
        if (l != null && now - l < ticks) return true;
        LAST.put(key, now);
        return false;
    }

    private static ServerPlayerEntity target(ServerPlayerEntity v, UUID tid) {
        ServerPlayerEntity t = v.getServer().getPlayerManager().getPlayer(tid);
        if (t == null) Gui.say(v, "§7Игрок вышел из сети.");
        return t;
    }

    private static Text button(String label, String cmd) {
        return Text.literal(label).setStyle(Style.EMPTY.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, cmd)));
    }

    public static int realFans(RapState st, UUID id) {
        int n = 0;
        for (Map.Entry<UUID, RapState.Stats> e : st.entries()) if (e.getValue().subs.contains(id)) n++;
        return n;
    }

    // ---------- список игроков ----------
    public static void open(ServerPlayerEntity v) {
        MinecraftServer s = v.getServer();
        RapState st = RapState.get(s);
        Gui.Builder b = new Gui.Builder("Игроки онлайн", 6);
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
        int i = 0;
        for (ServerPlayerEntity o : s.getPlayerManager().getPlayerList()) {
            if (o == v || i >= slots.length) continue;
            RapState.Stats a = st.of(o.getUuid());
            UUID id = o.getUuid();
            ItemStack h = Gui.icon(Items.PLAYER_HEAD, "§f" + o.getName().getString(),
                    "§7Этап: §f" + RapState.stageName(a.hype), "§7Хайп: §e" + a.hype + "  §7Подписчики: §f" + a.followers,
                    a.crew.isEmpty() ? "§8Без crew" : "§7Crew: §e" + a.crew,
                    Concert.active(id) ? "§dСейчас на концерте!" : "§8", PARTY.containsKey(id) ? "§aУ него вечеринка" : "§8", "§eКлик — действия");
            h.getOrCreateNbt().putString("SkullOwner", o.getName().getString());
            b.set(slots[i++], h, q -> menu(q, id));
        }
        if (i == 0) b.set(22, Gui.icon(Items.PAPER, "§7Сейчас на сервере только ты", "§7Позови друзей: фиты, баттлы и crew интереснее вместе"), null);
        b.set(4, Gui.icon(Items.PLAYER_HEAD, "§6Мои реальные подписчики: " + realFans(st, v.getUuid()), "§7Каждый даёт +5% к твоим стримам (до +50%)"), null);
        b.set(49, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(v);
    }

    private static void menu(ServerPlayerEntity v, UUID tid) {
        ServerPlayerEntity t = target(v, tid);
        if (t == null) { open(v); return; }
        RapState st = RapState.get(v.getServer());
        RapState.Stats me = st.of(v.getUuid()), ta = st.of(tid);
        boolean following = me.subs.contains(tid);
        RapState.Crew mc = st.crewOf(me);
        RapState.Member mm = mc == null ? null : mc.members.get(v.getUuid());
        boolean mod = mm != null && mm.rank >= 2;
        boolean sameCrew = mc != null && mc.name.equals(ta.crew);
        Gui.Builder b = new Gui.Builder(t.getName().getString(), 4);
        b.set(10, Gui.icon(Items.BOOK, "§fПрофиль"), q -> { q.closeHandledScreen(); profile(q, tid); });
        b.set(11, Gui.icon(following ? Items.RED_DYE : Items.LIME_DYE, following ? "§cОтписаться" : "§aПодписаться", "§7Реальные подписчики усиливают его стримы"), q -> { follow(q, tid); menu(q, tid); });
        b.set(12, Gui.icon(Items.JUKEBOX, "§bПослушать трек", "§7Его трек получает прослушивания"), q -> { listen(q, tid); menu(q, tid); });
        b.set(13, Gui.icon(Items.NOTE_BLOCK, "§dПредложить фит", "§7Совместный трек: +30 хайпа обоим"), q -> {
            ServerPlayerEntity tt = target(q, tid); if (tt != null) { q.closeHandledScreen(); Fans.request(q, tt); } });
        b.set(14, Gui.icon(Items.IRON_SWORD, "§cВызвать на баттл", "§7PvP: победитель +50 хайпа"), q -> {
            ServerPlayerEntity tt = target(q, tid); if (tt != null) { q.closeHandledScreen(); Beef.request(q, tt); } });
        if (mod && ta.crew.isEmpty()) b.set(15, Gui.icon(Items.WHITE_BANNER, "§eПозвать в crew"), q -> {
            ServerPlayerEntity tt = target(q, tid); if (tt != null) { q.closeHandledScreen(); CrewSys.invite(q, tt); } });
        b.set(16, Gui.icon(Items.EMERALD, "§aПеревод денег"), q -> payMenu(q, tid));
        b.set(19, Gui.icon(Items.CHEST, "§fПодарить предмет из руки", "§7Предмет в основной руке уйдёт игроку"), q -> { gift(q, tid); menu(q, tid); });
        if (sameCrew && mod && ta.wanted > 0) b.set(20, Gui.icon(Items.IRON_BARS, "§9Прикрыть (100 ₽)", "§7Снимет 1 звезду розыска члену crew"), q -> { cover(q, tid); menu(q, tid); });
        if (PARTY.containsKey(tid)) b.set(21, Gui.icon(Items.RED_BED, "§aНа вечеринку", "§7Телепорт к его дому"), q -> { q.closeHandledScreen(); visit(q, tid); });
        if (Concert.active(tid)) b.set(22, Gui.icon(Items.FIREWORK_ROCKET, "§6Прийти на концерт", "§7Ты станешь зрителем: бонус ему и тебе"), q -> {
            ServerPlayerEntity tt = target(q, tid); if (tt != null) { q.closeHandledScreen(); Concert.attend(q, tt); } });
        b.set(31, Gui.icon(Items.ARROW, "§7Назад"), Players::open);
        b.frame().open(v);
    }

    private static void payMenu(ServerPlayerEntity v, UUID tid) {
        Gui.Builder b = new Gui.Builder("Перевод", 3);
        int[] amounts = {100, 500, 1000, 5000};
        for (int i = 0; i < amounts.length; i++) {
            int amt = amounts[i];
            b.set(10 + i * 2, Gui.icon(Items.GOLD_NUGGET, "§a" + amt + " ₽"), q -> { pay(q, tid, amt); menu(q, tid); });
        }
        b.set(22, Gui.icon(Items.ARROW, "§7Назад"), q -> menu(q, tid));
        b.frame().open(v);
    }

    // ---------- действия ----------
    public static void profile(ServerPlayerEntity v, UUID tid) {
        ServerPlayerEntity t = target(v, tid);
        if (t == null) return;
        RapState st = RapState.get(v.getServer());
        RapState.Stats a = st.of(tid);
        Gui.say(v, "§6=== " + t.getName().getString() + " ===");
        Gui.say(v, "§eЭтап: §f" + RapState.stageName(a.hype) + "  §eХайп: §f" + a.hype + "  §eПодписчики: §f" + a.followers + "  §eРеальных: §f" + realFans(st, tid));
        Gui.say(v, "§eСлушатели: §bОблачко " + a.listenersCloud + " §7| §2Спотик " + a.listenersSpot + "  §eБифы: §a" + a.beefWins + "§7/§c" + a.beefLosses);
        Gui.say(v, "§eCrew: §f" + (a.crew.isEmpty() ? "нет" : a.crew) + "  §eСтиль: §d" + Shop.style(a) + "  §eПозывной: §7" + Story.codename(a));
        if (!a.tracks.isEmpty()) {
            RapState.Track top = a.tracks.get(0);
            Gui.say(v, "§eПоследний трек: §f«" + top.title + "» §7(качество " + top.quality + ", " + top.streams + " прослушиваний)");
        }
    }

    public static void follow(ServerPlayerEntity v, UUID tid) {
        ServerPlayerEntity t = target(v, tid);
        if (t == null || t == v) return;
        RapState st = RapState.get(v.getServer());
        RapState.Stats a = st.of(v.getUuid());
        if (a.subs.remove(tid)) {
            Gui.say(v, "§7Ты отписался от " + t.getName().getString() + ".");
        } else {
            a.subs.add(tid);
            Gui.say(v, "§aТы подписался на " + t.getName().getString() + ". Будешь видеть его релизы.");
            Gui.say(t, "§d" + v.getName().getString() + " подписался на тебя. §7+5% к стримам.");
        }
        st.markDirty();
    }

    public static void notifyFollowers(MinecraftServer s, ServerPlayerEntity artist, String title) {
        RapState st = RapState.get(s);
        String name = artist.getName().getString();
        for (ServerPlayerEntity o : s.getPlayerManager().getPlayerList()) {
            if (o == artist || !st.of(o.getUuid()).subs.contains(artist.getUuid())) continue;
            o.sendMessage(Text.literal("§d[Облачко] " + name + " выпустил «" + title + "» ").append(button("§a[Послушать]", "/rap listen " + name)));
        }
    }

    public static void listen(ServerPlayerEntity v, UUID tid) {
        ServerPlayerEntity t = target(v, tid);
        if (t == null) return;
        if (t == v) { Gui.say(v, "§7Свои треки ты и так знаешь наизусть."); return; }
        MinecraftServer s = v.getServer();
        RapState st = RapState.get(s);
        RapState.Stats ta = st.of(tid), va = st.of(v.getUuid());
        if (ta.tracks.isEmpty()) { Gui.say(v, "§7У него пока нет треков."); return; }
        long now = s.getOverworld().getTime();
        if (onCooldown("listen:" + v.getUuid() + ":" + tid, now, 1200)) { Gui.say(v, "§7Ты уже слушал его недавно (раз в минуту)."); return; }
        RapState.Track tr = ta.tracks.get(0);
        tr.streams += 25;
        ta.totalStreams += 25;
        ta.royalties += 2;
        va.addHype(1);
        st.markDirty();
        Gui.say(v, "§bТы слушаешь «" + tr.title + "» от " + t.getName().getString() + ". §7Ему +25 прослушиваний.");
        t.sendMessage(Text.literal("§7" + v.getName().getString() + " слушает твой трек «" + tr.title + "»."), true);
    }

    public static void pay(ServerPlayerEntity v, UUID tid, int amount) {
        ServerPlayerEntity t = target(v, tid);
        if (t == null) return;
        if (t == v || amount < 1) { Gui.say(v, "§7Так не пойдёт."); return; }
        RapState st = RapState.get(v.getServer());
        RapState.Stats a = st.of(v.getUuid()), b = st.of(tid);
        if (a.money < amount) { Gui.say(v, "§cНе хватает денег."); return; }
        a.addMoney(-amount);
        b.addMoney(amount);
        st.markDirty();
        Gui.say(v, "§aПереведено " + amount + " ₽ игроку " + t.getName().getString() + ".");
        Gui.say(t, "§aТебе перевели " + amount + " ₽ от " + v.getName().getString() + ".");
    }

    public static void gift(ServerPlayerEntity v, UUID tid) {
        ServerPlayerEntity t = target(v, tid);
        if (t == null || t == v) return;
        ItemStack held = v.getMainHandStack();
        if (held.isEmpty()) { Gui.say(v, "§7Возьми в руку предмет, который хочешь подарить."); return; }
        if (held.isOf(RapLifeMod.PARCEL)) { Gui.say(v, "§7Груз Бархата не передаётся."); return; }
        ItemStack copy = held.copy();
        v.setStackInHand(Hand.MAIN_HAND, ItemStack.EMPTY);
        t.giveItemStack(copy);
        Gui.say(v, "§aПодарено: " + copy.getName().getString() + " ×" + copy.getCount());
        Gui.say(t, "§aТебе подарили " + copy.getName().getString() + " ×" + copy.getCount() + " от " + v.getName().getString() + ".");
    }

    public static void cover(ServerPlayerEntity v, UUID tid) {
        ServerPlayerEntity t = target(v, tid);
        if (t == null) return;
        RapState st = RapState.get(v.getServer());
        RapState.Stats a = st.of(v.getUuid()), b = st.of(tid);
        RapState.Crew c = st.crewOf(a);
        RapState.Member m = c == null ? null : c.members.get(v.getUuid());
        if (c == null || m == null || m.rank < 2 || !c.name.equals(b.crew)) { Gui.say(v, "§7Прикрывать могут Старшие и Лидер — только своих."); return; }
        if (b.wanted <= 0) { Gui.say(v, "§7Его никто не ищет."); return; }
        long now = v.getServer().getOverworld().getTime();
        if (onCooldown("cover:" + tid, now, 6000)) { Gui.say(v, "§7Его уже недавно прикрывали."); return; }
        if (a.money < 100) { Gui.say(v, "§cНужно 100 ₽."); return; }
        a.addMoney(-100);
        b.wanted--;
        a.cred += 1;
        st.markDirty();
        Gui.say(v, "§aТы замолвил слово за " + t.getName().getString() + ".");
        Gui.say(t, "§9" + v.getName().getString() + " прикрыл тебя. Розыск: " + Crime.stars(b.wanted));
    }

    public static void crewChat(ServerPlayerEntity p, String msg) {
        MinecraftServer s = p.getServer();
        RapState st = RapState.get(s);
        RapState.Crew c = st.crewOf(st.of(p.getUuid()));
        if (c == null) { Gui.say(p, "§7Ты не в crew."); return; }
        for (UUID id : c.members.keySet()) {
            ServerPlayerEntity o = s.getPlayerManager().getPlayer(id);
            if (o != null) Gui.say(o, "§5[Crew «" + c.name + "»] §f" + p.getName().getString() + "§7: " + msg);
        }
    }

    // ---------- вечеринки ----------
    public static void party(ServerPlayerEntity v) {
        MinecraftServer s = v.getServer();
        RapState.Stats a = RapState.get(s).of(v.getUuid());
        if (PARTY.remove(v.getUuid()) != null) { Gui.say(v, "§7Вечеринка закончилась. Все разошлись."); return; }
        if (Shop.qualityBonus(a) == 0 || a.homeSet == 0) { Gui.say(v, "§7Для вечеринки нужен дом с сохранённой точкой (/rap home set)."); return; }
        PARTY.put(v.getUuid(), s.getOverworld().getTime() + 12000);
        Gui.say(v, "§aДвери открыты на 10 минут. Каждый гость приносит тебе хайп.");
        String name = v.getName().getString();
        for (ServerPlayerEntity o : s.getPlayerManager().getPlayerList()) {
            if (o != v) o.sendMessage(Text.literal("§d[Вечеринка] " + name + " открыл двери дома! ").append(button("§a[Прийти]", "/rap visit " + name)));
        }
    }

    public static void visit(ServerPlayerEntity v, UUID tid) {
        ServerPlayerEntity host = target(v, tid);
        if (host == null) return;
        MinecraftServer s = v.getServer();
        if (!PARTY.containsKey(tid)) { Gui.say(v, "§7Вечеринка уже закончилась."); return; }
        RapState st = RapState.get(s);
        RapState.Stats h = st.of(tid), a = st.of(v.getUuid());
        long now = s.getOverworld().getTime();
        if (v != host && onCooldown("visit:" + v.getUuid() + ":" + tid, now, 3000)) { Gui.say(v, "§7Ты уже был у него недавно."); return; }
        v.teleport(s.getOverworld(), h.homeX + 0.5, h.homeY, h.homeZ + 0.5, v.getYaw(), v.getPitch());
        if (v != host) {
            h.addHype(5); h.followers += 3; a.addHype(2); a.addLoyalty(1);
            st.markDirty();
            Gui.say(host, "§d" + v.getName().getString() + " пришёл на вечеринку. §e+5 хайпа");
        }
        Gui.say(v, "§dТы на вечеринке у " + host.getName().getString() + ". §e+2 хайпа");
    }

    public static void announceConcert(ServerPlayerEntity p, String venue) {
        String name = p.getName().getString();
        for (ServerPlayerEntity o : p.getServer().getPlayerManager().getPlayerList()) {
            if (o != p) o.sendMessage(Text.literal("§6[Афиша] " + name + " выступает: " + venue + " ").append(button("§a[Прийти]", "/rap attend " + name)));
        }
    }

    public static void tick(MinecraftServer s) {
        long now = s.getOverworld().getTime();
        PARTY.entrySet().removeIf(e -> now > e.getValue());
    }
}
