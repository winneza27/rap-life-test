package ru.raplife;

import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Районы города: crew захватывают их из общака, воюют друг с другом, районы приносят доход в общак. */
public final class Districts {
    public static final String[] NAMES = {"Бетонный квартал", "Гаражи", "Набережная", "Рынок", "Вокзал", "Новостройки"};
    private static final Random R = new Random();
    private static final Map<String, Long> LAST = new HashMap<>();

    public static void open(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        RapState.Crew me = st.crewOf(a);
        Gui.Builder b = new Gui.Builder("Районы города", 3);
        for (int i = 0; i < NAMES.length; i++) {
            String n = NAMES[i];
            String owner = st.districts.get(n);
            boolean mine = me != null && me.name.equals(owner);
            b.set(10 + i, Gui.icon(mine ? Items.GREEN_BANNER : owner == null ? Items.WHITE_BANNER : Items.RED_BANNER, (mine ? "§a" : "§f") + n,
                    "§7Владелец: §f" + (owner == null ? "никто" : owner), "§7Доход: §a20 ₽/мин в общак",
                    mine ? "§aТвой район" : owner == null ? "§eЗахватить: 1000 ₽ из общака" : "§cАтаковать: 500 ₽ из общака",
                    "§8Нужен ранг Старший или Лидер"), mine ? null : q -> act(q, n));
        }
        b.set(18, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(p);
    }

    private static void act(ServerPlayerEntity p, String name) {
        MinecraftServer s = p.getServer();
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(p.getUuid());
        RapState.Crew me = st.crewOf(a);
        if (me == null) { Gui.say(p, "§7Нужен crew."); return; }
        RapState.Member m = me.members.get(p.getUuid());
        if (m == null || m.rank < 2) { Gui.say(p, "§7Районы захватывают Старшие и Лидер."); return; }
        long now = s.getOverworld().getTime();
        Long last = LAST.get(me.name);
        if (last != null && now - last < 3600) { Gui.say(p, "§7Crew ещё зализывает раны (3 минуты между вылазками)."); return; }
        String owner = st.districts.get(name);
        if (owner == null) {
            if (me.treasury < 1000) { Gui.say(p, "§cВ общаке нужно 1000 ₽."); return; }
            me.treasury -= 1000;
            st.districts.put(name, me.name);
            me.rep += 5;
            LAST.put(me.name, now);
            st.markDirty();
            tell(s, me, "§6Crew «" + me.name + "» занял район «" + name + "».");
        } else {
            RapState.Crew def = st.crews.get(owner);
            if (def == null) { st.districts.remove(name); st.markDirty(); open(p); return; }
            if (me.treasury < 500) { Gui.say(p, "§cВ общаке нужно 500 ₽."); return; }
            me.treasury -= 500;
            LAST.put(me.name, now);
            int atk = me.members.size() * 12 + me.rep / 5 + R.nextInt(40);
            int dfn = def.members.size() * 12 + def.rep / 5 + 15 + R.nextInt(40);
            if (atk > dfn) {
                st.districts.put(name, me.name);
                me.rep += 8;
                def.rep = Math.max(0, def.rep - 3);
                tell(s, me, "§6Crew «" + me.name + "» отбил район «" + name + "» у «" + def.name + "» (" + atk + ":" + dfn + ").");
                tell(s, def, "§cCrew «" + me.name + "» отобрал у вас район «" + name + "».");
            } else {
                me.rep = Math.max(0, me.rep - 5);
                def.rep += 3;
                tell(s, me, "§cАтака на «" + name + "» провалилась (" + atk + ":" + dfn + "). Общак потерял 500 ₽.");
                tell(s, def, "§aВы отбили атаку «" + me.name + "» на район «" + name + "».");
            }
            st.markDirty();
        }
        open(p);
    }

    private static void tell(MinecraftServer s, RapState.Crew c, String msg) {
        for (UUID id : c.members.keySet()) {
            ServerPlayerEntity o = s.getPlayerManager().getPlayer(id);
            if (o != null) Gui.say(o, msg);
        }
    }

    public static void tick(MinecraftServer s) {
        RapState st = RapState.get(s);
        if (st.districts.isEmpty()) return;
        for (String owner : st.districts.values()) {
            RapState.Crew c = st.crews.get(owner);
            if (c != null) c.treasury += 20;
        }
        st.markDirty();
    }
}
