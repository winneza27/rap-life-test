package ru.raplife;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** ПКМ — меню телефона. Shift+ПКМ — сразу лента ТикТока. */
public class PhoneItem extends Item {
    public PhoneItem(Settings s) { super(s); }

    @Override
    public TypedActionResult<ItemStack> use(World w, PlayerEntity p, Hand h) {
        ItemStack stack = p.getStackInHand(h);
        if (w.isClient || !(p instanceof ServerPlayerEntity sp)) return TypedActionResult.success(stack);
        if (p.isSneaking()) {
            if (p.getItemCooldownManager().isCoolingDown(this)) return TypedActionResult.fail(stack);
            p.getItemCooldownManager().set(this, 100);
            RapAi.showFeed(sp);
        } else {
            PhoneMenu.open(sp);
        }
        return TypedActionResult.success(stack);
    }
}
