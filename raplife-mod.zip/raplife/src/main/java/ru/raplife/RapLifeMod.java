package ru.raplife;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.UUID;

public class RapLifeMod implements ModInitializer {
    public static final String MOD_ID = "raplife";
    public static Item MIC, PHONE, PARCEL;

    @Override
    public void onInitialize() {
        Config.load();
        MIC = Registry.register(Registries.ITEM, new Identifier(MOD_ID, "microphone"), new MicItem(new Item.Settings().maxCount(1)));
        PHONE = Registry.register(Registries.ITEM, new Identifier(MOD_ID, "phone"), new PhoneItem(new Item.Settings().maxCount(1)));
        PARCEL = Registry.register(Registries.ITEM, new Identifier(MOD_ID, "parcel"), new Item(new Item.Settings().maxCount(1)));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> { e.add(MIC); e.add(PHONE); });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) -> { RapCommands.register(dispatcher); Admin.register(dispatcher); });
        ServerTickEvents.END_SERVER_TICK.register(RapEvents::tick);
        UseEntityCallback.EVENT.register(Fans::onUse);
        UseEntityCallback.EVENT.register(Npcs::onUse);
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, src) -> { Crime.onDeath(entity, src); Boss.onDeath(entity, src); Beef.onDeath(entity, src); });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> Help.onJoin(handler.getPlayer()));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID id = handler.getPlayer().getUuid();
            Concert.abort(id);
            Choices.clear(id);
            Boss.abort(id);
            Beef.abort(id);
        });
    }
}
