package ru.raplife;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

public final class RapAi {
    private static final Random R = new Random();

    public static final String SYSTEM =
            "Ты сценарист пародийной игры про жизнь вымышленного русского рэпера из андеграунд-сцены "
          + "(клауд-рэп, трэп, SoundCloud-эстетика). Все персонажи, организации и государственные органы вымышлены, "
          + "реальных людей и партий не называй. Без мата, без восхваления наркотиков и насилия, без оскорблений. "
          + "Отвечай по-русски, очень коротко.";

    public static CompletableFuture<List<String>> lyrics(String nick, int hype, String title) {
        String user = "Рэпер «" + nick + "» (этап карьеры: " + RapState.stageName(hype) + ", хайп " + hype
                + ") выпустил трек «" + title + "». Напиши ровно 4 коротких строки куплета в стиле клауд-рэпа. "
                + "Верни только 4 строки, без нумерации и пояснений.";
        return AiClient.ask(SYSTEM, user).thenApply(t -> {
            List<String> l = lines(t, 4);
            if (l.isEmpty()) return Offline.lyrics(title);
            List<String> out = new ArrayList<>();
            for (String s : l) out.add("§f" + s);
            return out;
        });
    }

    public static CompletableFuture<List<String>> feed(String nick, int hype, int cred) {
        String user = "Ты — лента ИИ-ТикТока в мире игры. Рэпер «" + nick + "», этап: " + RapState.stageName(hype)
                + ", хайп " + hype + ", уличный авторитет " + cred + ". Придумай ровно 3 вирусных видео про него. "
                + "Каждая строка в формате: описание видео (до 80 символов) | комментарий (до 50 символов). "
                + "Верни только 3 строки.";
        return AiClient.ask(SYSTEM, user).thenApply(t -> {
            List<String> l = lines(t, 3);
            return l.isEmpty() ? Offline.feed() : l;
        });
    }

    public static void showFeed(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        if (s == null) return;
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(p.getUuid());
        p.sendMessage(Text.literal("§d[ТикТок] §7Листаем ленту" + (Config.get().ready() ? " (ИИ)..." : " (офлайн)...")));
        feed(p.getName().getString(), a.hype, a.cred).thenAccept(lines -> s.execute(() -> {
            for (String l : lines) {
                String[] parts = l.split("\\|", 2);
                p.sendMessage(Text.literal("§d▶ §f" + parts[0].strip()));
                if (parts.length > 1) p.sendMessage(Text.literal("   §8> §7" + parts[1].strip()));
            }
            if (R.nextInt(100) < 25 + Math.min(30, a.cred) + a.loyalty / 5 + Shop.style(a) / 2) {
                int g = 15 + R.nextInt(25);
                a.addHype(g);
                a.followers += g * 2;
                st.markDirty();
                p.sendMessage(Text.literal("§6★ Видео залетело в рекомендации! §e+" + g + " хайпа"));
            }
        }));
    }

    /** Реплика персонажа (ИИ или запасной текст), затем after на серверном потоке. */
    public static void speak(ServerPlayerEntity p, String speaker, String persona, String situation,
                             String[] fallback, Runnable after) {
        MinecraftServer s = p.getServer();
        if (s == null) return;
        RapState.Stats a = RapState.get(s).of(p.getUuid());
        String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        String user = "Персонаж: " + speaker + ". " + persona + " Ситуация: " + situation
                + " Игрок: рэпер «" + p.getName().getString() + "», этап «" + RapState.stageName(a.hype)
                + "», хайп " + a.hype + ", розыск " + a.wanted + ", лояльность фанатов " + a.loyalty
                + ". Время на часах игрока: " + time + ". Напиши 2-3 короткие реплики персонажа "
                + "(каждая с новой строки, до 110 символов). Стиль: странно, поэтично, с мета-юмором в духе "
                + "Хидео Кодзимы. Без мата. Верни только реплики.";
        AiClient.ask(SYSTEM, user).thenAccept(t -> s.execute(() -> {
            List<String> l = lines(t, 3);
            if (l.isEmpty()) l = Arrays.asList(fallback);
            p.sendMessage(Text.literal("§8[ §6" + speaker + " §8]"));
            for (String x : l) p.sendMessage(Text.literal("§f  " + x));
            if (after != null) after.run();
        }));
    }

    public static List<String> lines(String t, int max) {
        List<String> out = new ArrayList<>();
        if (t == null) return out;
        for (String l : t.split("\\R")) {
            l = l.strip().replaceFirst("^[\\-•*\\d.)\\s]+", "");
            if (l.isEmpty()) continue;
            out.add(l.length() > 140 ? l.substring(0, 140) : l);
            if (out.size() >= max) break;
        }
        return out;
    }
}
