package ru.raplife;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;

import java.util.UUID;

/** Помощники-NPC: менеджер, звукарь, юрист, Старший, охранник. Привязаны к владельцу. */
public final class Npcs {
    public static final String TAG = "raplife_npc";
    private record Role(String id, String name, int price, String desc, net.minecraft.item.Item icon) {}

    private static final Role[] ROLES = {
            new Role("manager", "Менеджер", 2000, "Сам выводит роялти, заказывает рекламу", Items.WRITABLE_BOOK),
            new Role("engineer", "Звукарь", 1500, "+2 к качеству новых треков, пересводит старые", Items.NOTE_BLOCK),
            new Role("lawyer", "Юрист", 2500, "Закрывает дела, снимает налоговые риски", Items.BOOK),
            new Role("elder", "Старший", 0, "Даёт поручения (нужна Глава 2)", Items.GOLDEN_HELMET),
            new Role("guard", "Охранник", 1800, "Стоит на посту и бьёт Патруль рядом", Items.IRON_CHESTPLATE)};

    public static void openHire(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        Gui.Builder b = new Gui.Builder("Помощники", 3);
        int slot = 10;
        for (Role r : ROLES) {
            boolean has = a.npcIds.containsKey(r.id());
            b.set(slot++, Gui.icon(r.icon(), (has ? "§a✔ " : "§f") + r.name(), "§7" + r.desc(),
                    has ? "§eКлик — позвать к себе" : "§eНанять: " + r.price() + " ₽"), q -> { if (has) summon(q, r); else hire(q, r); });
        }
        b.set(16, Gui.icon(Items.ARROW, "§7Назад"), PhoneMenu::open);
        b.frame().open(p);
    }

    private static void hire(ServerPlayerEntity p, Role r) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (r.id().equals("elder") && a.chapter < 2) { Gui.say(p, "§7Старшие замечают только тех, у кого есть 100 хайпа."); return; }
        if (a.money < r.price()) { Gui.say(p, "§cНужно " + r.price() + " ₽."); return; }
        a.addMoney(-r.price());
        Entity e = spawn(p, r);
        if (e == null) return;
        a.npcIds.put(r.id(), e.getUuid());
        st.markDirty();
        Gui.say(p, "§aТеперь у тебя есть помощник: " + r.name() + ". ПКМ по нему — меню.");
        openHire(p);
    }

    private static void summon(ServerPlayerEntity p, Role r) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        ServerWorld w = p.getServerWorld();
        Entity e = w.getEntity(a.npcIds.get(r.id()));
        if (e != null && !e.isRemoved()) {
            e.requestTeleport(p.getX() + 1.5, p.getY(), p.getZ() + 1.5);
        } else {
            Entity n = spawn(p, r);
            if (n != null) { a.npcIds.put(r.id(), n.getUuid()); st.markDirty(); }
        }
        p.closeHandledScreen();
        Gui.say(p, "§7" + r.name() + " рядом.");
    }

    private static Entity spawn(ServerPlayerEntity p, Role r) {
        ServerWorld w = p.getServerWorld();
        Entity e = r.id().equals("guard") ? EntityType.IRON_GOLEM.create(w) : EntityType.VILLAGER.create(w);
        if (e == null) return null;
        e.refreshPositionAndAngles(p.getX() + 1.5, p.getY(), p.getZ() + 1.5, p.getYaw(), 0f);
        e.setCustomName(net.minecraft.text.Text.literal("§6" + r.name()));
        e.setCustomNameVisible(true);
        e.addCommandTag(TAG);
        e.addCommandTag("role:" + r.id());
        e.addCommandTag("owner:" + p.getUuidAsString());
        if (e instanceof MobEntity m) {
            m.setPersistent();
            if (!(e instanceof IronGolemEntity)) { m.setAiDisabled(true); m.setInvulnerable(true); }
        }
        if (e instanceof IronGolemEntity g) g.setPlayerCreated(true);
        w.spawnEntity(e);
        return e;
    }

    public static ActionResult onUse(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hit) {
        if (!entity.getCommandTags().contains(TAG)) return ActionResult.PASS;
        if (world.isClient || hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity sp)) return ActionResult.SUCCESS;
        String role = null, owner = null;
        for (String t : entity.getCommandTags()) {
            if (t.startsWith("role:")) role = t.substring(5);
            if (t.startsWith("owner:")) owner = t.substring(6);
        }
        if (role == null || owner == null) return ActionResult.SUCCESS;
        if (!owner.equals(sp.getUuidAsString())) { Gui.say(sp, "§7Это чей-то помощник."); return ActionResult.SUCCESS; }
        UUID id = RapState.get(sp.getServer()).of(sp.getUuid()).npcIds.get(role);
        if (id == null || !id.equals(entity.getUuid())) { entity.discard(); Gui.say(sp, "§7Этот помощник больше не у тебя на службе."); return ActionResult.SUCCESS; }
        openRole(sp, role);
        return ActionResult.SUCCESS;
    }

    private static void openRole(ServerPlayerEntity p, String role) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        switch (role) {
            case "manager" -> {
                Gui.Builder b = new Gui.Builder("Менеджер", 3);
                b.set(10, Gui.icon(Items.EMERALD, "§aЗабрать роялти: " + (int) a.royalties + " ₽"), q -> { Streaming.withdraw(q); openRole(q, "manager"); });
                b.set(12, Gui.icon(Items.PAPER, "§dРеклама у блогеров", "§7200 ₽ → +40 хайпа"), q -> {
                    if (a.money < 200) { Gui.say(q, "§cНужно 200 ₽."); return; }
                    a.addMoney(-200); a.addHype(40); a.followers += 80; st.markDirty();
                    Gui.say(q, "§dБлогеры сделали рекламу. §e+40 хайпа"); openRole(q, "manager"); });
                b.set(14, Gui.icon(Items.FIREWORK_ROCKET, "§6Организовать концерт"), q -> { q.closeHandledScreen(); Concert.start(q); });
                b.set(16, Gui.icon(Items.JUKEBOX, "§bОткрыть стриминг"), Streaming::open);
                b.frame().open(p);
            }
            case "engineer" -> {
                Gui.Builder b = new Gui.Builder("Звукарь: пересвести трек (300 ₽)", 4);
                int[] slots = {10, 11, 12, 13, 14, 15, 16};
                for (int i = 0; i < a.tracks.size() && i < slots.length; i++) {
                    RapState.Track t = a.tracks.get(i);
                    b.set(slots[i], Gui.icon(Items.MUSIC_DISC_13, "§f" + t.title, "§7Качество: §e" + t.quality + "/10"), q -> { Streaming.improve(q, t); openRole(q, "engineer"); });
                }
                if (a.tracks.isEmpty()) b.set(13, Gui.icon(Items.PAPER, "§7Нет треков для сведения"), null);
                b.frame().open(p);
            }
            case "lawyer" -> {
                Gui.Builder b = new Gui.Builder("Юрист", 3);
                int cost = 300 * Math.max(1, a.wanted);
                b.set(11, Gui.icon(Items.IRON_BARS, "§9Закрыть дело (розыск → 0)", "§7Цена: " + cost + " ₽", "§7Сейчас: " + Crime.stars(a.wanted)), q -> {
                    if (a.wanted <= 0) { Gui.say(q, "§7Дел нет."); return; }
                    if (a.money < cost) { Gui.say(q, "§cНужно " + cost + " ₽."); return; }
                    a.addMoney(-cost); a.wanted = 0; st.markDirty(); Gui.say(q, "§aДело закрыто."); openRole(q, "lawyer"); });
                b.set(15, Gui.icon(Items.BOOK, "§6Налоговая консультация", "§7600 ₽ — обнулить риск проверок", "§7Риск: " + a.auditRisk + "%"), q -> {
                    if (a.money < 600) { Gui.say(q, "§cНужно 600 ₽."); return; }
                    a.addMoney(-600); a.auditRisk = 0; st.markDirty(); Gui.say(q, "§aДокументы в порядке."); openRole(q, "lawyer"); });
                b.frame().open(p);
            }
            case "elder" -> {
                Gui.Builder b = new Gui.Builder("Старший", 3);
                b.set(11, Gui.icon(Items.WRITABLE_BOOK, "§6Взять поручение"), q -> { q.closeHandledScreen(); Missions.accept(q); });
                b.set(13, Gui.icon(Items.BOOK, "§fСтатус поручения"), q -> { q.closeHandledScreen(); Missions.status(q); });
                b.set(15, Gui.icon(Items.GOLDEN_HELMET, "§eСовет по жизни"), q -> {
                    q.closeHandledScreen();
                    RapAi.speak(q, "Старший", "Ты — Старший, пожилой уважаемый человек района, говоришь коротко, по-отечески, с поговорками.",
                            "Дай рэперу совет по карьере и жизни.",
                            new String[]{"Слава — как лёд: красиво, пока не растаяла.", "Не бери то, чего не вернёшь, не обещай того, чего не сделаешь."}, null);
                });
                b.frame().open(p);
            }
            default -> Gui.say(p, "§7Охранник кивает и продолжает стоять на посту.");
        }
    }
}
