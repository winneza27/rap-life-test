package ru.raplife;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.VindicatorEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.*;

/** Серые схемы: абстрактный «Груз» от синдиката «Бархат», розыск, Патруль, отмыв, взятки, накрутка. */
public final class Crime {
    public static final String COP = "raplife_cop";
    private static final Random R = new Random();

    private static class Run { int tx, tz, pay, loaded; long deadline; }
    private static final Map<UUID, Run> RUNS = new HashMap<>();

    public static String stars(int n) { return "★".repeat(n) + "☆".repeat(Math.max(0, 5 - n)); }

    public static void addWanted(ServerPlayerEntity p, RapState.Stats a, int n) {
        a.wanted = Math.min(5, a.wanted + n);
        a.lastWantedTick = p.getServer().getOverworld().getTime();
        p.sendMessage(Text.literal("§c⚠ Розыск: " + stars(a.wanted)));
    }

    // ---------- Груз ----------
    public static void startRun(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        RapState st = RapState.get(s);
        RapState.Stats a = st.of(p.getUuid());
        if (a.chapter < 2) { p.sendMessage(Text.literal("§7Бархат пока не знает твоего имени (нужно 100 хайпа).")); return; }
        if (RUNS.containsKey(p.getUuid())) { p.sendMessage(Text.literal("§7Груз уже у тебя. §f/rap run status")); return; }
        double ang = R.nextDouble() * Math.PI * 2;
        int dist = 250 + R.nextInt(250);
        Run r = new Run();
        r.tx = (int) (p.getX() + Math.cos(ang) * dist);
        r.tz = (int) (p.getZ() + Math.sin(ang) * dist);
        r.pay = 250 + a.chapter * 100 + R.nextInt(150);
        if (a.stash > 0) { r.loaded = a.stash; r.pay *= (1 + a.stash); a.stash = 0; st.markDirty(); }
        r.deadline = s.getOverworld().getTime() + 12000;
        RUNS.put(p.getUuid(), r);
        p.giveItemStack(new ItemStack(RapLifeMod.PARCEL));
        p.sendMessage(Text.literal("§6Груз получен. §fТочка: X " + r.tx + ", Z " + r.tz + " §7(10 минут). Не теряй груз и не нарывайся на Патруль."));
    }

    public static void status(ServerPlayerEntity p) {
        Run r = RUNS.get(p.getUuid());
        if (r == null) { p.sendMessage(Text.literal("§7Активных заказов нет. Позвони Бархату: /rap codec")); return; }
        long left = (r.deadline - p.getServer().getOverworld().getTime()) / 20;
        p.sendMessage(Text.literal("§6Груз: §fX " + r.tx + ", Z " + r.tz + " §7| осталось " + left + " с | оплата ~" + r.pay + " ₽ (грязные)"));
    }

    public static void abort(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (RUNS.remove(p.getUuid()) == null) { p.sendMessage(Text.literal("§7Нечего отменять.")); return; }
        removeParcel(p);
        a.repSyndicate -= 5;
        st.markDirty();
        p.sendMessage(Text.literal("§cТы отказался от заказа. Бархат это запомнит. §7(-5 репутации)"));
    }

    public static boolean hasRun(UUID id) { return RUNS.containsKey(id); }

    private static boolean hasParcel(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).isOf(RapLifeMod.PARCEL)) return true;
        return false;
    }

    private static void removeParcel(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).isOf(RapLifeMod.PARCEL)) inv.setStack(i, ItemStack.EMPTY);
    }

    public static void tickRuns(MinecraftServer s) {
        if (RUNS.isEmpty()) return;
        RapState st = RapState.get(s);
        long now = s.getOverworld().getTime();
        Iterator<Map.Entry<UUID, Run>> it = RUNS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Run> en = it.next();
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(en.getKey());
            if (p == null) continue;
            Run r = en.getValue();
            RapState.Stats a = st.of(p.getUuid());
            if (!hasParcel(p)) {
                a.repSyndicate -= 10; st.markDirty();
                p.sendMessage(Text.literal("§cГруз потерян. Бархат недоволен. §7(-10 репутации)"));
                it.remove(); continue;
            }
            if (now > r.deadline) {
                removeParcel(p); a.repSyndicate -= 8; st.markDirty();
                p.sendMessage(Text.literal("§cТы опоздал. Получатель ушёл. §7(-8 репутации)"));
                it.remove(); continue;
            }
            double dx = p.getX() - r.tx, dz = p.getZ() - r.tz;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d < 6) { deliver(p, st, a, r); it.remove(); continue; }
            p.sendMessage(Text.literal("§8Груз: §f" + (int) d + " м §8| осталось " + (r.deadline - now) / 20 + " с"), true);
            if (R.nextInt(r.loaded > 0 ? 45 : 90) == 0 && !Choices.hasPending(p.getUuid())) checkpoint(p, st, a);
        }
    }

    private static void deliver(ServerPlayerEntity p, RapState st, RapState.Stats a, Run r) {
        removeParcel(p);
        a.dirty += r.pay;
        a.repSyndicate += 5;
        a.cred += 2;
        st.markDirty();
        Missions.onEvent(p, 3, 1);
        p.sendMessage(Text.literal("§aГруз доставлен. §e+" + r.pay + " ₽ грязными §7(отмой: /rap launder <сумма>)"));
        if (R.nextInt(100) < 30) {
            p.sendMessage(Text.literal("§9За тобой был хвост."));
            addWanted(p, a, 1);
            st.markDirty();
        }
    }

    private static void checkpoint(ServerPlayerEntity p, RapState st, RapState.Stats a) {
        Choices.offer(p, "Патрульный пост", List.of("Тебя останавливают для «рутинной проверки».", "Рюкзак выглядит подозрительно тяжёлым."),
                Choices.opt("Откупиться (150 ₽)", q -> {
                    if (a.money >= 150) { a.addMoney(-150); a.repPolice += 1; st.markDirty(); q.sendMessage(Text.literal("§7Патрульный отвернулся. Проезжай.")); }
                    else { q.sendMessage(Text.literal("§cНе хватает денег! Приходится бежать.")); addWanted(q, a, 1); spawnPatrol(q, 2); st.markDirty(); }
                }),
                Choices.opt("Рвануть с места", q -> { addWanted(q, a, 1); a.repPolice -= 3; spawnPatrol(q, 1 + a.wanted); st.markDirty(); }),
                Choices.opt("Сдать маршрут Майору", q -> {
                    RUNS.remove(q.getUuid()); removeParcel(q);
                    a.repPolice += 10; a.repSyndicate -= 15; a.addMoney(100); st.markDirty();
                    q.sendMessage(Text.literal("§7Майор кивает: «Хороший артист». §e+100 ₽, репутация у Бархата упала."));
                }));
    }

    // ---------- Патруль ----------
    public static void spawnPatrol(ServerPlayerEntity p, int count) {
        ServerWorld w = p.getServerWorld();
        for (int i = 0; i < count; i++) {
            double ang = R.nextDouble() * Math.PI * 2;
            double dist = 14 + R.nextInt(8);
            int x = (int) (p.getX() + Math.cos(ang) * dist), z = (int) (p.getZ() + Math.sin(ang) * dist);
            int y = w.getRegistryKey() == World.OVERWORLD ? w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) : (int) p.getY();
            VindicatorEntity v = EntityType.VINDICATOR.create(w);
            if (v == null) continue;
            v.refreshPositionAndAngles(x + 0.5, y, z + 0.5, R.nextFloat() * 360f, 0f);
            v.setCustomName(Text.literal("§9Патрульный"));
            v.setCustomNameVisible(true);
            v.addCommandTag(COP);
            v.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_AXE));
            v.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
            v.setPersistent();
            v.setTarget(p);
            w.spawnEntity(v);
        }
        p.sendMessage(Text.literal("§9Патруль на подходе!"));
    }

    public static void tickPatrols(MinecraftServer s) {
        RapState st = RapState.get(s);
        long now = s.getOverworld().getTime();
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            RapState.Stats a = st.of(p.getUuid());
            if (a.wanted <= 0) continue;
            if (now - a.lastWantedTick > 3600) {
                a.wanted--; a.lastWantedTick = now; st.markDirty();
                p.sendMessage(Text.literal("§7Розыск снижен: " + stars(a.wanted)));
            }
            if (a.wanted > 0 && R.nextInt(100) >= Math.max(0, Math.min(60, a.repStreet))) {
                int near = p.getServerWorld().getEntitiesByClass(VindicatorEntity.class, p.getBoundingBox().expand(48),
                        v -> v.getCommandTags().contains(COP)).size();
                if (near < 3) spawnPatrol(p, Math.min(a.wanted, 3));
            }
        }
    }

    public static void onDeath(LivingEntity e, DamageSource src) {
        if (e.getCommandTags().contains(COP) && src.getAttacker() instanceof ServerPlayerEntity sp) {
            RapState st = RapState.get(sp.getServer());
            RapState.Stats a = st.of(sp.getUuid());
            a.repPolice -= 5;
            addWanted(sp, a, 1);
            st.markDirty();
        }
    }

    // ---------- Деньги ----------
    public static void launder(ServerPlayerEntity p, int amount) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (amount > a.dirty) { p.sendMessage(Text.literal("§cУ тебя только " + a.dirty + " ₽ грязными.")); return; }
        int fee = Math.max(10, 30 - a.repSyndicate / 5);
        int clean = amount * (100 - fee) / 100;
        a.dirty -= amount;
        a.addMoney(clean);
        a.auditRisk = Math.min(90, a.auditRisk + Math.max(1, amount / 20));
        st.markDirty();
        p.sendMessage(Text.literal("§aОтмыто через мерч и клубы: §e" + clean + " ₽ §7(комиссия " + fee + "%). Внимание Ведомства растёт."));
    }

    public static void bribe(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        if (a.wanted <= 0) { p.sendMessage(Text.literal("§7Тебя никто не ищет.")); return; }
        int cost = 100 * a.wanted;
        if (a.money < cost) { p.sendMessage(Text.literal("§cНужно " + cost + " ₽.")); return; }
        a.addMoney(-cost); a.wanted--; a.repPolice -= 2; st.markDirty();
        p.sendMessage(Text.literal("§7Конверт перешёл из рук в руки. Розыск: " + stars(a.wanted) + " §c-" + cost + " ₽"));
    }

    public static void boost(ServerPlayerEntity p) {
        RapState st = RapState.get(p.getServer());
        RapState.Stats a = st.of(p.getUuid());
        long now = p.getServer().getOverworld().getTime();
        if (now - a.lastBoost < 3000) { p.sendMessage(Text.literal("§7Ботоферма остывает.")); return; }
        if (a.money < 300) { p.sendMessage(Text.literal("§cНакрутка стоит 300 ₽.")); return; }
        a.lastBoost = now; a.addMoney(-300);
        if (R.nextInt(100) < 35) {
            a.addHype(-40); a.repGov -= 3; a.addLoyalty(-5);
            p.sendMessage(Text.literal("§cАлгоритм заметил накрутку и тебя забанили в рекомендациях. §7-40 хайпа"));
        } else {
            a.addHype(60); a.followers += 150;
            p.sendMessage(Text.literal("§aБоты сделали своё дело. §e+60 хайпа"));
        }
        st.markDirty();
    }
}
