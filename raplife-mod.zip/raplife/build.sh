#!/bin/sh
# Нужны: JDK 17+ и установленный Gradle 8.6+  (https://gradle.org/install)
gradle build && echo "Готово: build/libs/raplife-1.0.0.jar"
