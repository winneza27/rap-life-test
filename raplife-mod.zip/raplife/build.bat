@echo off
gradle build
echo Готово: build\libs\raplife-1.0.0.jar
pause
